<?php
/**
 * GENERATED FILE — do not edit directly.
 * Source: index.html.  Rebuild with: python3 tools/build-theme.py
 */
?>
<?php get_header(); ?>

<main id="main">

  <!-- ── HERO ────────────────────────────────────────────────── -->
  <section class="hero" id="heroSlider" aria-label="EnVue Telematics highlights">
    <div class="hero-backgrounds" aria-hidden="true">
      <div class="hero-bg active">
        <img src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=2000&q=80" alt="" loading="eager" fetchpriority="high">
      </div>
      <div class="hero-bg">
        <img src="https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=2000&q=80" alt="" loading="lazy">
      </div>
      <div class="hero-bg">
        <img src="https://images.unsplash.com/photo-1703194531119-e8b98a555cb6?auto=format&fit=crop&w=2000&q=80" alt="" loading="lazy">
      </div>
    </div>
    <div class="hero-scrim" aria-hidden="true"></div>

    <div class="wrap hero-layout">
      <div class="hero-content">
        <div class="hero-slide active" data-slide="0">
          <span class="eyebrow eyebrow--light">Intelligence for every route</span>
          <h1>Every vehicle visible. <span>Every decision on time.</span></h1>
          <p>EnVue connects your fleet, your assets and your safety evidence through GPS tracking, AI dash cams and a team that deploys it with you — not a box shipped to your yard.</p>
        </div>
        <div class="hero-slide" data-slide="1" aria-hidden="true">
          <span class="eyebrow eyebrow--light">Command center</span>
          <h1>Control the miles, <span>the risk and the margin.</span></h1>
          <p>Live telemetry from every vehicle turns the daily run into an operation you can measure: where the cost is, where the risk is, and what to do about both this week.</p>
        </div>
        <div class="hero-slide" data-slide="2" aria-hidden="true">
          <span class="eyebrow eyebrow--light">Local deployment</span>
          <h1>Technology your team <span>actually uses.</span></h1>
          <p>From the first assessment through quarterly reviews, we stay with the rollout until dispatch, safety and maintenance are each working from the same picture.</p>
        </div>

        <div class="hero-actions">
          <a class="button button-primary button-lg" href="#demo">Get a Free Demo <span>→</span></a>
          <a class="button button-ghost button-lg" href="#platform">See the platform</a>
        </div>

        <div class="hero-controls" aria-label="Change highlighted slide">
          <button class="hero-arrow" id="heroPrevious" type="button" aria-label="Previous slide">←</button>
          <div class="hero-dots">
            <button class="hero-dot active" type="button" data-hero-go="0" aria-pressed="true" aria-label="Slide 1"></button>
            <button class="hero-dot" type="button" data-hero-go="1" aria-pressed="false" aria-label="Slide 2"></button>
            <button class="hero-dot" type="button" data-hero-go="2" aria-pressed="false" aria-label="Slide 3"></button>
          </div>
          <button class="hero-arrow" id="heroNext" type="button" aria-label="Next slide">→</button>
          <div class="hero-count" aria-live="polite"><strong id="heroCurrent">01</strong> / 03</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── CREDIBILITY ─────────────────────────────────────────── -->
  <section aria-label="Fleet results at a glance">
    <div class="wrap">
      <div class="stat-band">
        <div><strong><span data-count="31">31</span>%</strong><span>Fewer reportable accidents</span></div>
        <div><strong><span data-count="7">7</span>%</strong><span>Fuel economy improvement</span></div>
        <div><strong><span data-count="40">40</span>%</strong><span>Dispatch efficiency gain</span></div>
        <div><strong><span data-count="300">300</span>+</strong><span>Software integrations</span></div>
      </div>
    </div>
  </section>

  <!-- ── COMMAND ─────────────────────────────────────────────── -->
  <section class="section">
    <div class="wrap command-grid">
      <div class="command-copy reveal">
        <span class="eyebrow">Connected operation</span>
        <h2>One clear view for every team that touches the fleet.</h2>
        <p class="lede">Leadership needs the number. Operations needs to know where to act. Safety needs context. Maintenance needs early warning. EnVue puts all four on the same operational truth instead of four spreadsheets that disagree.</p>
        <div class="command-points">
          <div><strong>01</strong><span>Vehicle, route and idle-time oversight in a single live map.</span></div>
          <div><strong>02</strong><span>Video evidence for incidents, preventive coaching and driver protection.</span></div>
          <div><strong>03</strong><span>Executive reporting on savings, risk, utilization and service levels.</span></div>
        </div>
      </div>
      <div class="command-images reveal" style="--d:1">
        <img class="main" src="https://images.unsplash.com/photo-1703194531119-e8b98a555cb6?auto=format&fit=crop&w=1200&q=80" alt="Fleet yard viewed from above at a container terminal" loading="lazy">
        <img class="float top" src="https://images.unsplash.com/photo-1744884275743-4b075af04f62?auto=format&fit=crop&w=700&q=80" alt="AI dash cam monitoring inside a truck cab" loading="lazy">
        <img class="float bottom" src="https://images.unsplash.com/photo-1534097575056-ddba81f714c8?auto=format&fit=crop&w=700&q=80" alt="Construction equipment tracked on site" loading="lazy">
      </div>
    </div>
  </section>

  <!-- ── PROOF ───────────────────────────────────────────────── -->
  <section class="section section--soft">
    <div class="wrap">
      <div class="section-head">
        <div>
          <span class="eyebrow">Why fleets switch</span>
          <h2>Results your operation can point at.</h2>
        </div>
        <p>Three things change in the first quarter: fewer calls to find a vehicle, fewer incidents that turn into claims, and a maintenance schedule that stops surprising you.</p>
      </div>

      <div class="proof-grid">
        <article class="proof-card-large reveal">
          <img src="https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=1100&q=80" alt="Fleet of trucks on the highway" loading="lazy">
          <span>Control</span>
          <h3>Fewer phone calls to find a truck.</h3>
          <p>Dispatch sees routes, stops, deviations and critical alerts from one shared base — so the answer to “where is it?” stops costing anyone an afternoon.</p>
          <a href="<?php echo esc_url( home_url( '/gps-tracking/' ) ); ?>">See GPS tracking →</a>
        </article>

        <article class="reveal" style="--d:1">
          <img src="https://images.unsplash.com/photo-1744884275743-4b075af04f62?auto=format&fit=crop&w=700&q=80" alt="Driver monitored by an in-cab safety camera" loading="lazy">
          <span>Adoption</span>
          <h3>Data the team will actually use.</h3>
          <p>Training, role-based reporting and quarterly reviews that turn a platform into an operating habit.</p>
          <a href="<?php echo esc_url( home_url( '/company/' ) ); ?>">See our approach →</a>
        </article>

        <article class="reveal" style="--d:2">
          <img src="https://images.unsplash.com/photo-1736134869393-bb43683d5d28?auto=format&fit=crop&w=700&q=80" alt="Truck on the highway at night" loading="lazy">
          <span>Results</span>
          <h3>Better calls on the next route.</h3>
          <p>Visibility that cuts waste, shortens response time and protects the margin on every mile you run.</p>
          <a href="<?php echo esc_url( home_url( '/results/' ) ); ?>">See the numbers →</a>
        </article>
      </div>
    </div>
  </section>

  <!-- ── PLATFORM TABS ───────────────────────────────────────── -->
  <section class="section" id="platform">
    <div class="wrap" id="solutionTabs">
      <div class="section-head">
        <div>
          <span class="eyebrow">The EnVue platform</span>
          <h2>Complete control of your operation.</h2>
        </div>
        <p>Built on Geotab, the world’s largest open telematics platform — so it connects to the hardware and software you already run on day one.</p>
      </div>

      <div class="tab-buttons" role="tablist" aria-label="Platform capabilities">
        <button class="active" type="button" role="tab" aria-selected="true" data-tab="cams">AI Dash Cams</button>
        <button type="button" role="tab" aria-selected="false" data-tab="gps">GPS Tracking</button>
        <button type="button" role="tab" aria-selected="false" data-tab="assets">Equipment &amp; Assets</button>
        <button type="button" role="tab" aria-selected="false" data-tab="fuel">Fuel &amp; Maintenance</button>
      </div>

      <div class="tab-panels">
        <article class="tab-panel active" id="tab-cams">
          <img src="https://images.unsplash.com/photo-1744884275743-4b075af04f62?auto=format&fit=crop&w=1100&q=80" alt="AI dash cam recording from a truck cab" loading="lazy">
          <div>
            <span class="number">01 / Safety</span>
            <h3>See every incident before it becomes a claim.</h3>
            <p>Cameras trigger automatically on hard braking, swerving and distracted driving. Exonerating footage reaches your legal team in seconds, not weeks of discovery.</p>
            <ul>
              <li>Automatic event-triggered video on every hard event</li>
              <li>Real-time in-cab distracted driving alerts</li>
              <li>Automated driver scorecards and coaching queues</li>
              <li>31% fewer reportable accidents across deployed fleets</li>
            </ul>
            <a class="text-link" href="<?php echo esc_url( home_url( '/dash-cams/' ) ); ?>">Explore AI dash cams <span>→</span></a>
          </div>
        </article>

        <article class="tab-panel" id="tab-gps">
          <img src="https://images.unsplash.com/photo-1643686978040-beac9782e58b?auto=format&fit=crop&w=1100&q=80" alt="GPS tracking device on a vehicle dashboard" loading="lazy">
          <div>
            <span class="number">02 / Visibility</span>
            <h3>Tracking that turns into action.</h3>
            <p>Live location, geofencing and trip history for every vehicle — plus the reports that make a week of driving legible to someone who wasn’t there.</p>
            <ul>
              <li>Live map with geofence arrival and departure alerts</li>
              <li>Trip history and stop analysis down to the minute</li>
              <li>Idle time reporting by driver, route and yard</li>
              <li>Stolen vehicle recovery with exact location</li>
            </ul>
            <a class="text-link" href="<?php echo esc_url( home_url( '/gps-tracking/' ) ); ?>">Explore GPS tracking <span>→</span></a>
          </div>
        </article>

        <article class="tab-panel" id="tab-assets">
          <img src="https://images.unsplash.com/photo-1534097575056-ddba81f714c8?auto=format&fit=crop&w=1100&q=80" alt="Construction equipment on a job site" loading="lazy">
          <div>
            <span class="number">03 / Assets</span>
            <h3>Visibility beyond the vehicle.</h3>
            <p>Trailers, generators, compressors and machines tracked on the same platform as the trucks that tow them — with utilization data that settles rent-or-buy arguments.</p>
            <ul>
              <li>Powered and non-powered asset trackers</li>
              <li>Utilization reporting per asset and per site</li>
              <li>Theft prevention and after-hours movement alerts</li>
              <li>One inventory across every yard you operate</li>
            </ul>
            <a class="text-link" href="<?php echo esc_url( home_url( '/equipment-management/' ) ); ?>">Explore asset tracking <span>→</span></a>
          </div>
        </article>

        <article class="tab-panel" id="tab-fuel">
          <img src="https://images.unsplash.com/photo-1745956983820-6e960f7e8472?auto=format&fit=crop&w=1100&q=80" alt="Fleet trucks on the highway" loading="lazy">
          <div>
            <span class="number">04 / Cost</span>
            <h3>Stop paying for problems you can see coming.</h3>
            <p>Engine fault codes, fuel card reconciliation and MPG benchmarking turn two of the largest line items in the fleet budget into something you can manage weekly.</p>
            <ul>
              <li>Diagnostic alerts before a breakdown pulls a truck off the road</li>
              <li>Fuel card fraud detection and spend controls</li>
              <li>Per-driver idle cost in dollars, not percentages</li>
              <li>Cost-per-mile benchmarking by vehicle and class</li>
            </ul>
            <a class="text-link" href="<?php echo esc_url( home_url( '/fuel-management/' ) ); ?>">Explore fuel &amp; maintenance <span>→</span></a>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- ── TOOLS ───────────────────────────────────────────────── -->
  <section class="section section--soft">
    <div class="wrap tools-grid">
      <div class="tool-card reveal">
        <span class="eyebrow">Savings estimator</span>
        <h2>Estimate what a connected fleet returns.</h2>

        <label for="fleetRange">Vehicles in your fleet <output id="fleetOutput" for="fleetRange">50</output></label>
        <input id="fleetRange" type="range" min="10" max="500" step="10" value="50">

        <label for="fuelInput">Monthly fuel spend per vehicle</label>
        <div class="money-field">
          <span>$</span>
          <input id="fuelInput" type="number" min="100" step="50" value="1200" aria-label="Monthly fuel spend per vehicle in dollars">
          <small>USD</small>
        </div>

        <div class="saving-result">
          <small>Estimated annual savings</small>
          <strong id="savingTotal">$86,400</strong>
        </div>
        <p class="disclaimer">*Illustrative only, based on a 12% operating reduction from idle control, routing and maintenance alerts. Your actual result depends on your routes, drivers and baseline.</p>
      </div>

      <div class="tool-card reveal" style="--d:1">
        <span class="eyebrow">Video safety</span>
        <h2>From alert to context in seconds.</h2>
        <div class="video-card">
          <div class="video-feed">
            <img src="https://images.unsplash.com/photo-1736134869393-bb43683d5d28?auto=format&fit=crop&w=900&q=80" alt="Dash camera view of a night highway" loading="lazy">
            <span class="record">● REC</span>
            <span class="event" id="safetyEvent">Normal driving</span>
          </div>
          <div class="event-actions">
            <button type="button" class="active" data-event="safe">Normal route</button>
            <button type="button" data-event="brake">Hard brake</button>
            <button type="button" data-event="distracted">Distraction</button>
          </div>
          <p class="coaching" id="coachingMessage">No events. Following distance, speed and lane position are all inside policy — nothing reaches a reviewer.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── ROLLOUT ─────────────────────────────────────────────── -->
  <section class="section">
    <div class="wrap rollout-grid">
      <div class="rollout-copy">
        <span class="eyebrow">Deployment</span>
        <h2>From assessment to full control of the fleet.</h2>
        <p class="lede">A connected system works when the rollout is clear. This is the path your operation follows, from the first review to the quarterly tune-up.</p>
        <div class="rollout-steps" role="tablist" aria-label="Deployment stages">
          <button class="active" type="button" role="tab" aria-selected="true" data-rollout="audit"><span>01</span>Assessment</button>
          <button type="button" role="tab" aria-selected="false" data-rollout="install"><span>02</span>Installation</button>
          <button type="button" role="tab" aria-selected="false" data-rollout="train"><span>03</span>Adoption</button>
          <button type="button" role="tab" aria-selected="false" data-rollout="improve"><span>04</span>Optimization</button>
        </div>
      </div>

      <div class="rollout-panel">
        <span class="panel-label" id="rolloutLabel">Week 01 / Assessment</span>
        <h3 id="rolloutTitle">We learn your operation before anything gets installed.</h3>
        <p id="rolloutText">A review of vehicles, assets, routes, risk exposure and reporting gaps, so the rollout is designed around how your fleet actually runs.</p>
        <div class="rollout-deliverables">
          <div><small>Deliverable</small><strong id="rolloutDeliverable">Fleet needs map</strong></div>
          <div><small>Focus</small><strong id="rolloutFocus">Visibility</strong></div>
          <div><small>Status</small><strong class="ready">Ready</strong></div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── SECTORS ─────────────────────────────────────────────── -->
  <section class="section section--soft">
    <div class="wrap">
      <div class="section-head section-head--compact">
        <div>
          <span class="eyebrow">Industries</span>
          <h2>Built for fleets that keep America moving.</h2>
        </div>
        <a class="text-link" href="<?php echo esc_url( home_url( '/industries/' ) ); ?>">All industries <span>→</span></a>
      </div>

      <div class="sector-cards">
        <a href="<?php echo esc_url( home_url( '/construction/' ) ); ?>">
          <img src="https://images.unsplash.com/photo-1534097575056-ddba81f714c8?auto=format&fit=crop&w=800&q=80" alt="" loading="lazy">
          <span>01</span>
          <h3>Construction &amp; Heavy Equipment</h3>
          <p>Track every machine across sprawling job sites. Stop theft, cut idle, stay on schedule.</p>
        </a>
        <a href="<?php echo esc_url( home_url( '/trucking/' ) ); ?>">
          <img src="https://images.unsplash.com/photo-1745956983820-6e960f7e8472?auto=format&fit=crop&w=800&q=80" alt="" loading="lazy">
          <span>02</span>
          <h3>Trucking &amp; Transportation</h3>
          <p>HOS automation, DOT compliance and video-based liability protection for every haul.</p>
        </a>
        <a href="<?php echo esc_url( home_url( '/field-services/' ) ); ?>">
          <img src="https://images.unsplash.com/photo-1703194531119-e8b98a555cb6?auto=format&fit=crop&w=800&q=80" alt="" loading="lazy">
          <span>03</span>
          <h3>Field Service Operations</h3>
          <p>Dynamic dispatching and technician accountability that turn calls into competitive edge.</p>
        </a>
        <a href="<?php echo esc_url( home_url( '/oil-gas/' ) ); ?>">
          <img src="https://images.unsplash.com/photo-1736134869393-bb43683d5d28?auto=format&fit=crop&w=800&q=80" alt="" loading="lazy">
          <span>04</span>
          <h3>Oil &amp; Gas / Energy</h3>
          <p>Remote tracking, lone worker safety and regulatory compliance for high-stakes field ops.</p>
        </a>
        <a href="<?php echo esc_url( home_url( '/logistics/' ) ); ?>">
          <img src="https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=800&q=80" alt="" loading="lazy">
          <span>05</span>
          <h3>Logistics &amp; Distribution</h3>
          <p>Container-level tracking, dynamic dispatch and terminal visibility at scale.</p>
        </a>
        <a href="<?php echo esc_url( home_url( '/government/' ) ); ?>">
          <img src="https://images.unsplash.com/photo-1643686978040-beac9782e58b?auto=format&fit=crop&w=800&q=80" alt="" loading="lazy">
          <span>06</span>
          <h3>Government &amp; Municipal</h3>
          <p>Public accountability dashboards and compliance automation for city and county fleets.</p>
        </a>
      </div>
    </div>
  </section>

  <!-- ── CUSTOMER STORIES ────────────────────────────────────── -->
  <section class="section">
    <div class="wrap">
      <div class="section-head section-head--compact">
        <div>
          <span class="eyebrow">Customer stories</span>
          <h2>Fleets that made the switch.</h2>
        </div>
        <a class="text-link" href="<?php echo esc_url( home_url( '/results/' ) ); ?>">Read the case studies <span>→</span></a>
      </div>

      <div class="quote-grid">
        <div class="quote-card reveal">
          <blockquote>“When our truck was stolen, we had the exact GPS location within minutes. The vehicle was recovered the same day. That one recovery paid for three years of the platform.”</blockquote>
          <cite><strong>Fleet Manager</strong>Cooper Electric Supply Co.</cite>
        </div>
        <div class="quote-card reveal" style="--d:1">
          <blockquote>“The engine diagnostic alerts caught a failure before it happened. We avoided a $12,000 repair with zero downtime. Predictive maintenance paid for our entire contract.”</blockquote>
          <cite><strong>Operations Director</strong>AGL Welding Supply Co.</cite>
        </div>
        <div class="quote-card reveal" style="--d:2">
          <blockquote>“This isn’t a vendor relationship; it’s a genuine operational partnership. They deployed with us, trained our team, and continue to optimize alongside us every quarter.”</blockquote>
          <cite><strong>CEO</strong>B-4 Transport Company</cite>
        </div>
      </div>
    </div>
  </section>

  <!-- ── INTEGRATIONS ────────────────────────────────────────── -->
  <section class="section section--soft">
    <div class="wrap">
      <div class="section-head section-head--center">
        <div>
          <span class="eyebrow">300+ integrations</span>
          <h2>Connects with everything your team already uses.</h2>
          <p>No rip-and-replace. EnVue plugs directly into your dispatch, ERP, fuel card and camera systems on day one.</p>
        </div>
      </div>
      <div class="feature-trio">
        <div class="reveal">
          <div class="feature-icon" aria-hidden="true">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0H5a2 2 0 0 1-2-2V9m6 12h10a2 2 0 0 0 2-2V9M3 9h18"/></svg>
          </div>
          <h3>Open platform</h3>
          <p>Built on Geotab’s open API, so your data stays yours and connects to the systems you already pay for.</p>
        </div>
        <div class="reveal" style="--d:1">
          <div class="feature-icon" aria-hidden="true">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v4m0 12v4M2 12h4m12 0h4M5 5l2.5 2.5M16.5 16.5 19 19M19 5l-2.5 2.5M7.5 16.5 5 19"/></svg>
          </div>
          <h3>Hardware you can add later</h3>
          <p>Cameras, sensors and trackers plug into the same account as the fleet grows — no second platform, no second login.</p>
        </div>
        <div class="reveal" style="--d:2">
          <div class="feature-icon" aria-hidden="true">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18M7 15l4-4 3 3 5-6"/></svg>
          </div>
          <h3>Reporting that consolidates</h3>
          <p>One set of dashboards across dispatch, fuel, maintenance and safety instead of four exports someone reconciles by hand.</p>
        </div>
      </div>
    </div>
  </section>

</main>

<!-- ── FINAL CTA ─────────────────────────────────────────────── -->
<section class="final-cta" id="demo">
  <div class="wrap final-grid">
    <div>
      <span class="eyebrow eyebrow--light">Next route</span>
      <h2>A more visible fleet starts with one conversation.</h2>
    </div>
    <div>
      <p>Talk to an EnVue specialist about tracking, cameras, assets and deployment for your operation. No scripted pitch — a working session about your fleet.</p>
      <div class="hero-actions">
        <a class="button button-primary button-lg" href="<?php echo esc_url( home_url( '/company/#contact' ) ); ?>">Talk to a specialist <span>→</span></a>
        <a class="button button-ghost button-lg" href="tel:8002011169">Call (800) 201-1169</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
