<?php
/**
 * Centris Theme — functions.php
 * Elementor-compatible, EN/ES bilingual contact center theme.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------------------------------------------------------------
   FORCE REMOVE "01 — In action" SECTION FROM ALL OUTPUT
   Uses simple string search (no regex) to avoid PCRE crashes
--------------------------------------------------------------- */
function centris_remove_in_action_section( $buffer ) {
    // Target the section by its unique text fingerprints
    $needles = [
        'id="in-action"',
        'class="in-action-grid"',
        '01 — In action',
        '01 &mdash; In action',
        'actually sounds like',
        'Centris hears each call as it happens',
    ];

    foreach ( $needles as $needle ) {
        $pos = strpos( $buffer, $needle );
        if ( $pos === false ) continue;

        // Find the opening <section before this needle
        $sec_start = strrpos( substr( $buffer, 0, $pos ), '<section' );
        if ( $sec_start === false ) continue;

        // Find the closing </section> after this needle
        $sec_end = strpos( $buffer, '</section>', $pos );
        if ( $sec_end === false ) continue;
        $sec_end += strlen( '</section>' );

        // Remove that entire section
        $buffer = substr( $buffer, 0, $sec_start ) . substr( $buffer, $sec_end );
        break; // Only one in-action section
    }
    return $buffer;
}
add_action( 'template_redirect', function() {
    ob_start( 'centris_remove_in_action_section' );
}, 0 );

define( 'CENTRIS_VERSION', time() );
define( 'CENTRIS_DIR',     get_template_directory() );
define( 'CENTRIS_URI',     get_template_directory_uri() );

/**
 * Check if Elementor has built the current page.
 */
function centris_is_elementor_page( $post_id = null ) {
    if ( ! $post_id ) $post_id = get_the_ID();
    if ( ! $post_id ) $post_id = get_queried_object_id();
    return get_post_meta( $post_id, '_elementor_edit_mode', true ) === 'builder';
}

/**
 * If this page was built with Elementor, render it and return true.
 */
function centris_render_elementor_and_exit() {
    if ( ! centris_is_elementor_page() ) return false;
    get_header();
    get_template_part( 'inc/nav' );
    echo '<div class="elementor-page-wrap">';
    while ( have_posts() ) { the_post(); the_content(); }
    echo '</div>';
    get_footer();
    return true;
}

/* ---------------------------------------------------------------
   THEME SETUP
--------------------------------------------------------------- */
function centris_setup() {
    load_theme_textdomain( 'centris', CENTRIS_DIR . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'custom-logo', [ 'height' => 80, 'width' => 200, 'flex-height' => true, 'flex-width' => true ] );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'elementor' );
    register_nav_menus( [
        'primary'    => __( 'Primary Navigation', 'centris' ),
        'footer'     => __( 'Footer Navigation',  'centris' ),
        'services'   => __( 'Services Menu',       'centris' ),
        'industries' => __( 'Industries Menu',     'centris' ),
    ] );
}
add_action( 'after_setup_theme', 'centris_setup' );

/* ---------------------------------------------------------------
   ENQUEUE SCRIPTS & STYLES
--------------------------------------------------------------- */
function centris_enqueue_assets() {
    wp_enqueue_style( 'centris-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap',
        [], null );
    wp_enqueue_style( 'centris-styles',
        CENTRIS_URI . '/assets/css/centris.css',
        [ 'centris-fonts' ], CENTRIS_VERSION );
    wp_enqueue_script( 'centris-scripts',
        CENTRIS_URI . '/assets/js/centris-scripts.js',
        [], CENTRIS_VERSION, true );
    wp_localize_script( 'centris-scripts', 'centrisData', [
        'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
        'nonce'       => wp_create_nonce( 'centris_nonce' ),
        'contactPage' => get_page_link( get_page_by_path( 'contact' ) ),
        'siteUrl'     => get_site_url(),
    ] );
}
add_action( 'wp_enqueue_scripts', 'centris_enqueue_assets' );

/* ---------------------------------------------------------------
   ELEMENTOR COMPATIBILITY
--------------------------------------------------------------- */
add_action( 'elementor/init', function() {
    add_filter( 'elementor/utils/get_edit_link', '__return_true' );
} );

function centris_register_elementor_locations( $elementor_theme_manager ) {
    $elementor_theme_manager->register_all_core_location();
    $elementor_theme_manager->register_location( 'header', [ 'label' => __( 'Header', 'centris' ), 'multiple' => false, 'edit_in_content' => false ] );
    $elementor_theme_manager->register_location( 'footer', [ 'label' => __( 'Footer', 'centris' ), 'multiple' => false, 'edit_in_content' => false ] );
    $elementor_theme_manager->register_location( 'single',  [ 'label' => __( 'Single',  'centris' ) ] );
    $elementor_theme_manager->register_location( 'archive', [ 'label' => __( 'Archive', 'centris' ) ] );
}
add_action( 'elementor/theme/register_locations', 'centris_register_elementor_locations' );

/* ---------------------------------------------------------------
   CONTACT FORM AJAX
--------------------------------------------------------------- */
function centris_handle_contact() {
    check_ajax_referer( 'centris_nonce', 'nonce' );
    $name    = sanitize_text_field( $_POST['name']    ?? '' );
    $company = sanitize_text_field( $_POST['company'] ?? '' );
    $email   = sanitize_email(      $_POST['email']   ?? '' );
    $phone   = sanitize_text_field( $_POST['phone']   ?? '' );
    $volume  = sanitize_text_field( $_POST['volume']  ?? '' );
    $message = sanitize_textarea_field( $_POST['message'] ?? '' );
    if ( empty( $name ) || ! is_email( $email ) )
        wp_send_json_error( [ 'message' => __( 'Please provide a valid name and email.', 'centris' ) ] );
    $to      = get_option( 'admin_email' );
    $subject = sprintf( '[Centris Demo Request] %s — %s', $name, $company );
    $body    = sprintf( "Name: %s\nCompany: %s\nEmail: %s\nPhone: %s\nCall Volume: %s\n\nMessage:\n%s", $name, $company, $email, $phone, $volume, $message );
    $headers = [ "Reply-To: $name <$email>", 'Content-Type: text/plain; charset=UTF-8' ];
    $sent = wp_mail( $to, $subject, $body, $headers );
    if ( $sent ) wp_send_json_success( [ 'message' => __( 'Thanks! We\'ll be in touch within one business day.', 'centris' ) ] );
    else         wp_send_json_error(   [ 'message' => __( 'Something went wrong. Please email us directly.', 'centris' ) ] );
}
add_action( 'wp_ajax_centris_contact',        'centris_handle_contact' );
add_action( 'wp_ajax_nopriv_centris_contact', 'centris_handle_contact' );

/* ---------------------------------------------------------------
   WIDGET AREAS
--------------------------------------------------------------- */
function centris_widgets_init() {
    register_sidebar( [ 'name' => __( 'Footer — Column 1', 'centris' ), 'id' => 'footer-col-1', 'before_widget' => '<div class="footer-widget">', 'after_widget' => '</div>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>' ] );
    register_sidebar( [ 'name' => __( 'Footer — Column 2', 'centris' ), 'id' => 'footer-col-2', 'before_widget' => '<div class="footer-widget">', 'after_widget' => '</div>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>' ] );
}
add_action( 'widgets_init', 'centris_widgets_init' );

/* ---------------------------------------------------------------
   TITLE TAG
--------------------------------------------------------------- */
add_filter( 'pre_get_document_title', function( $title ) {
    if ( is_home() || is_front_page() ) return 'Centris — Bilingual Contact Center Solutions Powered by AI';
    return $title . ' — Centris';
} );

/* ---------------------------------------------------------------
   REMOVE EMOJI BLOAT
--------------------------------------------------------------- */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

/* ---------------------------------------------------------------
   EXCERPT
--------------------------------------------------------------- */
add_filter( 'excerpt_length', fn() => 30 );
add_filter( 'excerpt_more',   fn() => '…' );

/* ---------------------------------------------------------------
   ELEMENTOR: disable default fonts/colors
--------------------------------------------------------------- */
add_action( 'elementor/init', function() {
    if ( defined( 'ELEMENTOR_VERSION' ) ) {
        update_option( 'elementor_disable_color_schemes',      'yes' );
        update_option( 'elementor_disable_typography_schemes', 'yes' );
    }
} );

/* ---------------------------------------------------------------
   SETUP WIZARD
--------------------------------------------------------------- */
require_once CENTRIS_DIR . '/inc/setup-wizard.php';

/* ---------------------------------------------------------------
   PAGE ROUTING
--------------------------------------------------------------- */
function centris_page_template( $template ) {
    if ( ! is_page() ) return $template;
    $post_id = get_queried_object_id();
    if ( get_post_meta( $post_id, '_elementor_edit_mode', true ) === 'builder' ) return $template;
    if ( isset( $_GET['elementor-preview'] ) || ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) ) return $template;
    $slug = get_post_field( 'post_name', $post_id );
    $map  = [
        'about' => 'template-pages/page-about.php', 'services' => 'template-pages/page-services.php',
        'industries' => 'template-pages/page-industries.php', 'contact' => 'template-pages/page-contact.php',
        'case-studies' => 'template-pages/page-case-studies.php', 'resources' => 'template-pages/page-resources.php',
        'ai-call-center' => 'template-pages/services/page-ai-call-center.php',
        'customer-support' => 'template-pages/services/page-customer-support.php',
        'bpo' => 'template-pages/services/page-bpo.php', 'inbound-sales' => 'template-pages/services/page-inbound-sales.php',
        'live-chat' => 'template-pages/services/page-live-chat.php',
        'marketing-surveys' => 'template-pages/services/page-marketing-surveys.php',
        'quality-assurance' => 'template-pages/services/page-quality-assurance.php',
        'soft-collections' => 'template-pages/services/page-soft-collections.php',
        'tier-1-tech' => 'template-pages/services/page-tier-1-tech.php',
        'finance' => 'template-pages/industries/page-finance.php',
        'healthcare' => 'template-pages/industries/page-healthcare.php',
        'insurance' => 'template-pages/industries/page-insurance.php',
        'retail' => 'template-pages/industries/page-retail.php',
        'security' => 'template-pages/industries/page-security.php',
        'utilities' => 'template-pages/industries/page-utilities.php',
    ];
    if ( isset( $map[ $slug ] ) ) {
        $path = CENTRIS_DIR . '/' . $map[ $slug ];
        if ( file_exists( $path ) ) return $path;
    }
    return $template;
}
add_filter( 'template_include', 'centris_page_template' );

/* ---------------------------------------------------------------
   AUTO-CREATE PAGES ON ACTIVATION
--------------------------------------------------------------- */
function centris_create_pages() {
    if ( get_option( 'centris_pages_created' ) ) return;
    $pages = [
        [ 'title' => 'Home', 'slug' => 'home', 'parent' => 0 ],
        [ 'title' => 'About', 'slug' => 'about', 'parent' => 0 ],
        [ 'title' => 'Services', 'slug' => 'services', 'parent' => 0 ],
        [ 'title' => 'Industries', 'slug' => 'industries', 'parent' => 0 ],
        [ 'title' => 'Contact', 'slug' => 'contact', 'parent' => 0 ],
        [ 'title' => 'Case Studies', 'slug' => 'case-studies', 'parent' => 0 ],
        [ 'title' => 'Resources', 'slug' => 'resources', 'parent' => 0 ],
    ];
    $services_page_id = 0; $industries_page_id = 0; $home_id = 0;
    foreach ( $pages as $p ) {
        if ( get_page_by_path( $p['slug'] ) ) {
            if ( $p['slug'] === 'home' ) $home_id = get_page_by_path('home')->ID;
            if ( $p['slug'] === 'services' ) $services_page_id = get_page_by_path('services')->ID;
            if ( $p['slug'] === 'industries' ) $industries_page_id = get_page_by_path('industries')->ID;
            continue;
        }
        $id = wp_insert_post( [ 'post_title' => $p['title'], 'post_name' => $p['slug'], 'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '' ] );
        if ( $p['slug'] === 'services' )   $services_page_id   = $id;
        if ( $p['slug'] === 'industries' ) $industries_page_id = $id;
        if ( $p['slug'] === 'home' )       $home_id            = $id;
    }
    $service_children = [ 'AI Call Center' => 'ai-call-center', 'Customer Support' => 'customer-support', 'BPO' => 'bpo', 'Inbound Sales' => 'inbound-sales', 'Live Chat' => 'live-chat', 'Marketing Surveys' => 'marketing-surveys', 'Quality Assurance' => 'quality-assurance', 'Soft Collections' => 'soft-collections', 'Tier 1 Tech Support' => 'tier-1-tech' ];
    if ( ! $services_page_id ) { $sp = get_page_by_path('services'); $services_page_id = $sp ? $sp->ID : 0; }
    foreach ( $service_children as $title => $slug ) {
        if ( get_page_by_path( $slug ) ) continue;
        wp_insert_post( [ 'post_title' => $title, 'post_name' => $slug, 'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '', 'post_parent' => $services_page_id ] );
    }
    $industry_children = [ 'Finance' => 'finance', 'Healthcare' => 'healthcare', 'Insurance' => 'insurance', 'Retail' => 'retail', 'Security' => 'security', 'Utilities' => 'utilities' ];
    if ( ! $industries_page_id ) { $ip = get_page_by_path('industries'); $industries_page_id = $ip ? $ip->ID : 0; }
    foreach ( $industry_children as $title => $slug ) {
        if ( get_page_by_path( $slug ) ) continue;
        wp_insert_post( [ 'post_title' => $title, 'post_name' => $slug, 'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '', 'post_parent' => $industries_page_id ] );
    }
    // Set homepage to front-page.php by setting a static front page
    if ( $home_id ) {
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $home_id );
    }
    update_option( 'centris_pages_created', true );
}
add_action( 'after_switch_theme', 'centris_create_pages' );
add_action( 'init', 'centris_create_pages' );
