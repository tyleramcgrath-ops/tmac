<?php
get_header();
if ( function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'single' ) ) {
    // Elementor Pro
} else {
    while ( have_posts() ) : the_post(); ?>
    <main class="wrap" style="padding: 8rem 1.5rem; max-width: 52rem; margin: 0 auto; min-height: 60vh;">
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header style="margin-bottom: 3rem;">
                <p class="meta" style="font-family: var(--mono); font-size: 11px; text-transform: uppercase; letter-spacing: 0.2em; color: rgba(255,255,255,0.4); margin-bottom: 1rem;">
                    <?php echo get_the_date(); ?> · <?php the_category( ', ' ); ?>
                </p>
                <h1 style="font-family: var(--serif); font-size: clamp(2rem,4vw,3rem); color: white; margin: 0; line-height: 1.1; letter-spacing: -0.02em;">
                    <?php the_title(); ?>
                </h1>
            </header>
            <div class="entry-content" style="color: var(--muted); font-size: 16px; line-height: 1.8;">
                <?php the_content(); ?>
            </div>
        </article>
    </main>
    <?php endwhile;
}
get_footer();
