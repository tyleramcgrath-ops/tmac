<?php
/**
 * Centris Theme — Setup Wizard
 * Shows a one-time admin notice with setup instructions after activation.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function centris_activation_notice() {
    if ( get_option( 'centris_setup_done' ) ) return;
    ?>
    <div class="notice notice-info is-dismissible" style="border-left-color:#ff4650; padding: 16px;">
        <h3 style="margin: 0 0 8px; color: #1d2327;">🚀 Centris Theme Activated</h3>
        <p style="margin: 0 0 12px;">Your Centris theme is ready. Here's your quick-start checklist:</p>
        <ol style="margin: 0 0 12px; padding-left: 20px;">
            <li><strong>Set your homepage:</strong> Settings → Reading → Static page → select "Front Page"</li>
            <li><strong>Install Elementor:</strong> <a href="<?php echo admin_url('plugin-install.php?s=elementor&tab=search&type=term'); ?>">Install Elementor</a> (free) for visual editing</li>
            <li><strong>Set admin email:</strong> Settings → General → Administration Email Address (receives demo requests)</li>
            <li><strong>Upload logo:</strong> Appearance → Customize → Site Identity</li>
            <li><strong>Create pages:</strong> Services, Industries, About, Contact (Elementor builds these visually)</li>
        </ol>
        <p><a href="<?php echo admin_url('options-reading.php'); ?>" class="button button-primary" style="background:#ff4650; border-color:#ff4650;">Configure Homepage →</a>
        &nbsp;<a href="<?php echo admin_url('admin.php?page=centris_dismiss_notice'); ?>" class="button">Dismiss</a></p>
    </div>
    <?php
}
add_action( 'admin_notices', 'centris_activation_notice' );

function centris_dismiss_notice_handler() {
    if ( isset( $_GET['page'] ) && $_GET['page'] === 'centris_dismiss_notice' ) {
        update_option( 'centris_setup_done', true );
        wp_redirect( admin_url() );
        exit;
    }
}
add_action( 'admin_init', 'centris_dismiss_notice_handler' );
