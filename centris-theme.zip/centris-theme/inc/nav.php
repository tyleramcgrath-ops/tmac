<?php
/**
 * Centris — Shared navigation header (used by every page template).
 * English-only, dark theme fixed, no lang/theme toggles.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="scroll-progress" aria-hidden="true"><div class="scroll-progress-bar" id="scrollBar"></div></div>
<header class="nav">
  <div class="nav-inner">
    <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris">
      <?php if ( has_custom_logo() ): the_custom_logo(); else: ?>
      <img src="data:image/webp;base64,UklGRuYHAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCCCBAAA8B4AnQEqpgA0AD4xFolCoiEhFLu2UCADBLEDFAIEB+AH6AfwBpAH4AW9Z2l4Owrr35KfwD/AfEDaH7B96P3A/yXxr7hWsv8Z+UX+V+cPor+zP3Bv0H/vP5edwrzDfo3+wHvM/3P/R+uB6iP9J/gHo3ey76EH6eeld+4Pwiftd+3nsh/9HOQP6B2bQADGAf3D7ANVN+wDXbvsA+JScR/g39v/Tb/qf0/kM/0ACxnBoJtgTeYQx8xQO4raMRk3dbbGoIqiEaNtHDMZ4f5M3c1r7YLSElzTS+kxlC4/f4tpJZnhqcolQZl697yRkufA6O/wv+/fFuex6MTv31rVz8mtwAD+/JDwz83N2+JsHB+oy2XGP/JC/Ned8HAAw4o5s8TJIgy/Cx2zo6lRGhugPKVSevPAzM+88sEqxkkK6hqQYZzQARdC0BtnHBBZmMX0RV895/4Kpa9y/HsoWbONUvTx2+FQO3AewGp0LxOJtnPLXS59h4he2rn75bf5KDgOMTwRDMXwppJ1FddBfC+toJSm1lAriTi8dFEM/5y7XaPlhT99AUg//yw/XtS7AwGNMWNftKqtZpElAA///bKJLWbD1NDDOc+Mqf/njT1RZR6M9ZDGsmfFoeON/MHGi5nZN0hFvHecp0pn/6VbrtmIkSlfMljPJvzDQctqzteZkkGCQMxns4O4k405JWVPVYTCw5BWOQNkJm6Aai2b2azTrEANfrLxTLvEqmtYmV5TGJPCOS2Irf/tlKVIdrHCs3AV4BVTfCREjo5lhPWlkV3m3zZD6Ln0kQVcfia2BKjxp0tnTHDTzc2UXTzgYmCk1S/6fF8ooHwZr0hFUETmImX0/UjHEjjZlXfCrEz0W4hNeiw9t2EyT27wsgPrKVT3dmxmCmIelQxAZVCOigXro7xh4rKDBaxgHBiRhJ3tEzBEF8iR2l0WiosH/6kWLm7Dupxwivu2FvDybJ8Yq1RQ4/qRmBdzWsHEUYtwfUJIna8eJseNk4wAc8Qxc1gtfj2UxP1XyMFyu/Auu8ZFcN8hDxtVeD3r3LWbpVFs86m8vjInt4qCw9LKlp7VV+KE6S5BzhJeuhArTTEAzJBvc1iax3Fu5M1wo7uEl58FAPgxlOuKSMPHdh0vGA8c/lYWinyqRyvCXEj5ahQJAo+GlEnlW76FXhrYJy8SvKu/WArI/SKQ537Gn77SQ9/++qN147B85GyBEsSJLCiMLUQ6q+jZOQa6wwhkYPIhBStwa9mEz4fKkZEyFJ6VDSTS/bld5B9RGLUQCp7yUYfeuxmmSKOVCQ90qmo9koMBNYZVqIcBbDOsajRbcWcGm9lORuaHXjo02uqoFzLR+3AtX//8xI2qC1PWMJpwAUSNYmvhCsTy6r/r8Fqt9v/nKPaMRvYbVaTz0Oy1owtnaTyynw/VTZiZj95fZRn2ThkxzhbMgTY3uxO2gN4YZz6sUftcFLOiTANn/94dUMUI5Ev5TPaQAlXFRP/1gQ6S7gRIVEfdJ9pzCABdBuAQVh5Cl+bXnrArRIopOOnUkAAAAAA=" alt="Centris" style="height:36px;width:auto;display:block;filter:none;" />
      <?php endif; ?>
    </a>
    <nav class="nav-links" aria-label="Main navigation">
      <span class="has-dropdown"><a href="<?php echo home_url('/services/'); ?>">Services</a>
        <div class="nav-dropdown" role="menu">
          <a href="<?php echo home_url('/services/ai-call-center/'); ?>"><span class="num">01</span>AI Call Center</a>
          <a href="<?php echo home_url('/services/customer-support/'); ?>"><span class="num">02</span>Customer Support</a>
          <a href="<?php echo home_url('/services/bpo/'); ?>"><span class="num">03</span>Business Process Outsourcing</a>
          <a href="<?php echo home_url('/services/inbound-sales/'); ?>"><span class="num">04</span>Inbound Sales</a>
          <a href="<?php echo home_url('/services/live-chat/'); ?>"><span class="num">05</span>Live Chat</a>
          <a href="<?php echo home_url('/services/marketing-surveys/'); ?>"><span class="num">06</span>Marketing Surveys</a>
          <a href="<?php echo home_url('/services/quality-assurance/'); ?>"><span class="num">07</span>Quality Assurance</a>
          <a href="<?php echo home_url('/services/soft-collections/'); ?>"><span class="num">08</span>Soft Collections</a>
          <a href="<?php echo home_url('/services/tier-1-tech/'); ?>"><span class="num">09</span>Tier 1 Tech Support</a>
          <a class="all-link" href="<?php echo home_url('/services/'); ?>">View all services</a>
        </div>
      </span>
      <span class="has-dropdown"><a href="<?php echo home_url('/industries/'); ?>">Industries</a>
        <div class="nav-dropdown" role="menu">
          <a href="<?php echo home_url('/industries/insurance/'); ?>">Insurance</a>
          <a href="<?php echo home_url('/industries/healthcare/'); ?>">Healthcare</a>
          <a href="<?php echo home_url('/industries/retail/'); ?>">Retail &amp; E-commerce</a>
          <a href="<?php echo home_url('/industries/security/'); ?>">Security</a>
          <a href="<?php echo home_url('/industries/utilities/'); ?>">Utilities</a>
          <a href="<?php echo home_url('/industries/finance/'); ?>">Finance</a>
          <a class="all-link" href="<?php echo home_url('/industries/'); ?>">View all industries</a>
        </div>
      </span>
      <a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a>
      <a href="<?php echo home_url('/about/'); ?>">About</a>
      <a href="<?php echo home_url('/resources/'); ?>">Resources</a>
    </nav>
    <div class="nav-tools">
      <a class="cta-primary sm" href="<?php echo home_url('/contact/'); ?>">Book a demo
        <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </a>
    </div>
  </div>
</header>
