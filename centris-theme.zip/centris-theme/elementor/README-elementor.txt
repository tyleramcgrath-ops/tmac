CENTRIS THEME — ELEMENTOR USAGE GUIDE
======================================

The Centris theme is fully compatible with Elementor Free and Elementor Pro.

HOW THE HOMEPAGE WORKS
-----------------------
The homepage (front-page.php) renders the complete Centris landing page
automatically — NO Elementor setup required to get a pixel-perfect result.

All interactive features work out of the box:
  • Live metrics ticker
  • Sophia AI demo (play/pause scenarios: insurance, healthcare, billing, sales)
  • Voice playback via Web Speech API
  • ROI Calculator with live sliders
  • Coverage map (Monterrey / Aguascalientes pins)
  • Services grid with 3D tilt effect
  • FAQ accordion
  • EN/ES language toggle
  • Dark/light theme toggle
  • Scroll progress bar
  • Floating Sophia chat widget
  • Animated counters on scroll
  • Contact form with WordPress AJAX handler

EDITING WITH ELEMENTOR
-----------------------
1. Install Elementor (free version from wordpress.org/plugins)
2. Go to Pages → Front Page → Edit with Elementor
3. Use the HTML widget to edit any section, OR
4. Use Elementor's Custom CSS panel to override styles

For section-level editing, each section has an ID you can target:
  #in-action    — Sophia AI demo section
  #services     — Services grid
  #roi          — ROI Calculator
  #industries   — Industry cards
  #why          — Why Centris section
  #coverage     — Map section
  #cases        — Case studies
  #faq          — FAQ accordion
  #contact      — Contact/demo booking form

ELEMENTOR PRO — THEME BUILDER
------------------------------
With Elementor Pro, you can:
1. Create a Header template to replace the built-in nav
2. Create a Footer template to replace the built-in footer
3. Build inner pages (Services, Industries, About) visually

Go to: Templates → Theme Builder → Add New

COLORS (add these to Elementor's Global Colors)
-------------------------------------------------
  Background Dark:    #02041a
  Background Card:    #060c44
  Text Primary:       #f5f6ff
  Text Muted:         rgba(245,246,255,0.60)
  Blue Accent:        #0017ff
  Blue Mid:           #3a4cff
  Blue Light:         #7a86ff
  Coral/CTA:          #ff4650
  Coral Soft:         #ff8a91
  Emerald/Success:    #34d399

FONTS (add these to Elementor's Global Fonts)
----------------------------------------------
  Primary: Inter (Google Fonts)
  Monospace: JetBrains Mono (Google Fonts)

CONTACT FORM
------------
The contact form at the bottom submits via WordPress AJAX to admin email.
To change the recipient: Settings → General → Administration Email Address

For advanced forms, install WPForms or Contact Form 7 and replace the
#contactForm HTML in the front-page.php with your shortcode.

INNER PAGES
-----------
The theme includes page.php for standard WordPress pages.
Create pages for: Services, Industries, About, Contact, Case Studies
Elementor can build these fully from scratch.

SUPPORT
-------
Theme version: 1.0.0
Built by: Centris Engineering Team
