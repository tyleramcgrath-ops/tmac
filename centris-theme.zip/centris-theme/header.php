<!doctype html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Centris delivers dedicated bilingual contact center teams powered by Sophia AI — real-time transcription, sentiment analysis, and auto-scored QA. Nearshore in Monterrey and Aguascalientes." />
  <meta property="og:title" content="Centris — Bilingual Contact Center Solutions" />
  <meta property="og:description" content="Human-first AI for contact centers. EN/ES bilingual agents, Sophia AI assistant, up to 45% cost savings." />
  <meta property="og:type" content="website" />
  <meta name="theme-color" content="#02041a" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
