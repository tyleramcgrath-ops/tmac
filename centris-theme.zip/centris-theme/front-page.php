<?php
get_header();
if ( centris_render_elementor_and_exit() ) return;
?>
<?php get_template_part('inc/nav'); ?>
<!-- LIVE METRICS TICKER -->
    <div class="ticker" aria-label="Live operations metrics">
      <div class="ticker-inner">
        <span class="ticker-dot"></span>
        <span class="ticker-label">Live</span>
        <div class="ticker-track">
          <div class="ticker-items">
            <span>Calls handled today · <b id="tk-calls">12,847</b></span>
            <span>Avg sentiment · <b id="tk-sent">+0.42</b></span>
            <span>QA coverage · <b>100%</b></span>
            <span>Avg handle time · <b id="tk-aht">4m 12s</b></span>
            <span>Bilingual agents online · <b id="tk-agents">1,284</b></span>
            <span>First-call resolution · <b>91.3%</b></span>
            <span>Calls handled today · <b>12,847</b></span>
            <span>Avg sentiment · <b>+0.42</b></span>
            <span>QA coverage · <b>100%</b></span>
            <span>Avg handle time · <b>4m 12s</b></span>
            <span>Bilingual agents online · <b>1,284</b></span>
            <span>First-call resolution · <b>91.3%</b></span>
          </div>
        </div>
      </div>
    </div>
    <!-- HERO with real photo background -->
    <section class="hero">
      <div class="hero-bg-photo">
        <img src="<?php echo CENTRIS_URI; ?>/assets/images/centris-hero.webp" alt="Centris bilingual customer service professional powered by AI" />
      </div>
      <div class="hero-bg"><div class="grid-sweep"></div></div>
      <div class="hero-grid">
        <div>
          <p class="meta reveal r1">Say hello to Centris</p>
          <h1 class="reveal r2"><span>Leader in Contact Center Solutions,</span><br /><span class="accent">Built for a Human-First AI Future.</span></h1>
          <p class="hero-sub reveal r4">For more than 30 years, Centris has provided dedicated bilingual contact center teams that operate as a seamless extension of the organizations we support. Our agents deliver consistent, professional service powered by Sophia — our in-call AI assistant — strengthening customer relationships, improving efficiency, and helping your business grow with confidence.</p>
          <div class="hero-ctas reveal r5">
            <a class="cta-primary md" href="#contact">Book a demo
              <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
            <a class="cta-quiet" href="#roi"><u>See your ROI</u>
              <svg class="ico" viewBox="0 0 24 24" style="transform:translateY(-1px)"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg></a>
          </div>
        </div>
        <div class="hero-stats reveal r5">
          <div class="stat"><span class="n">Up to <span class="italic">45<span class="small">%</span></span></span><span class="lbl">savings versus<br />U.S.-based contact centers</span></div>
          <div class="stat"><span class="n"><span class="italic">30<span class="small">+</span></span></span><span class="lbl">years delivering<br />nearshore contact-center work</span></div>
          <div class="stat"><span class="n"><span class="italic">5<span class="small">k+</span></span></span><span class="lbl">happy customers<br />across North America</span></div>
          <div class="stat"><span class="n"><span class="italic">2</span></span><span class="lbl">nearshore locations<br />Monterrey · Aguascalientes</span></div>
        </div>
      </div>
    </section>

        <!-- INDUSTRY TRUST STRIP -->
    <section class="logos border-t">
      <p class="logos-label">Trusted across insurance, healthcare, retail, security &amp; more</p>
      <div class="industry-trust-grid">
        <a href="<?php echo home_url('/industries/insurance/'); ?>" class="itg-card"><span class="itg-icon">🏥</span><span class="itg-name">Insurance</span></a>
        <a href="<?php echo home_url('/industries/healthcare/'); ?>" class="itg-card"><span class="itg-icon">💊</span><span class="itg-name">Healthcare</span></a>
        <a href="<?php echo home_url('/industries/retail/'); ?>" class="itg-card"><span class="itg-icon">🛍</span><span class="itg-name">Retail</span></a>
        <a href="<?php echo home_url('/industries/security/'); ?>" class="itg-card"><span class="itg-icon">🔒</span><span class="itg-name">Security</span></a>
        <a href="<?php echo home_url('/industries/utilities/'); ?>" class="itg-card"><span class="itg-icon">⚡</span><span class="itg-name">Utilities</span></a>
        <a href="<?php echo home_url('/industries/finance/'); ?>" class="itg-card"><span class="itg-icon">💳</span><span class="itg-name">Finance</span></a>
      </div>
    </section>

    <!-- AI CAPABILITIES PILLARS -->
    <section class="section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">00 — How it works</p>
          <h2>Four AI pillars<br /><span class="accent">behind every conversation.</span></h2>
          <p>Sophia is more than a transcript engine. She listens, reads the room, suggests the next move, and scores every interaction — in real time, bilingually.</p>
        </div>
        <div class="ai-pillars">
          <div class="pillar ir"><span class="pn">01</span><h3>Real-time transcription</h3><p>Every word captured, in English and Spanish, with sub-second latency. Full record, every call, every channel.</p><div class="footer">EN · ES · LIVE</div></div>
          <div class="pillar ir"><span class="pn">02</span><h3>Sentiment analysis</h3><p>Live read on tone — frustrated, recovering, advocating — surfaced as the call moves. Coaching becomes specific, not vibes.</p><div class="footer">−1.0 to +1.0 · realtime</div></div>
          <div class="pillar ir"><span class="pn">03</span><h3>Sophia, your assistant</h3><p>Suggests the right line, the right policy, the right escalation. Agents stay in control. Accept, rewrite, or skip.</p><div class="footer">conf 0.94 avg</div></div>
          <div class="pillar ir"><span class="pn">04</span><h3>Auto-scored QA</h3><p>AI and machine learning score every interaction across every channel. No sampling, no surprises, no missed coaching moments.</p><div class="footer">100% coverage</div></div>
        </div>
      </div>
    </section>

    <!-- IN ACTION — interactive demo -->

    <!-- WORKFLOW -->
    <section class="section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">02 — Handoff</p>
          <h2><span class="accent">AI handles the load.</span><br/>Humans handle the moment.</h2>
          <p>A live call moves through five steps. AI does what AI is good at; trained bilingual agents do what humans are good at. Neither replaces the other — they hand off in milliseconds.</p>
        </div>
        <div class="workflow-steps">
          <div class="wf-step ai ir"><div class="wf-num">01</div><span class="who">AI</span><h4>Listen</h4><p>Sophia transcribes the call — EN/ES — and detects tone, intent, and language shift.</p></div>
          <div class="wf-step ai ir"><div class="wf-num">02</div><span class="who">AI</span><h4>Analyze</h4><p>Pull customer history, relevant policy, prior contacts, and sentiment trajectory in under a second.</p></div>
          <div class="wf-step ai ir"><div class="wf-num">03</div><span class="who">AI</span><h4>Suggest</h4><p>Surface the next line, the right offer, the right escalation — with a confidence score.</p></div>
          <div class="wf-step human ir"><div class="wf-num">04</div><span class="who">Human</span><h4>Decide</h4><p>The agent stays in their voice. Accept, rewrite, or take the call somewhere only a human can.</p></div>
          <div class="wf-step ai ir"><div class="wf-num">05</div><span class="who">AI</span><h4>Document</h4><p>The CRM note writes itself. Sentiment shift, action items, language preference — logged before the call ends.</p></div>
        </div>
      </div>
    </section>

    <!-- SERVICES -->
    <section id="services" class="section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">03 — Services</p>
          <h2>Bilingual support teams,<br /><span class="accent">across every channel.</span></h2>
          <p>Centris delivers human expertise and AI-driven efficiency in one package — helping organizations improve service quality, reduce costs, and scale operations without compromise.</p>
        </div>
        <div class="svc-grid">
          <a class="svc-card ir" href="<?php echo home_url('/services/ai-call-center/'); ?>" data-tilt>
            <div class="svc-img" style="color: #6674FF; background: linear-gradient(135deg, #1a1f5c 0%, #060c44 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <defs><radialGradient id="ai1" cx="50%" cy="50%"><stop offset="0%" stop-color="#6674FF" stop-opacity="0.6"/><stop offset="100%" stop-color="#6674FF" stop-opacity="0"/></radialGradient></defs>
                <circle cx="200" cy="100" r="80" fill="url(#ai1)"/>
                <g stroke="#6674FF" stroke-width="1" fill="none" opacity="0.6">
                  <line x1="80" y1="60" x2="200" y2="100"/><line x1="200" y1="100" x2="320" y2="60"/>
                  <line x1="200" y1="100" x2="80" y2="140"/><line x1="200" y1="100" x2="320" y2="140"/>
                  <line x1="80" y1="60" x2="80" y2="140"/><line x1="320" y1="60" x2="320" y2="140"/>
                  <line x1="200" y1="40" x2="200" y2="100"/><line x1="200" y1="100" x2="200" y2="160"/>
                </g>
                <g fill="#6674FF"><circle cx="80" cy="60" r="4"/><circle cx="320" cy="60" r="4"/><circle cx="80" cy="140" r="4"/><circle cx="320" cy="140" r="4"/><circle cx="200" cy="40" r="4"/><circle cx="200" cy="160" r="4"/></g>
                <circle cx="200" cy="100" r="10" fill="#FF4650"/>
                <circle cx="200" cy="100" r="18" fill="none" stroke="#FF4650" stroke-width="1" opacity="0.5"><animate attributeName="r" values="10;30;10" dur="3s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.6;0;0.6" dur="3s" repeatCount="indefinite"/></circle>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">01</span>
            <div class="svc-corner"><span class="dot live"></span></div>
            <div class="svc-body">
              <h3>AI Call Center</h3>
              <p>Where humans are powered by AI. Centris blends AI efficiency with real bilingual agents to deliver smarter, more empathetic customer care — at the speed of live conversation.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/customer-support/'); ?>" data-tilt>
            <div class="svc-img" style="color: #FF8A91; background: linear-gradient(135deg, #4a1620 0%, #060c44 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <g fill="none" stroke="#FF4650" stroke-width="1.5" opacity="0.5">
                  <circle cx="200" cy="100" r="30"/><circle cx="200" cy="100" r="55"/><circle cx="200" cy="100" r="80"/><circle cx="200" cy="100" r="105"/>
                </g>
                <path d="M 60 100 Q 100 60 140 100 T 220 100 T 300 100 T 380 100" fill="none" stroke="#FF8A91" stroke-width="2" opacity="0.8"/>
                <circle cx="200" cy="100" r="14" fill="#FF4650"/>
                <circle cx="200" cy="100" r="6" fill="white"/>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">02</span>
            <div class="svc-corner"><span class="dot"></span><span class="dot"></span></div>
            <div class="svc-body">
              <h3>Customer Support</h3>
              <p>Nearshore bilingual support across voice, chat, and email. Our agents work as a seamless extension of your team, in your tone, on your hours.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/bpo/'); ?>" data-tilt>
            <div class="svc-img" style="color: #34d399; background: linear-gradient(135deg, #073227 0%, #060c44 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <g fill="#34d399" opacity="0.4">
                  <rect x="40" y="80" width="20" height="40" rx="2"/><rect x="80" y="60" width="20" height="80" rx="2"/><rect x="120" y="40" width="20" height="120" rx="2"/><rect x="160" y="70" width="20" height="60" rx="2"/><rect x="200" y="50" width="20" height="100" rx="2"/><rect x="240" y="65" width="20" height="70" rx="2"/><rect x="280" y="45" width="20" height="110" rx="2"/><rect x="320" y="75" width="20" height="50" rx="2"/><rect x="360" y="55" width="20" height="90" rx="2"/>
                </g>
                <g fill="#34d399"><rect x="120" y="40" width="20" height="120" rx="2"/><rect x="200" y="50" width="20" height="100" rx="2"/><rect x="280" y="45" width="20" height="110" rx="2"/></g>
                <line x1="20" y1="180" x2="380" y2="180" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">03</span>
            <div class="svc-corner"><span class="dot"></span></div>
            <div class="svc-body">
              <h3>Business Process Outsourcing</h3>
              <p>Skilled teams in Mexico take on the back-office work that slows you down — so your in-house operation can focus on the work only you can do.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/inbound-sales/'); ?>" data-tilt>
            <div class="svc-img" style="color: #34d399; background: linear-gradient(135deg, #0c2f24 0%, #0017ff 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <defs><linearGradient id="up1" x1="0%" y1="100%" x2="0%" y2="0%"><stop offset="0%" stop-color="#34d399" stop-opacity="0"/><stop offset="100%" stop-color="#34d399" stop-opacity="0.5"/></linearGradient></defs>
                <path d="M 20 160 L 80 130 L 140 140 L 200 90 L 260 70 L 320 40 L 380 30 L 380 200 L 20 200 Z" fill="url(#up1)"/>
                <polyline points="20,160 80,130 140,140 200,90 260,70 320,40 380,30" fill="none" stroke="#34d399" stroke-width="2.5"/>
                <g fill="#34d399"><circle cx="80" cy="130" r="3"/><circle cx="140" cy="140" r="3"/><circle cx="200" cy="90" r="3"/><circle cx="260" cy="70" r="3"/><circle cx="320" cy="40" r="3"/><circle cx="380" cy="30" r="5" stroke="white" stroke-width="2"/></g>
                <text x="350" y="22" font-family="JetBrains Mono" font-size="11" fill="#34d399" font-weight="500">+38%</text>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">04</span>
            <div class="svc-corner"><span class="dot live"></span></div>
            <div class="svc-body">
              <h3>Inbound Sales</h3>
              <p>Increase customer retention, lift conversion, win market share. Our teams handle the moment your customer's ready to buy — in either language.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/live-chat/'); ?>" data-tilt>
            <div class="svc-img" style="color: #7a86ff; background: linear-gradient(135deg, #1a1f7c 0%, #4a1620 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <g><rect x="40" y="40" width="180" height="60" rx="20" fill="#6674FF" opacity="0.85"/><circle cx="60" cy="115" r="3" fill="#6674FF"/><circle cx="72" cy="115" r="3" fill="#6674FF"/><circle cx="84" cy="115" r="3" fill="#6674FF"/></g>
                <g><rect x="180" y="120" width="200" height="60" rx="20" fill="#FF4650" opacity="0.9"/><circle cx="370" cy="105" r="3" fill="#FF4650"/><circle cx="358" cy="105" r="3" fill="#FF4650"/><circle cx="346" cy="105" r="3" fill="#FF4650"/></g>
                <text x="55" y="76" font-family="Inter" font-size="14" fill="white" font-weight="500">Hi! Can you help?</text>
                <text x="195" y="156" font-family="Inter" font-size="14" fill="white" font-weight="500">Absolutely — here for you.</text>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">05</span>
            <div class="svc-corner"><span class="dot live"></span></div>
            <div class="svc-body">
              <h3>Live Chat</h3>
              <p>A personalized approach to building rapport, optimized for retention. Steal share from competitors who can't match the same level of care.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/marketing-surveys/'); ?>" data-tilt>
            <div class="svc-img" style="color: #FF4650; background: linear-gradient(135deg, #4a2810 0%, #060c44 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <g fill="#FF4650"><circle cx="50" cy="50" r="4" opacity="0.3"/><circle cx="100" cy="80" r="6" opacity="0.6"/><circle cx="150" cy="40" r="3" opacity="0.4"/><circle cx="200" cy="100" r="8"/><circle cx="250" cy="60" r="5" opacity="0.7"/><circle cx="300" cy="90" r="4" opacity="0.5"/><circle cx="350" cy="50" r="3" opacity="0.3"/><circle cx="80" cy="140" r="5" opacity="0.5"/><circle cx="160" cy="160" r="7" opacity="0.7"/><circle cx="240" cy="150" r="4" opacity="0.4"/><circle cx="320" cy="130" r="6" opacity="0.6"/></g>
                <g stroke="#FF8A91" stroke-width="1" fill="none" opacity="0.3"><line x1="100" y1="80" x2="200" y2="100"/><line x1="200" y1="100" x2="250" y2="60"/><line x1="200" y1="100" x2="160" y2="160"/><line x1="200" y1="100" x2="300" y2="90"/></g>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">06</span>
            <div class="svc-corner"><span class="dot"></span></div>
            <div class="svc-body">
              <h3>Marketing Surveys</h3>
              <p>Let your customers tell you what they want directly. Real conversations, structured insight — fuel for the next product, the next campaign, the next quarter.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/quality-assurance/'); ?>" data-tilt>
            <div class="svc-img" style="color: #34d399; background: linear-gradient(135deg, #0a2438 0%, #060c44 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <g fill="none" stroke="#34d399" stroke-width="1.5"><polygon points="200,40 240,65 240,115 200,140 160,115 160,65" opacity="0.4"/><polygon points="200,60 225,75 225,105 200,120 175,105 175,75" opacity="0.7"/></g>
                <text x="200" y="105" text-anchor="middle" font-family="Inter" font-size="22" fill="white" font-weight="700">97</text>
                <text x="200" y="125" text-anchor="middle" font-family="JetBrains Mono" font-size="9" fill="#34d399" letter-spacing="2">SCORE</text>
                <g stroke="#34d399" stroke-width="2" fill="none" opacity="0.5"><path d="M 80 170 Q 120 165 160 160"/><path d="M 240 160 Q 280 165 320 170"/></g>
                <g fill="#34d399"><circle cx="80" cy="170" r="3"/><circle cx="320" cy="170" r="3"/></g>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">07</span>
            <div class="svc-corner"><span class="dot live"></span><span class="dot"></span></div>
            <div class="svc-body">
              <h3>Quality Assurance</h3>
              <p>AI and machine learning capture, transcribe, and score every interaction — across every channel. No sampling, no surprises, no missed coaching moments.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/soft-collections/'); ?>" data-tilt>
            <div class="svc-img" style="color: #FF8A91; background: linear-gradient(135deg, #3a1818 0%, #060c44 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <g fill="none" stroke="#FF8A91" stroke-width="1" opacity="0.4">
                  <path d="M 80 100 Q 200 30 320 100 Q 200 170 80 100"/>
                  <path d="M 110 100 Q 200 50 290 100 Q 200 150 110 100"/>
                  <path d="M 140 100 Q 200 70 260 100 Q 200 130 140 100"/>
                </g>
                <g><path d="M 175 100 Q 175 85 200 85 Q 225 85 225 100 Q 225 115 215 120 L 215 130 L 185 130 L 185 120 Q 175 115 175 100" fill="#FF4650" opacity="0.9"/></g>
                <text x="200" y="108" text-anchor="middle" font-family="Inter" font-size="11" fill="white" font-weight="600">care</text>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">08</span>
            <div class="svc-corner"><span class="dot"></span></div>
            <div class="svc-body">
              <h3>Soft Collections</h3>
              <p>A sensitive, respectful approach to debt recovery that protects the customer relationship while moving the balance. Empathy at scale.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>

          <a class="svc-card ir" href="<?php echo home_url('/services/tier-1-tech/'); ?>" data-tilt>
            <div class="svc-img" style="color: #0017ff; background: linear-gradient(135deg, #060c44 0%, #1a1f7c 100%);">
              <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
                <g stroke="#7a86ff" stroke-width="1.5" fill="none" opacity="0.5"><path d="M 40 60 L 120 60 L 120 100 L 200 100 L 200 60 L 280 60 L 280 140 L 360 140"/><path d="M 40 140 L 100 140 L 100 100 L 160 100"/><path d="M 240 40 L 240 80 L 320 80 L 320 120"/></g>
                <g fill="#6674FF"><rect x="36" y="56" width="8" height="8"/><rect x="116" y="96" width="8" height="8"/><rect x="196" y="56" width="8" height="8"/><rect x="276" y="56" width="8" height="8"/><rect x="356" y="136" width="8" height="8"/><rect x="36" y="136" width="8" height="8"/><rect x="156" y="96" width="8" height="8"/><rect x="236" y="36" width="8" height="8"/><rect x="316" y="116" width="8" height="8"/></g>
                <circle cx="200" cy="100" r="22" fill="rgba(255,69,80,0.15)" stroke="#FF4650" stroke-width="1.5"/>
                <text x="200" y="106" text-anchor="middle" font-family="JetBrains Mono" font-size="10" fill="#FF4650" font-weight="500">T1</text>
              </svg>
              <div class="glow"></div><div class="scan"></div>
            </div>
            <span class="svc-num">09</span>
            <div class="svc-corner"><span class="dot live"></span></div>
            <div class="svc-body">
              <h3>Tier 1 Tech Support</h3>
              <p>A first line of defense that actually solves the problem. Our agents are trained in your product and your tone — so the customer never has to wait for a human to call back.</p>
              <span class="svc-cta">Learn more <svg class="ico" viewBox="0 0 24 24" style="width:14px;height:14px;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
            </div>
          </a>
        </div>
      </div>
    </section>

    <!-- QA BUNDLE -->
    <section class="section qa-section border-t">
      <div class="wrap">
        <div class="qa-grid">
          <div>
            <div class="sec-head ir">
              <p class="meta">04 — Centris Unified QA Management</p>
              <h2>Live QA, meet <span class="italic accent">Sophia.</span></h2>
              <p>A complete software suite for modernizing quality assurance in contact centers — with our in-call AI assistant Sophia at the core. Real-time transcription, sentiment, suggestions, and automated CRM notes, in one bundle.</p>
            </div>
            <ul class="qa-features">
              <li class="ir"><span class="dot"></span><div><span class="lbl">Real-time transcription.</span><span class="desc">Every word captured, in English and Spanish, with sub-second latency.</span></div></li>
              <li class="ir"><span class="dot"></span><div><span class="lbl">Sentiment analysis.</span><span class="desc">Live read on tone — frustrated, recovering, advocating — surfaced as the call moves.</span></div></li>
              <li class="ir"><span class="dot"></span><div><span class="lbl">Sophia, your in-call assistant.</span><span class="desc">Suggests the right line, the right policy, the right escalation. Agents stay in control.</span></div></li>
              <li class="ir"><span class="dot"></span><div><span class="lbl">Automated CRM notes.</span><span class="desc">The note's written before the call ends. No after-call wrap-up.</span></div></li>
              <li class="ir"><span class="dot"></span><div><span class="lbl">Score every conversation.</span><span class="desc">Rubrics applied in real time, not on 3% sampled after the fact.</span></div></li>
            </ul>
          </div>
          <div class="dashboard ir" style="background: linear-gradient(180deg, rgba(8,12,38,0.95) 0%, rgba(4,8,28,0.98) 100%);">
            <div class="dash-bar">
              <div class="dots"><span></span><span></span><span></span></div>
              <span class="title">QA Dashboard · This week</span>
              <span class="right"><span>live</span><span class="live"></span></span>
            </div>
            <div class="dash-body">
              <div class="dash-row">
                <span class="ttl">Volume scored — last 7 days</span>
                <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;align-items:end;height:96px;">
                  <div style="height:38%;background:linear-gradient(180deg,var(--blue-3),var(--blue-2));border-radius:3px;"></div>
                  <div style="height:52%;background:linear-gradient(180deg,var(--blue-3),var(--blue-2));border-radius:3px;"></div>
                  <div style="height:48%;background:linear-gradient(180deg,var(--blue-3),var(--blue-2));border-radius:3px;"></div>
                  <div style="height:66%;background:linear-gradient(180deg,var(--blue-3),var(--blue-2));border-radius:3px;"></div>
                  <div style="height:72%;background:linear-gradient(180deg,var(--blue-3),var(--blue-2));border-radius:3px;"></div>
                  <div style="height:88%;background:linear-gradient(180deg,var(--coral-soft),var(--coral));border-radius:3px;"></div>
                  <div style="height:96%;background:linear-gradient(180deg,var(--coral-soft),var(--coral));border-radius:3px;box-shadow:0 0 20px rgba(255,69,80,0.4);"></div>
                </div>
              </div>
              <div class="dash-signals" style="grid-template-columns:repeat(2,1fr);">
                <div class="signal"><div class="lbl">Average QA score</div><div class="val up">94<span style="font-size:0.55em;color:var(--muted);">%</span></div></div>
                <div class="signal"><div class="lbl">Sentiment shift</div><div class="val up">+0.21</div></div>
                <div class="signal"><div class="lbl">Calls scored</div><div class="val">12.4<span style="font-size:0.55em;color:var(--muted);">k</span></div></div>
                <div class="signal"><div class="lbl">Coverage</div><div class="val">100<span style="font-size:0.55em;color:var(--muted);">%</span></div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ANIMATED COUNTERS -->
    <section class="counters border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">By the numbers</p>
          <h2>Thirty years.<br /><span class="accent">Five thousand customers. One mission.</span></h2>
        </div>
        <div class="counter-grid ir" id="counterGrid" style="margin-top: 3rem;">
          <div class="counter"><div class="n"><span data-count="30" data-suffix="+">0</span></div><div class="l"><b>Years</b> · Of bilingual contact center expertise</div></div>
          <div class="counter"><div class="n"><span data-count="5" data-suffix="K+">0</span></div><div class="l"><b>Customers</b> · Across North America</div></div>
          <div class="counter"><div class="n"><span data-count="45"><span></span></span><span class="suf">%</span></div><div class="l"><b>Cost savings</b> · Versus U.S.-based centers</div></div>
          <div class="counter"><div class="n"><span data-count="100"><span></span></span><span class="suf">%</span></div><div class="l"><b>QA coverage</b> · Every call, every channel, every day</div></div>
        </div>
      </div>
    </section>

    <!-- ROI CALCULATOR -->
    <section id="roi" class="section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">05 — Calculator</p>
          <h2>See your savings,<br /><span class="accent">in about ten seconds.</span></h2>
          <p>Move the sliders. Nearshore Mexico typically costs 40–50% less than U.S. centers on a fully-loaded basis, and AI-assisted QA covers 100% of calls instead of the 2–3% manual sample. Numbers update live.</p>
        </div>
        <div class="roi-wrap ir">
          <div class="roi-inputs">
            <div class="roi-field">
              <div class="roi-field-head"><label for="roi-vol">Monthly call volume</label><span class="v" id="roi-vol-v">25,000</span></div>
              <input id="roi-vol" type="range" min="2000" max="200000" step="1000" value="25000" />
            </div>
            <div class="roi-field">
              <div class="roi-field-head"><label for="roi-aht">Avg handle time (min)</label><span class="v" id="roi-aht-v">6.5</span></div>
              <input id="roi-aht" type="range" min="2" max="15" step="0.5" value="6.5" />
            </div>
            <div class="roi-field">
              <div class="roi-field-head"><label for="roi-rate">Current cost / call ($)</label><span class="v" id="roi-rate-v">$7.20</span></div>
              <input id="roi-rate" type="range" min="2" max="20" step="0.10" value="7.20" />
            </div>
            <div class="roi-field">
              <div class="roi-field-head"><label for="roi-mix">% bilingual (Spanish)</label><span class="v" id="roi-mix-v">35%</span></div>
              <input id="roi-mix" type="range" min="0" max="100" step="5" value="35" />
            </div>
          </div>
          <div class="roi-out">
            <p class="meta">Estimated impact · year one</p>
            <div class="big" id="roi-savings">$648,000<span class="unit">/ yr saved</span></div>
            <p class="sub">vs. running the same volume on a U.S.-based or single-language center. Includes labor, real estate, tech stack, QA coverage gains.</p>
            <div class="roi-breakdown">
              <div class="roi-line"><span class="k">Current annual spend</span><span class="v" id="roi-current">$2.16M</span></div>
              <div class="roi-line"><span class="k">Centris annual spend</span><span class="v" id="roi-new">$1.51M</span></div>
              <div class="roi-line"><span class="k">QA coverage gain</span><span class="v" id="roi-qa">+97 pts</span></div>
              <div class="roi-line total"><span class="k">Net savings</span><span class="v" id="roi-total">$648K · 30%</span></div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- INDUSTRIES with photos -->
    <section id="industries" class="section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">06 — Industries</p>
          <h2>Built for the conversations<br /><span class="accent">your industry actually has.</span></h2>
          <p>From a stressed customer filing a claim to a patient navigating a self-service portal — the conversation is the brand. We've spent three decades learning yours.</p>
        </div>
        <div class="industries">
          <a href="<?php echo home_url('/industries/insurance/'); ?>" class="industry ir">
            <div class="pic"><img src="https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=720&q=80&auto=format&fit=crop" alt="Insurance" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="body"><span class="ind-num">01 / Insurance</span><h3>When the day's already bad,<br />we make the next ten minutes better.</h3><p>If you're in an accident, filing a claim is stressful. Our agents are trained to walk customers swiftly through the process — empathetically, accurately, in either language.</p><span class="more">→ Read more</span></div>
          </a>
          <a href="<?php echo home_url('/industries/healthcare/'); ?>" class="industry ir">
            <div class="pic"><img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=720&q=80&auto=format&fit=crop" alt="Healthcare" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="body"><span class="ind-num">02 / Healthcare</span><h3>Patients deserve more<br />than self-help portals.</h3><p>Patient Advocacy, RCM, Soft Collections, Scheduling — supported by bilingual agents trained in HIPAA-compliant workflows.</p><span class="more">→ Read more</span></div>
          </a>
          <a href="<?php echo home_url('/industries/retail/'); ?>" class="industry ir">
            <div class="pic"><img src="https://images.unsplash.com/photo-1556742044-3c52d6e88c62?w=720&q=80&auto=format&fit=crop" alt="Retail" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="body"><span class="ind-num">03 / Retail & E-commerce</span><h3>Impeccable customer service,<br />any channel they choose.</h3><p>Voice, live chat, email — your customers reach you wherever they are. We help retail and e-commerce brands keep that experience consistent and on-brand.</p><span class="more">→ Read more</span></div>
          </a>
          <a href="<?php echo home_url('/industries/security/'); ?>" class="industry ir">
            <div class="pic"><img src="https://images.unsplash.com/photo-1558002038-1055907df827?w=720&q=80&auto=format&fit=crop" alt="Security" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="body"><span class="ind-num">04 / Security</span><h3>Peace of mind, on call.</h3><p>Customers trust the security industry with what matters most. We hold up that promise with bilingual agents trained to triage and escalate with calm precision.</p><span class="more">→ Read more</span></div>
          </a>
          <a href="<?php echo home_url('/industries/utilities/'); ?>" class="industry ir">
            <div class="pic"><img src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=720&q=80&auto=format&fit=crop" alt="Utilities" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="body"><span class="ind-num">05 / Utilities</span><h3>Reliability goes beyond<br />the line itself.</h3><p>In utilities, being there when it matters most isn't a slogan — it's the brand. Centris keeps that promise live, in two languages, through outages and ordinary days alike.</p><span class="more">→ Read more</span></div>
          </a>
          <a href="<?php echo home_url('/industries/'); ?>" class="industry ir">
            <div class="pic"><img src="https://images.unsplash.com/photo-1556761175-b413da4baf72?w=720&q=80&auto=format&fit=crop" alt="More industries" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="body"><span class="ind-num">06 / Plus</span><h3>Finance · Restaurant · Waste<br />Warranty · Parking</h3><p>We also serve fast-casual restaurants, finance, waste management, warranty & claims operations, and parking operators.</p><span class="more">→ All industries</span></div>
          </a>
        </div>
      </div>
    </section>

    <!-- WHY NEARSHORE -->
    <section id="why" class="section border-t">
      <div class="wrap">
        <div class="why-simple-grid ir">
          <div class="why-stat-col">
            <div class="savings-block">
              <h3 class="savings-big">45<span class="pct">%</span></h3>
              <p class="savings-tag">average savings vs. U.S. contact centers</p>
            </div>
          </div>
          <div class="why-copy-col">
            <p class="meta">07 — Why Centris</p>
            <h2>As close to the U.S. as you can be<br /><span class="accent">without being in the U.S.</span></h2>
            <ul class="why-bullets">
              <li><strong>Bilingual by default</strong> — English and Spanish at native quality.</li>
              <li><strong>Same time zones</strong> — your customers, agents, and supervisors on the same clock.</li>
              <li><strong>30+ years of partnership</strong> — real playbooks, not just marketing.</li>
            </ul>
          </div>
        </div>
        <!-- Two location photos full-width -->
        <div class="loc-full-grid ir" style="margin-top:3rem;">
          <p class="meta" style="margin:0 0 1.25rem;text-transform:uppercase;letter-spacing:0.2em;font-size:11px;color:var(--quiet);">Two nearshore locations</p>
          <div class="loc-photo-grid">
            <a href="<?php echo home_url('/about/'); ?>" class="loc-photo-card" style="background-image:url('<?php echo CENTRIS_URI; ?>/assets/images/monterrey.webp');">
              <div class="loc-photo-overlay">
                <span class="loc-photo-sub">Nuevo León · MX · Center 01</span>
                <span class="loc-photo-name">Monterrey</span>
              </div>
            </a>
            <a href="<?php echo home_url('/about/'); ?>" class="loc-photo-card" style="background-image:url('<?php echo CENTRIS_URI; ?>/assets/images/aguascalientes.webp');">
              <div class="loc-photo-overlay">
                <span class="loc-photo-sub">Aguascalientes · MX · Center 02</span>
                <span class="loc-photo-name">Aguascalientes</span>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- CASE STUDIES with photos -->
    <section id="cases" class="section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">09 — Case studies</p>
          <h2>What it means<br /><span class="accent">to partner with Centris.</span></h2>
          <p>The numbers behind the relationships. Real outcomes, real customers, written up so you can see the work — not just the marketing.</p>
        </div>
        <div class="cases">
          <a href="<?php echo home_url('/case-studies/'); ?>" class="case ir">
            <div class="case-pic"><img src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=900&q=80&auto=format&fit=crop" alt="Healthcare" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="case-body">
              <span class="lbl">Healthcare technology & services</span>
              <span class="stat">100%<span class="small">Hispanic market support coverage</span></span>
              <h3>They needed Hispanic market support.<br />They got a partner.</h3>
              <p>A healthcare technology and services firm came to us to extend Spanish-language patient support. Three years later, Centris also handles Patient Advocacy, RCM follow-up, and QA scoring.</p>
              <span class="read">Read the case study →</span>
            </div>
          </a>
          <a href="<?php echo home_url('/case-studies/'); ?>" class="case ir">
            <div class="case-pic"><img src="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=900&q=80&auto=format&fit=crop" alt="Auto insurance" onerror="this.style.display='none'" loading="lazy"/></div>
            <div class="case-body">
              <span class="lbl">Auto insurance</span>
              <span class="stat">50%<span class="small">reduction in customer service cost</span></span>
              <h3>Half the cost.<br />A better experience.</h3>
              <p>This auto insurance company cut customer service spend by 50% after outsourcing to Centris — while measurably improving NPS, claim handling time, and Spanish-language coverage.</p>
              <span class="read">Read the case study →</span>
            </div>
          </a>
        </div>
      </div>
    </section>


    <!-- FAQ -->
    <section id="faq" class="section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">11 — FAQ</p>
          <h2>Questions we get<br /><span class="accent">before every kickoff.</span></h2>
          <p>Direct answers — no sales theater. If something here doesn't match your situation, the demo conversation is the right place to dig in.</p>
        </div>
        <div class="faq ir">
          <div class="faq-item open">
            <button class="faq-q" aria-expanded="true">How fast can we go live? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>Pilot programs typically launch in 30–45 days from signed agreement: weeks 1–2 are knowledge transfer and call-flow design, weeks 3–4 are agent training and shadowing, week 5 is soft launch with QA double-coverage. Full ramp to target volume usually takes 60–90 days.</p></div>
          </div>
          <div class="faq-item">
            <button class="faq-q" aria-expanded="false">What does pricing look like? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>Most engagements are per-hour FTE or per-call, depending on volume predictability. Expect 40–50% below comparable U.S. centers fully loaded. Pilots start at 10–25 seats; enterprise programs scale to 500+. Use the calculator above for a directional number, then we tighten it with your actual call mix.</p></div>
          </div>
          <div class="faq-item">
            <button class="faq-q" aria-expanded="false">How do you handle data security and compliance? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>SOC 2 Type II, HIPAA, PCI-DSS, and GDPR-aligned. PII never leaves controlled environments; recordings and transcripts are encrypted at rest and in transit. Sophia AI runs on isolated tenant infrastructure with full audit trails. We're happy to walk through the controls matrix during procurement review.</p></div>
          </div>
          <div class="faq-item">
            <button class="faq-q" aria-expanded="false">Will AI replace the human agents? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>No. Sophia listens, drafts, and recommends — the human decides. The model is augmentation: AI handles knowledge retrieval, sentiment tracking, real-time translation cues, and post-call QA so agents can focus on the conversation. Customers still talk to a person.</p></div>
          </div>
          <div class="faq-item">
            <button class="faq-q" aria-expanded="false">What languages do you cover? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>English and Spanish (Mexican and U.S. Hispanic markets) are native across both centers. Sophia adds real-time translation cues for 30+ additional languages on demand. All agents are fully bilingual EN/ES; we don't run language tiers.</p></div>
          </div>
          <div class="faq-item">
            <button class="faq-q" aria-expanded="false">Can you integrate with our CRM and telephony? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>Yes. Standard integrations include Salesforce, Zendesk, HubSpot, ServiceNow, Genesys, NICE CXone, Five9, AWS Connect, and Twilio Flex. Custom CRMs connect via REST/webhook in roughly two weeks. We don't ask you to switch tools.</p></div>
          </div>
          <div class="faq-item">
            <button class="faq-q" aria-expanded="false">How is quality measured? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>Sophia auto-scores 100% of calls on adherence, empathy, resolution, and compliance — versus the typical 2–3% manual sample. Human QA analysts review flagged calls and coach against trends weekly. You get a live dashboard plus a weekly digest.</p></div>
          </div>
          <div class="faq-item">
            <button class="faq-q" aria-expanded="false">What happens if we want to leave? <span class="plus" aria-hidden="true"></span></button>
            <div class="faq-a"><p>Standard contracts are annual with 90-day notice. Transition support includes knowledge artifacts, call recordings (where contractually retained), and a structured handover playbook. No exit fees, no hostage hardware.</p></div>
          </div>
        </div>
      </div>
    </section>

    <!-- COMPLIANCE STRIP -->
    <section class="compliance">
      <div class="wrap">
        <div class="compliance-row ir">
          <div class="compliance-label"><b>Certified &amp; audited.</b><br />Independent third-party attestation, refreshed annually.</div>
          <div class="compliance-badges">
            <div class="badge"><span class="b-name">SOC 2 · Type II</span><span class="b-desc">Security · Availability · Confidentiality</span></div>
            <div class="badge"><span class="b-name">HIPAA</span><span class="b-desc">Healthcare PHI handling · BAA available</span></div>
            <div class="badge"><span class="b-name">PCI-DSS</span><span class="b-desc">Level 1 service provider · pause-resume</span></div>
            <div class="badge"><span class="b-name">GDPR</span><span class="b-desc">EU data protection · DPA on file</span></div>
          </div>
        </div>
      </div>
    </section>

    <!-- CLOSING -->
    <section id="contact" class="closing border-t">
      <h2 class="ir">Want to learn more about<br /><span class="accent">outsourcing your contact center?</span></h2>
      <p class="ir">Fill out the form on our contact page and we'll get in touch ASAP. Plus, we'll send you our guide to moving contact center operations to Mexico — what works, what doesn't, and what the first 90 days actually look like.</p>
      <div class="ctas ir">
        <a class="cta-primary lg" href="#contact">Book a 15-minute demo
          <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
        <a class="cta-quiet" href="tel:18005304897"><u>Or call 1-800-530-4897</u>
          <svg class="ico" viewBox="0 0 24 24" style="transform:translateY(-1px)"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg></a>
      </div>
    </section>

    <!-- FOOTER -->
    <footer>
      <div class="foot">
        <div class="foot-brand">
          <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><?php if ( has_custom_logo() ): the_custom_logo(); else: ?><img src="data:image/webp;base64,UklGRuYHAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCCCBAAA8B4AnQEqpgA0AD4xFolCoiEhFLu2UCADBLEDFAIEB+AH6AfwBpAH4AW9Z2l4Owrr35KfwD/AfEDaH7B96P3A/yXxr7hWsv8Z+UX+V+cPor+zP3Bv0H/vP5edwrzDfo3+wHvM/3P/R+uB6iP9J/gHo3ey76EH6eeld+4Pwiftd+3nsh/9HOQP6B2bQADGAf3D7ANVN+wDXbvsA+JScR/g39v/Tb/qf0/kM/0ACxnBoJtgTeYQx8xQO4raMRk3dbbGoIqiEaNtHDMZ4f5M3c1r7YLSElzTS+kxlC4/f4tpJZnhqcolQZl697yRkufA6O/wv+/fFuex6MTv31rVz8mtwAD+/JDwz83N2+JsHB+oy2XGP/JC/Ned8HAAw4o5s8TJIgy/Cx2zo6lRGhugPKVSevPAzM+88sEqxkkK6hqQYZzQARdC0BtnHBBZmMX0RV895/4Kpa9y/HsoWbONUvTx2+FQO3AewGp0LxOJtnPLXS59h4he2rn75bf5KDgOMTwRDMXwppJ1FddBfC+toJSm1lAriTi8dFEM/5y7XaPlhT99AUg//yw/XtS7AwGNMWNftKqtZpElAA///bKJLWbD1NDDOc+Mqf/njT1RZR6M9ZDGsmfFoeON/MHGi5nZN0hFvHecp0pn/6VbrtmIkSlfMljPJvzDQctqzteZkkGCQMxns4O4k405JWVPVYTCw5BWOQNkJm6Aai2b2azTrEANfrLxTLvEqmtYmV5TGJPCOS2Irf/tlKVIdrHCs3AV4BVTfCREjo5lhPWlkV3m3zZD6Ln0kQVcfia2BKjxp0tnTHDTzc2UXTzgYmCk1S/6fF8ooHwZr0hFUETmImX0/UjHEjjZlXfCrEz0W4hNeiw9t2EyT27wsgPrKVT3dmxmCmIelQxAZVCOigXro7xh4rKDBaxgHBiRhJ3tEzBEF8iR2l0WiosH/6kWLm7Dupxwivu2FvDybJ8Yq1RQ4/qRmBdzWsHEUYtwfUJIna8eJseNk4wAc8Qxc1gtfj2UxP1XyMFyu/Auu8ZFcN8hDxtVeD3r3LWbpVFs86m8vjInt4qCw9LKlp7VV+KE6S5BzhJeuhArTTEAzJBvc1iax3Fu5M1wo7uEl58FAPgxlOuKSMPHdh0vGA8c/lYWinyqRyvCXEj5ahQJAo+GlEnlW76FXhrYJy8SvKu/WArI/SKQ537Gn77SQ9/++qN147B85GyBEsSJLCiMLUQ6q+jZOQa6wwhkYPIhBStwa9mEz4fKkZEyFJ6VDSTS/bld5B9RGLUQCp7yUYfeuxmmSKOVCQ90qmo9koMBNYZVqIcBbDOsajRbcWcGm9lORuaHXjo02uqoFzLR+3AtX//8xI2qC1PWMJpwAUSNYmvhCsTy6r/r8Fqt9v/nKPaMRvYbVaTz0Oy1owtnaTyynw/VTZiZj95fZRn2ThkxzhbMgTY3uxO2gN4YZz6sUftcFLOiTANn/94dUMUI5Ev5TPaQAlXFRP/1gQ6S7gRIVEfdJ9pzCABdBuAQVh5Cl+bXnrArRIopOOnUkAAAAAA=" alt="Centris" class="centris-logo" style="height:36px;width:auto;display:block;filter:none;" /><?php endif; ?></a>
          <p>Centris Information Services &mdash; bilingual nearshore contact center solutions, built for a human-first AI future.</p>
          <div class="foot-social">
            <a href="https://facebook.com/centrisinfo" aria-label="Facebook"><svg class="ico" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
            <a href="https://linkedin.com/company/centris-information-services" aria-label="LinkedIn"><svg class="ico" viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a href="https://x.com/centrisinfo" aria-label="X"><svg class="ico" viewBox="0 0 24 24"><path d="M18 4 6 20M6 4l12 16"/></svg></a>
          </div>
        </div>
        <div class="foot-col"><h4>Services</h4><ul>
          <li><a href="<?php echo home_url('/services/ai-call-center/'); ?>">AI Call Center</a></li>
          <li><a href="<?php echo home_url('/services/customer-support/'); ?>">Customer Support</a></li>
          <li><a href="<?php echo home_url('/services/bpo/'); ?>">Business Process Outsourcing</a></li>
          <li><a href="<?php echo home_url('/services/inbound-sales/'); ?>">Inbound Sales</a></li>
          <li><a href="<?php echo home_url('/services/live-chat/'); ?>">Live Chat</a></li>
          <li><a href="<?php echo home_url('/services/marketing-surveys/'); ?>">Marketing Surveys</a></li>
          <li><a href="<?php echo home_url('/services/quality-assurance/'); ?>">Quality Assurance</a></li>
          <li><a href="<?php echo home_url('/services/soft-collections/'); ?>">Soft Collections</a></li>
          <li><a href="<?php echo home_url('/services/tier-1-tech/'); ?>">Tier 1 Tech Support</a></li>
        </ul></div>
        <div class="foot-col"><h4>Industries</h4><ul>
          <li><a href="<?php echo home_url('/industries/insurance/'); ?>">Insurance</a></li>
          <li><a href="<?php echo home_url('/industries/healthcare/'); ?>">Healthcare</a></li>
          <li><a href="<?php echo home_url('/industries/retail/'); ?>">Retail &amp; E-commerce</a></li>
          <li><a href="<?php echo home_url('/industries/security/'); ?>">Security</a></li>
          <li><a href="<?php echo home_url('/industries/utilities/'); ?>">Utilities</a></li>
          <li><a href="<?php echo home_url('/industries/finance/'); ?>">Finance</a></li>
          <li><a href="<?php echo home_url('/industries/'); ?>">View all industries</a></li>
        </ul></div>
        <div class="foot-col">
          <h4>Contact</h4>
          <ul>
            <li><a href="tel:18005304897">1-800-530-4897</a></li>
            <li><a href="mailto:kudos@centrisinfo.com">kudos@centrisinfo.com</a></li>
            <li style="color: var(--muted); font-size: 14px;">119 W. Tyler St., Suite 260<br/>Longview, TX 75601</li>
          </ul>
          <h4 style="margin-top:1.75rem;">Resources</h4>
          <ul>
            <li><a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Whitepapers</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Industry Events</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="foot-meta">
        <span>&copy; 2026 Centris Information Services</span>
        <span>Human-first AI for contact centers</span>
      </div>
    </footer>

    <!-- FLOATING SOPHIA CHAT WIDGET -->
    <button class="sophia-fab" id="sophiaFab" aria-label="Open Sophia chat">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
      <span class="fab-dot"></span>
    </button>
    <div class="sophia-panel" id="sophiaPanel" role="dialog" aria-label="Sophia assistant">
      <div class="sp-head">
        <div class="sp-avatar">S</div>
        <div class="sp-meta"><div class="n">Sophia</div><div class="s">Online · Bilingual</div></div>
        <button class="sp-close" id="sophiaClose" aria-label="Close"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="sp-msgs" id="sophiaMsgs">
        <div class="sp-msg bot">Hi! I'm Sophia, the AI behind Centris contact centers. Ask me about pricing, ramp time, or what AI-assisted QA actually looks like.</div>
      </div>
      <div class="sp-quick" id="sophiaQuick">
        <button data-q="How fast can we go live?">Ramp time</button>
        <button data-q="What does pricing look like?">Pricing</button>
        <button data-q="How is quality measured?">Quality / QA</button>
        <button data-q="What languages do you cover?">Languages</button>
      </div>
      <form class="sp-input" id="sophiaForm">
        <input type="text" id="sophiaInput" placeholder="Ask Sophia anything..." autocomplete="off" />
        <button type="submit" aria-label="Send"><svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
      </form>
    </div>

    

<?php get_footer(); ?>
