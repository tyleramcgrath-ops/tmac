<?php get_header(); ?>
<main class="wrap" style="padding: 12rem 1.5rem; text-align: center; min-height: 70vh;">
    <p class="meta" style="font-family: var(--mono); font-size: 11px; text-transform: uppercase; letter-spacing: 0.2em; color: rgba(255,255,255,0.5); margin-bottom: 1.5rem;">
        404 — Page not found
    </p>
    <h1 style="font-family: var(--serif); font-weight: 700; font-size: clamp(2.5rem,6vw,5rem); color: white; margin: 0 0 1.5rem; letter-spacing: -0.03em;">
        Nothing here.
    </h1>
    <p style="color: var(--muted); font-size: 16px; margin: 0 0 2.5rem;">
        The page you're looking for doesn't exist or has moved.
    </p>
    <a href="<?php echo home_url('/'); ?>" class="cta-primary md">
        Back to home
        <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
    </a>
</main>
<?php get_footer(); ?>
