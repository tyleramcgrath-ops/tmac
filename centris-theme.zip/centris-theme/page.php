<?php
/**
 * Default page template — renders Elementor content when present,
 * falls back to standard WordPress loop otherwise.
 */
get_header();
get_template_part('inc/nav');

if ( function_exists('elementor_theme_do_location') && elementor_theme_do_location('single') ) {
    // Elementor Pro Theme Builder handles full output
} else {
    while ( have_posts() ) :
        the_post();

        // Elementor Free: the_content() outputs Elementor-rendered HTML
        $is_elementor = get_post_meta( get_the_ID(), '_elementor_edit_mode', true ) === 'builder';

        if ( $is_elementor ) {
            // Full-width Elementor canvas — no padding wrapper
            echo '<div class="elementor-page-wrap">';
            the_content();
            echo '</div>';
        } else {
            // Standard WordPress page content
            ?>
            <main class="wrap" style="padding: 8rem 1.5rem; min-height: 60vh;">
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h1 style="font-family: var(--serif); font-size: clamp(2rem,4vw,3.25rem); color: white; margin: 0 0 2rem;">
                        <?php the_title(); ?>
                    </h1>
                    <div class="entry-content" style="color: var(--muted); font-size: 16px; line-height: 1.75; max-width: 48rem;">
                        <?php the_content(); ?>
                    </div>
                </article>
            </main>
            <?php
        }
    endwhile;
}

get_footer();
