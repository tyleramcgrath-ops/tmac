<?php
/**
 * Default page template.
 * Elementor will override this for any page built with the page builder.
 */
get_header();

if ( function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'single' ) ) {
    // Elementor Pro theme builder handles the output
} else {
    // Fallback: plain WordPress loop
    while ( have_posts() ) :
        the_post();
        ?>
        <main class="wrap" style="padding: 8rem 1.5rem; min-height: 60vh;">
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <h1 style="font-family: var(--serif); font-size: clamp(2rem,4vw,3.25rem); color: white; margin: 0 0 2rem;">
                    <?php the_title(); ?>
                </h1>
                <div class="entry-content" style="color: var(--muted); font-size: 16px; line-height: 1.75; max-width: 48rem;">
                    <?php the_content(); ?>
                </div>
            </article>
        </main>
        <?php
    endwhile;
}

get_footer();
