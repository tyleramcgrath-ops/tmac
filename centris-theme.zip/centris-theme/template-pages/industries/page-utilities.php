<?php
/**
 * Template Name: Centris — Utilities
 * Centris Utilities page.
 */

// SEO
function centris_industry_utilities_meta() {
    if ( ! is_page( 'industry-utilities' ) ) return;
    ?>
    <meta name="description" content="Bilingual utilities contact center — outage response, billing disputes, and field dispatch support." />
    <meta property="og:title" content="Utilities — Centris" />
    <meta property="og:description" content="Bilingual utilities contact center — outage response, billing disputes, and field dispatch support." />
    <?php
}
add_action( 'wp_head', 'centris_industry_utilities_meta' );

get_header();
if ( centris_render_elementor_and_exit() ) return;
?>
<?php get_template_part('inc/nav'); ?>


</div>
    <section class="page-hero">
      <div class="wrap">
        <div class="crumbs"><a href="<?php echo home_url('/'); ?>">Home</a> <span class="sep">/</span> <a href="<?php echo home_url('/industries/'); ?>">Industries</a> <span class="sep">/</span> <span>Utilities</span></div>
        <h1><span>Bilingual contact center support for</span> <span class="accent">utilities.</span></h1>
        <p class="lede">Outage support, billing, payment arrangements, service connects/disconnects — bilingual where it matters.</p>
      </div>
    </section>

    <section class="content-section">
      <div class="wrap">
        <div class="two-col ir">
          <div class="prose">
            <p class="meta">What we do here</p>
            <h3>What we do here, every day.</h3>
            <div><p>Utility contact center volume is bursty. A storm or a heat wave can quadruple inbound in an hour. We pre-stage capacity for known weather windows and have surge protocols that bring extra agents online in hours, not days.</p></div>
            <ul>
              <li><b>Outage intake</b> — structured location capture, ETR communication.</li>
              <li><b>Billing &amp; payments</b> — arrangements, autopay setup, dispute handling.</li>
              <li><b>Service moves</b> — connects, disconnects, transfers.</li>
              <li><b>Surge capacity</b> — storm-ready, with pre-staged bilingual pool.</li>
            </ul>
          </div>
          <div class="media-card"><img src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&w=1200" alt="Utilities" loading="lazy" /></div>
        </div>
      </div>
    </section>

    <section class="split-feature border-t">
      <div class="wrap">
        <div class="copy ir">
          <span class="lbl">Storm protocols</span>
          <h4>Capacity that responds to weather forecasts, not aftermath.</h4>
          <p>We monitor weather forecasts for your service territories. When a storm is forecast to hit, surge protocols activate 24 hours ahead: pre-staged flex agents come online, supervisors get briefed on the playbook, and Sophia preloads outage protocol scripts. When customers start calling, the team is ready.</p>
        </div>
        <div class="img ir"><img src="https://images.unsplash.com/photo-1503455637927-730bce8583c0?auto=format&w=1200" alt="" loading="lazy" /></div>
      </div>
    </section>

    <section class="split-feature flip">
      <div class="wrap">
        <div class="copy ir">
          <span class="lbl">Bilingual reach</span>
          <h4>In many service territories, 30-50% of customers prefer Spanish.</h4>
          <p>Utilities have one of the highest bilingual call mix rates in the contact center world — especially in Texas, California, Arizona, Florida, and New Mexico. We staff fully bilingual on every queue, so outage reporting, billing arrangements, and service moves all happen in the customer's first language. The pickup rate on payment arrangements in particular is materially higher when the conversation is in Spanish.</p>
        </div>
        <div class="img ir"><img src="https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&w=1200" alt="" loading="lazy" /></div>
      </div>
    </section>

    <section class="content-section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">By the numbers</p>
          <h2><span>What "good" looks like</span><br /><span class="accent">in this industry.</span></h2>
        </div>
        <div class="counter-grid ir" style="margin-top:3rem; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
          <div class="counter"><div class="n">Storm-ready</div><div class="l">Surge capacity in hours, not days</div></div>
          <div class="counter"><div class="n">40%</div><div class="l">Bilingual call mix served</div></div>
          <div class="counter"><div class="n">100%</div><div class="l">Regulatory call recording</div></div>
        </div>
      </div>
    </section>
    <section id="contact-cta" class="closing border-t">
      <h2 class="ir"><span>Want our</span><br /><span class="accent">utilities playbook?</span></h2>
      <p class="ir">We'll send you the high-level playbook for your vertical and book 15 minutes to discuss your specific operation.</p>
      <div class="ctas ir">
        <a class="cta-primary lg" href="<?php echo home_url('/contact/'); ?>">Book a 15-minute demo
          <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
        <a class="cta-quiet" href="tel:18005304897"><u>Or call 1-800-530-4897</u>
          <svg class="ico" viewBox="0 0 24 24" style="transform:translateY(-1px)"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg></a>
      </div>
    </section>
    <footer>
      <div class="foot">
        <div class="foot-brand">
          <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><img src="data:image/webp;base64,UklGRloGAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCD2AgAAUBAAnQEqpgA0AD6RQJhJJaQiISo1vIiwEglmCHKxjQWlg9+m85Wxf4nir0IdofMB8HfVH4pfTV8wH7ZesB/p/Vh6AHSO+gB+tfpr+xz+4XpVAI0HW1OuIh7BKc+tlU2EG3c9pz7xiEy4hwmS2vrGaFMiRk6HoRNLaV4hMwD2aZuQpjtw2J4iYipiAAD+axULKw73xZ/5zu7c6cz8Kyn9y6jfrxJ+Hlr05mVmbEKPgTv9quR0GxaJW2+7Pl8AY1q7Clh0oS9ZrW90xnH2+Szy86R4xQlFOq45RZR38/tDveDoHlavpLb2gfmZ6MJM0/iDJuOkQN32hEDv8TliU2DB/19gFLRnwmnDvCSQHmxv9S7Aif4Gf1+3xe/9b4fzNhnSL8sj1UvtWcPj4C7Pw//05voL//aWWjs2zIhnTmBMG3QbsL0c6AdfAqmoXUD7Zsft3yyjIOa0v6o7ItcGvloPEdmktmsJc8UV40UyeWTWck2iYhB90D+FVZwTL0ovepmBvGmgGiKjDzv3bOCaDZicQplwq9GQ3M/xkLlCmvlK76mYFBamg/qAEf5k9crw4gq2UVVeZwC0PLIKI2X9XvnZmgWHjqvQtC1fh75iHVyXZfjU4AvRHQvyZe5c30O3yb7cKHOx9S62Ip3msyUeIiyrT3KnGoTKei8P/OuE94fXz94LHm3gnbyC2LkSBqXbdTDU8Ck16hD/C7sumGj6LC5cJby7p9LhOqWE/RxUWpWQ9A5wIUMaxeI8o2GpL0QP7n+NI5PyG/8NC11Qs3vMH3ZLqDmHq/ZeW5Rv91zGPnA1tbWEvG6VxaNPnDCaM9l/WfuNPb0ypwF3JTT09lMsL/4GOpenHYBcR5FK38d0W6P/K50BxZpCDZ83O0pGbsWoYibjB3cAmuxo//vK9vo74OruV9XZS4cVZerSFfYv/oclHfrJZIEyRvuNBdsdwlx/mLNKj/Zfvv/fSTD7AEvnoiOxJZPjfZj82/3z9wIJuf7wAAAAAAAAAAA=" alt="Centris" /></a>
          <p>Centris Information Services &mdash; bilingual nearshore contact center solutions, built for a human-first AI future.</p>
          <div class="foot-social">
            <a href="https://facebook.com/centrisinfo" aria-label="Facebook"><svg class="ico" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
            <a href="https://linkedin.com/company/centris-information-services" aria-label="LinkedIn"><svg class="ico" viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a href="https://x.com/centrisinfo" aria-label="X"><svg class="ico" viewBox="0 0 24 24"><path d="M18 4 6 20M6 4l12 16"/></svg></a>
          </div>
        </div>
        <div class="foot-col"><h4>Services</h4><ul>
          <li><a href="<?php echo home_url('/services/ai-call-center/'); ?>">AI Call Center</a></li>
          <li><a href="<?php echo home_url('/services/customer-support/'); ?>">Customer Support</a></li>
          <li><a href="<?php echo home_url('/services/bpo/'); ?>">Business Process Outsourcing</a></li>
          <li><a href="<?php echo home_url('/services/inbound-sales/'); ?>">Inbound Sales</a></li>
          <li><a href="<?php echo home_url('/services/live-chat/'); ?>">Live Chat</a></li>
          <li><a href="<?php echo home_url('/services/marketing-surveys/'); ?>">Marketing Surveys</a></li>
          <li><a href="<?php echo home_url('/services/quality-assurance/'); ?>">Quality Assurance</a></li>
          <li><a href="<?php echo home_url('/services/soft-collections/'); ?>">Soft Collections</a></li>
          <li><a href="<?php echo home_url('/services/tier-1-tech/'); ?>">Tier 1 Tech Support</a></li>
        </ul></div>
        <div class="foot-col"><h4>Industries</h4><ul>
          <li><a href="<?php echo home_url('/industries/insurance/'); ?>">Insurance</a></li>
          <li><a href="<?php echo home_url('/industries/healthcare/'); ?>">Healthcare</a></li>
          <li><a href="<?php echo home_url('/industries/retail/'); ?>">Retail &amp; E-commerce</a></li>
          <li><a href="<?php echo home_url('/industries/security/'); ?>">Security</a></li>
          <li><a href="<?php echo home_url('/industries/utilities/'); ?>">Utilities</a></li>
          <li><a href="<?php echo home_url('/industries/finance/'); ?>">Finance</a></li>
          <li><a href="<?php echo home_url('/industries/'); ?>">View all industries</a></li>
        </ul></div>
        <div class="foot-col">
          <h4>Contact</h4>
          <ul>
            <li><a href="tel:18005304897">1-800-530-4897</a></li>
            <li><a href="mailto:kudos@centrisinfo.com">kudos@centrisinfo.com</a></li>
            <li style="color: var(--muted); font-size: 14px;">119 W. Tyler St., Suite 260<br/>Longview, TX 75601</li>
          </ul>
          <h4 style="margin-top:1.75rem;">Resources</h4>
          <ul>
            <li><a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Whitepapers</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Industry Events</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="foot-meta">
        <span>&copy; 2026 Centris Information Services</span>
        <span>Human-first AI for contact centers</span>
      </div>
    </footer>
    <button class="sophia-fab" id="sophiaFab" aria-label="Open Sophia chat">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
      <span class="fab-dot"></span>
    </button>
    <div class="sophia-panel" id="sophiaPanel" role="dialog" aria-label="Sophia assistant">
      <div class="sp-head">
        <div class="sp-avatar">S</div>
        <div class="sp-meta"><div class="n">Sophia</div><div class="s">Online &middot; Bilingual</div></div>
        <button class="sp-close" id="sophiaClose" aria-label="Close"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="sp-msgs" id="sophiaMsgs">
        <div class="sp-msg bot">Hi! I'm Sophia, the AI behind Centris contact centers. Ask me about pricing, ramp time, or what AI-assisted QA actually looks like.</div>
      </div>
      <div class="sp-quick" id="sophiaQuick">
        <button data-q="How fast can we go live?">Ramp time</button>
        <button data-q="What does pricing look like?">Pricing</button>
        <button data-q="How is quality measured?">Quality / QA</button>
        <button data-q="What languages do you cover?">Languages</button>
      </div>
      <form class="sp-input" id="sophiaForm">
        <input type="text" id="sophiaInput" placeholder="Ask Sophia anything..." autocomplete="off" />
        <button type="submit" aria-label="Send"><svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
      </form>
    </div>


<?php get_footer(); ?>
