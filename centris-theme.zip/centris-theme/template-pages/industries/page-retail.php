<?php
/**
 * Template Name: Centris — Retail
 * Centris Retail page.
 */

// SEO
function centris_industry_retail_meta() {
    if ( ! is_page( 'industry-retail' ) ) return;
    ?>
    <meta name="description" content="Bilingual retail contact center — order management, returns, loyalty, and omnichannel support." />
    <meta property="og:title" content="Retail — Centris" />
    <meta property="og:description" content="Bilingual retail contact center — order management, returns, loyalty, and omnichannel support." />
    <?php
}
add_action( 'wp_head', 'centris_industry_retail_meta' );

get_header();
?>

<div class="scroll-progress" aria-hidden="true"><div class="scroll-progress-bar" id="scrollBar"></div></div>
    <header class="nav">
      <div class="nav-inner">
        <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><img src="data:image/webp;base64,UklGRloGAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCD2AgAAUBAAnQEqpgA0AD6RQJhJJaQiISo1vIiwEglmCHKxjQWlg9+m85Wxf4nir0IdofMB8HfVH4pfTV8wH7ZesB/p/Vh6AHSO+gB+tfpr+xz+4XpVAI0HW1OuIh7BKc+tlU2EG3c9pz7xiEy4hwmS2vrGaFMiRk6HoRNLaV4hMwD2aZuQpjtw2J4iYipiAAD+axULKw73xZ/5zu7c6cz8Kyn9y6jfrxJ+Hlr05mVmbEKPgTv9quR0GxaJW2+7Pl8AY1q7Clh0oS9ZrW90xnH2+Szy86R4xQlFOq45RZR38/tDveDoHlavpLb2gfmZ6MJM0/iDJuOkQN32hEDv8TliU2DB/19gFLRnwmnDvCSQHmxv9S7Aif4Gf1+3xe/9b4fzNhnSL8sj1UvtWcPj4C7Pw//05voL//aWWjs2zIhnTmBMG3QbsL0c6AdfAqmoXUD7Zsft3yyjIOa0v6o7ItcGvloPEdmktmsJc8UV40UyeWTWck2iYhB90D+FVZwTL0ovepmBvGmgGiKjDzv3bOCaDZicQplwq9GQ3M/xkLlCmvlK76mYFBamg/qAEf5k9crw4gq2UVVeZwC0PLIKI2X9XvnZmgWHjqvQtC1fh75iHVyXZfjU4AvRHQvyZe5c30O3yb7cKHOx9S62Ip3msyUeIiyrT3KnGoTKei8P/OuE94fXz94LHm3gnbyC2LkSBqXbdTDU8Ck16hD/C7sumGj6LC5cJby7p9LhOqWE/RxUWpWQ9A5wIUMaxeI8o2GpL0QP7n+NI5PyG/8NC11Qs3vMH3ZLqDmHq/ZeW5Rv91zGPnA1tbWEvG6VxaNPnDCaM9l/WfuNPb0ypwF3JTT09lMsL/4GOpenHYBcR5FK38d0W6P/K50BxZpCDZ83O0pGbsWoYibjB3cAmuxo//vK9vo74OruV9XZS4cVZerSFfYv/oclHfrJZIEyRvuNBdsdwlx/mLNKj/Zfvv/fSTD7AEvnoiOxJZPjfZj82/3z9wIJuf7wAAAAAAAAAAA=" alt="Centris" /></a>
        <nav class="nav-links">
          <span class="has-dropdown"><a href="<?php echo home_url('/services/'); ?>" data-i18n="nav.services">Services</a>
            <div class="nav-dropdown" role="menu">
              <a href="<?php echo home_url('/services/ai-call-center/'); ?>"><span class="num">01</span><span data-i18n="service.ai-call-center.name">AI Call Center</span></a>
              <a href="<?php echo home_url('/services/customer-support/'); ?>"><span class="num">02</span><span data-i18n="service.customer-support.name">Customer Support</span></a>
              <a href="<?php echo home_url('/services/bpo/'); ?>"><span class="num">03</span><span data-i18n="service.bpo.name">Business Process Outsourcing</span></a>
              <a href="<?php echo home_url('/services/inbound-sales/'); ?>"><span class="num">04</span><span data-i18n="service.inbound-sales.name">Inbound Sales</span></a>
              <a href="<?php echo home_url('/services/live-chat/'); ?>"><span class="num">05</span><span data-i18n="service.live-chat.name">Live Chat</span></a>
              <a href="<?php echo home_url('/services/marketing-surveys/'); ?>"><span class="num">06</span><span data-i18n="service.marketing-surveys.name">Marketing Surveys</span></a>
              <a href="<?php echo home_url('/services/quality-assurance/'); ?>"><span class="num">07</span><span data-i18n="service.quality-assurance.name">Quality Assurance</span></a>
              <a href="<?php echo home_url('/services/soft-collections/'); ?>"><span class="num">08</span><span data-i18n="service.soft-collections.name">Soft Collections</span></a>
              <a href="<?php echo home_url('/services/tier-1-tech/'); ?>"><span class="num">09</span><span data-i18n="service.tier-1-tech.name">Tier 1 Tech Support</span></a>
              <a class="all-link" href="<?php echo home_url('/services/'); ?>" data-i18n="nav.all_services">View all services</a>
            </div>
          </span>
          <span class="has-dropdown"><a href="<?php echo home_url('/industries/'); ?>" data-i18n="nav.industries" style="color:var(--coral)">Industries</a>
            <div class="nav-dropdown" role="menu">
              <a href="<?php echo home_url('/industries/insurance/'); ?>"><span data-i18n="industry.insurance.name">Insurance</span></a>
              <a href="<?php echo home_url('/industries/healthcare/'); ?>"><span data-i18n="industry.healthcare.name">Healthcare</span></a>
              <a href="<?php echo home_url('/industries/retail/'); ?>"><span data-i18n="industry.retail.name">Retail &amp; E-commerce</span></a>
              <a href="<?php echo home_url('/industries/security/'); ?>"><span data-i18n="industry.security.name">Security</span></a>
              <a href="<?php echo home_url('/industries/utilities/'); ?>"><span data-i18n="industry.utilities.name">Utilities</span></a>
              <a href="<?php echo home_url('/industries/finance/'); ?>"><span data-i18n="industry.finance.name">Finance</span></a>
              <a class="all-link" href="<?php echo home_url('/industries/'); ?>" data-i18n="nav.all_industries">View all industries</a>
            </div>
          </span>
          <a href="<?php echo home_url('/case-studies/'); ?>" data-i18n="nav.cases">Case Studies</a>
          <a href="<?php echo home_url('/about/'); ?>" data-i18n="nav.about">About</a>
          <a href="<?php echo home_url('/resources/'); ?>" data-i18n="nav.resources">Resources</a>
        </nav>
        <div class="nav-tools">
          <button class="lang-toggle" aria-label="Toggle language"><span class="active-lang">EN</span></button>
          <button class="theme-toggle" aria-label="Toggle theme">
            <svg class="sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
            <svg class="moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
          </button>
          <a class="cta-primary sm" href="<?php echo home_url('/contact/'); ?>" data-i18n="nav.cta">Book a demo
            <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </a>
        </div>
      </div>
    </header>
    <section class="page-hero">
      <div class="wrap">
        <div class="crumbs"><a href="<?php echo home_url('/'); ?>" data-i18n="crumb.home">Home</a> <span class="sep">/</span> <a href="<?php echo home_url('/industries/'); ?>" data-i18n="crumb.industries">Industries</a> <span class="sep">/</span> <span data-i18n="industry.retail.name">Retail & E-commerce</span></div>
        <h1><span>Bilingual contact center support for</span> <span class="accent" data-i18n="industry.retail.name_lower">retail & e-commerce.</span></h1>
        <p class="lede" data-i18n="industry.retail.desc">Order management, returns, replacements, and post-purchase support — built for Q4 peaks.</p>
      </div>
    </section>

    <section class="content-section">
      <div class="wrap">
        <div class="two-col ir">
          <div class="prose">
            <p class="meta" data-i18n="id.what.label">What we do here</p>
            <h3 data-i18n="id.what.h3">What we do here, every day.</h3>
            <div data-i18n-html="industry.retail.what"><p>Retail is volatile. November and December don't look like June, and a contact center that can't flex 2–3x is a contact center that loses peak. We staff a flex pool of pre-trained, ready-to-deploy bilingual agents — so when traffic doubles, your service levels don't drop.</p></div>
            <ul>
              <li data-i18n-html="industry.retail.bullet.0"><b>Peak flexing</b> — pre-trained pool, ready to scale on 2-week notice.</li>
              <li data-i18n-html="industry.retail.bullet.1"><b>Returns &amp; replacements</b> — handled cleanly, with disposition logged.</li>
              <li data-i18n-html="industry.retail.bullet.2"><b>Live chat conversion</b> — bilingual proactive chat for cart recovery.</li>
              <li data-i18n-html="industry.retail.bullet.3"><b>Post-purchase</b> — delivery, sizing, product questions handled in either language.</li>
            </ul>
          </div>
          <div class="media-card"><img src="https://images.unsplash.com/photo-1481437156560-3205f6a55735?auto=format&w=1200" alt="Retail & E-commerce" loading="lazy" /></div>
        </div>
      </div>
    </section>

    <section class="split-feature border-t">
      <div class="wrap">
        <div class="copy ir">
          <span class="lbl" data-i18n="industry.retail.f1.lbl">Peak season planning</span>
          <h4 data-i18n-html="industry.retail.f1.h">Q4 lift, planned in Q2.</h4>
          <p data-i18n="industry.retail.f1.p">We start staffing for holiday peak in June. By September, the flex pool is hired and trained. By Black Friday week, capacity is at 3x baseline and ready. When January hits and volume drops, the pool returns to baseline. You pay for what you used, your SLAs hold through peak, and your CSAT doesn't tank in the most-watched quarter of the year.</p>
        </div>
        <div class="img ir"><img src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&w=1200" alt="" loading="lazy" /></div>
      </div>
    </section>

    <section class="split-feature flip">
      <div class="wrap">
        <div class="copy ir">
          <span class="lbl" data-i18n="industry.retail.f2.lbl">Returns & disposition</span>
          <h4 data-i18n-html="industry.retail.f2.h">Returns are a customer moment, not just a logistics problem.</h4>
          <p data-i18n="industry.retail.f2.p">How you handle a return decides whether a customer comes back. We treat returns conversations as retention moments — listening for the root cause, offering alternatives where appropriate, and logging structured disposition data your merchandising team can act on. Sentiment, root cause, and likelihood-to-return-as-customer all get tagged on every call.</p>
        </div>
        <div class="img ir"><img src="https://images.unsplash.com/photo-1607082349566-187342175e2f?auto=format&w=1200" alt="" loading="lazy" /></div>
      </div>
    </section>

    <section class="content-section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta" data-i18n="id.stats.label">By the numbers</p>
          <h2><span data-i18n="id.stats.h2a">What "good" looks like</span><br /><span class="accent" data-i18n="id.stats.h2b">in this industry.</span></h2>
        </div>
        <div class="counter-grid ir" style="margin-top:3rem; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
          <div class="counter"><div class="n">3x</div><div class="l" data-i18n-html="industry.retail.stat.0">Peak-season capacity flex</div></div>
          <div class="counter"><div class="n">EN+ES</div><div class="l" data-i18n-html="industry.retail.stat.1">Bilingual chat conversion</div></div>
          <div class="counter"><div class="n">&lt;45s</div><div class="l" data-i18n-html="industry.retail.stat.2">Average chat first response</div></div>
        </div>
      </div>
    </section>
    <section id="contact-cta" class="closing border-t">
      <h2 class="ir"><span data-i18n="closing.h2a">Want our</span><br /><span class="accent" data-i18n="closing.h2b">retail & e-commerce playbook?</span></h2>
      <p class="ir" data-i18n="closing.sub">We'll send you the high-level playbook for your vertical and book 15 minutes to discuss your specific operation.</p>
      <div class="ctas ir">
        <a class="cta-primary lg" href="<?php echo home_url('/contact/'); ?>" data-i18n="closing.cta">Book a 15-minute demo
          <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
        <a class="cta-quiet" href="tel:18005304897"><u data-i18n="closing.alt">Or call 1-800-530-4897</u>
          <svg class="ico" viewBox="0 0 24 24" style="transform:translateY(-1px)"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg></a>
      </div>
    </section>
    <footer>
      <div class="foot">
        <div class="foot-brand">
          <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><img src="data:image/webp;base64,UklGRloGAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCD2AgAAUBAAnQEqpgA0AD6RQJhJJaQiISo1vIiwEglmCHKxjQWlg9+m85Wxf4nir0IdofMB8HfVH4pfTV8wH7ZesB/p/Vh6AHSO+gB+tfpr+xz+4XpVAI0HW1OuIh7BKc+tlU2EG3c9pz7xiEy4hwmS2vrGaFMiRk6HoRNLaV4hMwD2aZuQpjtw2J4iYipiAAD+axULKw73xZ/5zu7c6cz8Kyn9y6jfrxJ+Hlr05mVmbEKPgTv9quR0GxaJW2+7Pl8AY1q7Clh0oS9ZrW90xnH2+Szy86R4xQlFOq45RZR38/tDveDoHlavpLb2gfmZ6MJM0/iDJuOkQN32hEDv8TliU2DB/19gFLRnwmnDvCSQHmxv9S7Aif4Gf1+3xe/9b4fzNhnSL8sj1UvtWcPj4C7Pw//05voL//aWWjs2zIhnTmBMG3QbsL0c6AdfAqmoXUD7Zsft3yyjIOa0v6o7ItcGvloPEdmktmsJc8UV40UyeWTWck2iYhB90D+FVZwTL0ovepmBvGmgGiKjDzv3bOCaDZicQplwq9GQ3M/xkLlCmvlK76mYFBamg/qAEf5k9crw4gq2UVVeZwC0PLIKI2X9XvnZmgWHjqvQtC1fh75iHVyXZfjU4AvRHQvyZe5c30O3yb7cKHOx9S62Ip3msyUeIiyrT3KnGoTKei8P/OuE94fXz94LHm3gnbyC2LkSBqXbdTDU8Ck16hD/C7sumGj6LC5cJby7p9LhOqWE/RxUWpWQ9A5wIUMaxeI8o2GpL0QP7n+NI5PyG/8NC11Qs3vMH3ZLqDmHq/ZeW5Rv91zGPnA1tbWEvG6VxaNPnDCaM9l/WfuNPb0ypwF3JTT09lMsL/4GOpenHYBcR5FK38d0W6P/K50BxZpCDZ83O0pGbsWoYibjB3cAmuxo//vK9vo74OruV9XZS4cVZerSFfYv/oclHfrJZIEyRvuNBdsdwlx/mLNKj/Zfvv/fSTD7AEvnoiOxJZPjfZj82/3z9wIJuf7wAAAAAAAAAAA=" alt="Centris" /></a>
          <p data-i18n="foot.about">Centris Information Services &mdash; bilingual nearshore contact center solutions, built for a human-first AI future.</p>
          <div class="foot-social">
            <a href="https://facebook.com/centrisinfo" aria-label="Facebook"><svg class="ico" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
            <a href="https://linkedin.com/company/centris-information-services" aria-label="LinkedIn"><svg class="ico" viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a href="https://x.com/centrisinfo" aria-label="X"><svg class="ico" viewBox="0 0 24 24"><path d="M18 4 6 20M6 4l12 16"/></svg></a>
          </div>
        </div>
        <div class="foot-col"><h4 data-i18n="foot.services">Services</h4><ul>
          <li><a href="<?php echo home_url('/services/ai-call-center/'); ?>" data-i18n="service.ai-call-center.name">AI Call Center</a></li>
          <li><a href="<?php echo home_url('/services/customer-support/'); ?>" data-i18n="service.customer-support.name">Customer Support</a></li>
          <li><a href="<?php echo home_url('/services/bpo/'); ?>" data-i18n="service.bpo.name">Business Process Outsourcing</a></li>
          <li><a href="<?php echo home_url('/services/inbound-sales/'); ?>" data-i18n="service.inbound-sales.name">Inbound Sales</a></li>
          <li><a href="<?php echo home_url('/services/live-chat/'); ?>" data-i18n="service.live-chat.name">Live Chat</a></li>
          <li><a href="<?php echo home_url('/services/marketing-surveys/'); ?>" data-i18n="service.marketing-surveys.name">Marketing Surveys</a></li>
          <li><a href="<?php echo home_url('/services/quality-assurance/'); ?>" data-i18n="service.quality-assurance.name">Quality Assurance</a></li>
          <li><a href="<?php echo home_url('/services/soft-collections/'); ?>" data-i18n="service.soft-collections.name">Soft Collections</a></li>
          <li><a href="<?php echo home_url('/services/tier-1-tech/'); ?>" data-i18n="service.tier-1-tech.name">Tier 1 Tech Support</a></li>
        </ul></div>
        <div class="foot-col"><h4 data-i18n="foot.industries">Industries</h4><ul>
          <li><a href="<?php echo home_url('/industries/insurance/'); ?>" data-i18n="industry.insurance.name">Insurance</a></li>
          <li><a href="<?php echo home_url('/industries/healthcare/'); ?>" data-i18n="industry.healthcare.name">Healthcare</a></li>
          <li><a href="<?php echo home_url('/industries/retail/'); ?>" data-i18n="industry.retail.name">Retail &amp; E-commerce</a></li>
          <li><a href="<?php echo home_url('/industries/security/'); ?>" data-i18n="industry.security.name">Security</a></li>
          <li><a href="<?php echo home_url('/industries/utilities/'); ?>" data-i18n="industry.utilities.name">Utilities</a></li>
          <li><a href="<?php echo home_url('/industries/finance/'); ?>" data-i18n="industry.finance.name">Finance</a></li>
          <li><a href="<?php echo home_url('/industries/'); ?>" data-i18n="nav.all_industries">View all industries</a></li>
        </ul></div>
        <div class="foot-col">
          <h4 data-i18n="foot.contact">Contact</h4>
          <ul>
            <li><a href="tel:18005304897">1-800-530-4897</a></li>
            <li><a href="mailto:kudos@centrisinfo.com">kudos@centrisinfo.com</a></li>
            <li style="color: var(--muted); font-size: 14px;">119 W. Tyler St., Suite 260<br/>Longview, TX 75601</li>
          </ul>
          <h4 style="margin-top:1.75rem;" data-i18n="foot.resources">Resources</h4>
          <ul>
            <li><a href="<?php echo home_url('/case-studies/'); ?>" data-i18n="nav.cases">Case Studies</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Whitepapers</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Industry Events</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="foot-meta">
        <span>&copy; 2026 Centris Information Services</span>
        <span data-i18n="foot.tag">Human-first AI for contact centers</span>
      </div>
    </footer>
    <button class="sophia-fab" id="sophiaFab" aria-label="Open Sophia chat">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
      <span class="fab-dot"></span>
    </button>
    <div class="sophia-panel" id="sophiaPanel" role="dialog" aria-label="Sophia assistant">
      <div class="sp-head">
        <div class="sp-avatar">S</div>
        <div class="sp-meta"><div class="n">Sophia</div><div class="s">Online &middot; Bilingual</div></div>
        <button class="sp-close" id="sophiaClose" aria-label="Close"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="sp-msgs" id="sophiaMsgs">
        <div class="sp-msg bot">Hi! I'm Sophia, the AI behind Centris contact centers. Ask me about pricing, ramp time, or what AI-assisted QA actually looks like.</div>
      </div>
      <div class="sp-quick" id="sophiaQuick">
        <button data-q="How fast can we go live?">Ramp time</button>
        <button data-q="What does pricing look like?">Pricing</button>
        <button data-q="How is quality measured?">Quality / QA</button>
        <button data-q="What languages do you cover?">Languages</button>
      </div>
      <form class="sp-input" id="sophiaForm">
        <input type="text" id="sophiaInput" placeholder="Ask Sophia anything..." autocomplete="off" />
        <button type="submit" aria-label="Send"><svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
      </form>
    </div>


<?php get_footer(); ?>
