<?php
/**
 * Template Name: Centris — Industries
 * Centris Industries page.
 */

// SEO
function centris_industries_meta() {
    if ( ! is_page( 'industries' ) ) return;
    ?>
    <meta name="description" content="Centris serves insurance, healthcare, retail, security, utilities, and finance with bilingual AI-powered contact center teams." />
    <meta property="og:title" content="Industries — Centris" />
    <meta property="og:description" content="Centris serves insurance, healthcare, retail, security, utilities, and finance with bilingual AI-powered contact center teams." />
    <?php
}
add_action( 'wp_head', 'centris_industries_meta' );

get_header();
if ( centris_render_elementor_and_exit() ) return;
?>
<?php get_template_part('inc/nav'); ?>


</div>
    <section class="page-hero">
      <div class="wrap">
        <div class="crumbs"><a href="<?php echo home_url('/'); ?>">Home</a> <span class="sep">/</span> <span>Industries</span></div>
        <h1><span>We know your industry —</span> <span class="accent">because we've been serving it for years.</span></h1>
        <p class="lede">Industry verticals, each with its own playbook refined over thousands of real customer interactions. These aren't generic scripts.</p>
      </div>
    </section>
    <section class="content-section">
      <div class="wrap">
        <div class="industries-grid">
        <a class="industry ir" href="<?php echo home_url('/industries/insurance/'); ?>" style="text-decoration:none; display:block;">
          <div class="industry-img" style="background-image: url('https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&w=1200');"></div>
          <h3>Insurance</h3>
          <p>Claims, FNOL, policy service, and underwriting support — bilingual, scored, and tracked.</p>
        </a>
        <a class="industry ir" href="<?php echo home_url('/industries/healthcare/'); ?>" style="text-decoration:none; display:block;">
          <div class="industry-img" style="background-image: url('https://images.unsplash.com/photo-1530026405186-ed1f139313f8?auto=format&w=1200');"></div>
          <h3>Healthcare</h3>
          <p>HIPAA-compliant patient access, scheduling, and member services for provider networks and payers.</p>
        </a>
        <a class="industry ir" href="<?php echo home_url('/industries/retail/'); ?>" style="text-decoration:none; display:block;">
          <div class="industry-img" style="background-image: url('https://images.unsplash.com/photo-1481437156560-3205f6a55735?auto=format&w=1200');"></div>
          <h3>Retail &amp; E-commerce</h3>
          <p>Order management, returns, replacements, and post-purchase support — built for Q4 peaks.</p>
        </a>
        <a class="industry ir" href="<?php echo home_url('/industries/security/'); ?>" style="text-decoration:none; display:block;">
          <div class="industry-img" style="background-image: url('https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&w=1200');"></div>
          <h3>Security</h3>
          <p>Alarm response, dispatch coordination, account services. Zero-tolerance latency, 24/7 across two centers.</p>
        </a>
        <a class="industry ir" href="<?php echo home_url('/industries/utilities/'); ?>" style="text-decoration:none; display:block;">
          <div class="industry-img" style="background-image: url('https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&w=1200');"></div>
          <h3>Utilities</h3>
          <p>Outage support, billing, payment arrangements, service connects/disconnects — bilingual where it matters.</p>
        </a>
        <a class="industry ir" href="<?php echo home_url('/industries/finance/'); ?>" style="text-decoration:none; display:block;">
          <div class="industry-img" style="background-image: url('https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&w=1200');"></div>
          <h3>Finance</h3>
          <p>Account servicing, dispute intake, fraud verification, onboarding for consumer finance and fintech.</p>
        </a>
        </div>
      </div>
    </section>
    <section id="contact-cta" class="closing border-t">
      <h2 class="ir"><span>Which industry is yours?</span><br /><span class="accent">Let's compare playbooks.</span></h2>
      <p class="ir">Book a 15-minute call — we'll walk through the playbook we'd start with for your vertical.</p>
      <div class="ctas ir">
        <a class="cta-primary lg" href="<?php echo home_url('/contact/'); ?>">Book a 15-minute demo
          <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
        <a class="cta-quiet" href="tel:18005304897"><u>Or call 1-800-530-4897</u>
          <svg class="ico" viewBox="0 0 24 24" style="transform:translateY(-1px)"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg></a>
      </div>
    </section>
    <footer>
      <div class="foot">
        <div class="foot-brand">
          <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><img src="data:image/webp;base64,UklGRloGAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCD2AgAAUBAAnQEqpgA0AD6RQJhJJaQiISo1vIiwEglmCHKxjQWlg9+m85Wxf4nir0IdofMB8HfVH4pfTV8wH7ZesB/p/Vh6AHSO+gB+tfpr+xz+4XpVAI0HW1OuIh7BKc+tlU2EG3c9pz7xiEy4hwmS2vrGaFMiRk6HoRNLaV4hMwD2aZuQpjtw2J4iYipiAAD+axULKw73xZ/5zu7c6cz8Kyn9y6jfrxJ+Hlr05mVmbEKPgTv9quR0GxaJW2+7Pl8AY1q7Clh0oS9ZrW90xnH2+Szy86R4xQlFOq45RZR38/tDveDoHlavpLb2gfmZ6MJM0/iDJuOkQN32hEDv8TliU2DB/19gFLRnwmnDvCSQHmxv9S7Aif4Gf1+3xe/9b4fzNhnSL8sj1UvtWcPj4C7Pw//05voL//aWWjs2zIhnTmBMG3QbsL0c6AdfAqmoXUD7Zsft3yyjIOa0v6o7ItcGvloPEdmktmsJc8UV40UyeWTWck2iYhB90D+FVZwTL0ovepmBvGmgGiKjDzv3bOCaDZicQplwq9GQ3M/xkLlCmvlK76mYFBamg/qAEf5k9crw4gq2UVVeZwC0PLIKI2X9XvnZmgWHjqvQtC1fh75iHVyXZfjU4AvRHQvyZe5c30O3yb7cKHOx9S62Ip3msyUeIiyrT3KnGoTKei8P/OuE94fXz94LHm3gnbyC2LkSBqXbdTDU8Ck16hD/C7sumGj6LC5cJby7p9LhOqWE/RxUWpWQ9A5wIUMaxeI8o2GpL0QP7n+NI5PyG/8NC11Qs3vMH3ZLqDmHq/ZeW5Rv91zGPnA1tbWEvG6VxaNPnDCaM9l/WfuNPb0ypwF3JTT09lMsL/4GOpenHYBcR5FK38d0W6P/K50BxZpCDZ83O0pGbsWoYibjB3cAmuxo//vK9vo74OruV9XZS4cVZerSFfYv/oclHfrJZIEyRvuNBdsdwlx/mLNKj/Zfvv/fSTD7AEvnoiOxJZPjfZj82/3z9wIJuf7wAAAAAAAAAAA=" alt="Centris" /></a>
          <p>Centris Information Services &mdash; bilingual nearshore contact center solutions, built for a human-first AI future.</p>
          <div class="foot-social">
            <a href="https://facebook.com/centrisinfo" aria-label="Facebook"><svg class="ico" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
            <a href="https://linkedin.com/company/centris-information-services" aria-label="LinkedIn"><svg class="ico" viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a href="https://x.com/centrisinfo" aria-label="X"><svg class="ico" viewBox="0 0 24 24"><path d="M18 4 6 20M6 4l12 16"/></svg></a>
          </div>
        </div>
        <div class="foot-col"><h4>Services</h4><ul>
          <li><a href="<?php echo home_url('/services/ai-call-center/'); ?>">AI Call Center</a></li>
          <li><a href="<?php echo home_url('/services/customer-support/'); ?>">Customer Support</a></li>
          <li><a href="<?php echo home_url('/services/bpo/'); ?>">Business Process Outsourcing</a></li>
          <li><a href="<?php echo home_url('/services/inbound-sales/'); ?>">Inbound Sales</a></li>
          <li><a href="<?php echo home_url('/services/live-chat/'); ?>">Live Chat</a></li>
          <li><a href="<?php echo home_url('/services/marketing-surveys/'); ?>">Marketing Surveys</a></li>
          <li><a href="<?php echo home_url('/services/quality-assurance/'); ?>">Quality Assurance</a></li>
          <li><a href="<?php echo home_url('/services/soft-collections/'); ?>">Soft Collections</a></li>
          <li><a href="<?php echo home_url('/services/tier-1-tech/'); ?>">Tier 1 Tech Support</a></li>
        </ul></div>
        <div class="foot-col"><h4>Industries</h4><ul>
          <li><a href="<?php echo home_url('/industries/insurance/'); ?>">Insurance</a></li>
          <li><a href="<?php echo home_url('/industries/healthcare/'); ?>">Healthcare</a></li>
          <li><a href="<?php echo home_url('/industries/retail/'); ?>">Retail &amp; E-commerce</a></li>
          <li><a href="<?php echo home_url('/industries/security/'); ?>">Security</a></li>
          <li><a href="<?php echo home_url('/industries/utilities/'); ?>">Utilities</a></li>
          <li><a href="<?php echo home_url('/industries/finance/'); ?>">Finance</a></li>
          <li><a href="<?php echo home_url('/industries/'); ?>">View all industries</a></li>
        </ul></div>
        <div class="foot-col">
          <h4>Contact</h4>
          <ul>
            <li><a href="tel:18005304897">1-800-530-4897</a></li>
            <li><a href="mailto:kudos@centrisinfo.com">kudos@centrisinfo.com</a></li>
            <li style="color: var(--muted); font-size: 14px;">119 W. Tyler St., Suite 260<br/>Longview, TX 75601</li>
          </ul>
          <h4 style="margin-top:1.75rem;">Resources</h4>
          <ul>
            <li><a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Whitepapers</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Industry Events</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="foot-meta">
        <span>&copy; 2026 Centris Information Services</span>
        <span>Human-first AI for contact centers</span>
      </div>
    </footer>
    <button class="sophia-fab" id="sophiaFab" aria-label="Open Sophia chat">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
      <span class="fab-dot"></span>
    </button>
    <div class="sophia-panel" id="sophiaPanel" role="dialog" aria-label="Sophia assistant">
      <div class="sp-head">
        <div class="sp-avatar">S</div>
        <div class="sp-meta"><div class="n">Sophia</div><div class="s">Online &middot; Bilingual</div></div>
        <button class="sp-close" id="sophiaClose" aria-label="Close"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="sp-msgs" id="sophiaMsgs">
        <div class="sp-msg bot">Hi! I'm Sophia, the AI behind Centris contact centers. Ask me about pricing, ramp time, or what AI-assisted QA actually looks like.</div>
      </div>
      <div class="sp-quick" id="sophiaQuick">
        <button data-q="How fast can we go live?">Ramp time</button>
        <button data-q="What does pricing look like?">Pricing</button>
        <button data-q="How is quality measured?">Quality / QA</button>
        <button data-q="What languages do you cover?">Languages</button>
      </div>
      <form class="sp-input" id="sophiaForm">
        <input type="text" id="sophiaInput" placeholder="Ask Sophia anything..." autocomplete="off" />
        <button type="submit" aria-label="Send"><svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
      </form>
    </div>


<?php get_footer(); ?>
