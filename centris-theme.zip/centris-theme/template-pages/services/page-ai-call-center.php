<?php
/**
 * Template Name: Centris — AI Call Center
 * Centris AI Call Center page.
 */

// SEO
function centris_service_ai_call_center_meta() {
    if ( ! is_page( 'service-ai-call-center' ) ) return;
    ?>
    <meta name="description" content="AI-powered inbound and outbound call center with real-time transcription, Sophia AI, and bilingual EN/ES agents." />
    <meta property="og:title" content="AI Call Center — Centris" />
    <meta property="og:description" content="AI-powered inbound and outbound call center with real-time transcription, Sophia AI, and bilingual EN/ES agents." />
    <?php
}
add_action( 'wp_head', 'centris_service_ai_call_center_meta' );

get_header();
if ( centris_render_elementor_and_exit() ) return;
?>
<?php get_template_part('inc/nav'); ?>


</div>
    <section class="page-hero">
      <div class="wrap">
        <div class="crumbs"><a href="<?php echo home_url('/'); ?>">Home</a> <span class="sep">/</span> <a href="<?php echo home_url('/services/'); ?>">Services</a> <span class="sep">/</span> <span>AI Call Center</span></div>
        <h1><span>Where humans are powered by AI.</span></h1>
        <p class="lede">Centris blends AI efficiency with real bilingual agents to deliver smarter, more empathetic customer care — at the speed of live conversation.</p>
      </div>
    </section>

    <section class="content-section">
      <div class="wrap">
        <div class="two-col ir">
          <div class="prose">
            <p class="meta">Service 01</p>
            <h3>What <span>AI Call Center</span> means at Centris.</h3>
              <p>Our AI Call Center pairs every bilingual agent with Sophia, a real-time assistant that listens, transcribes, scores sentiment, and surfaces the next-best line — all without slowing the conversation down. The agent decides; Sophia accelerates.</p>
              <p>That changes the math. Average handle time drops 18–22%. First-call resolution climbs into the low 90s. And every single call gets QA scored — not the 2% manual sample that used to be the industry default.</p>
            <ul>
              <li><b>Live transcript &amp; translation cues</b> — agents see customer intent and sentiment as it happens, in either language.</li>
              <li><b>Next-best-action prompts</b> — Sophia surfaces the optimal response with a confidence score; the agent approves, rewrites, or skips.</li>
              <li><b>Automatic QA on every call</b> — adherence, empathy, resolution, and compliance scored on 100% of interactions.</li>
              <li><b>Sentiment tracking</b> — real-time emotional read of the caller, used for routing, escalation, and post-call coaching.</li>
            </ul>
          </div>
          <div class="media-card"><img src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&w=1400" alt="AI Call Center" loading="lazy" /></div>
        </div>
      </div>
    </section>

    <section class="split-feature border-t">
      <div class="wrap">
        <div class="copy ir">
          <span class="lbl">How Sophia works on a call</span>
          <h4>Listening, drafting, and scoring — all in the background.</h4>
          <p>As your agent talks with the customer, Sophia transcribes both sides into the screen, runs intent and sentiment detection on each sentence, and pulls relevant knowledge base content into a side panel. When the customer pauses, Sophia drafts a recommended response. Your agent reads it, decides, and speaks — all in under two seconds.</p>
        </div>
        <div class="img ir"><img src="https://images.unsplash.com/photo-1551836022-deb4988cc6c0?auto=format&w=1200" alt="" loading="lazy" /></div>
      </div>
    </section>

    <section class="split-feature flip">
      <div class="wrap">
        <div class="copy ir">
          <span class="lbl">Why bilingual matters here</span>
          <h4>Spanish-language conversion you can actually measure.</h4>
          <p>Roughly 30% of inbound contact volume in many North American verticals comes from Spanish-preference customers. When that traffic hits an English-only IVR or gets transferred to a generic queue, conversion drops by 20-40%. Our agents are native bilingual on every call — and Sophia surfaces translation cues for customers who switch mid-conversation.</p>
        </div>
        <div class="img ir"><img src="https://images.unsplash.com/photo-1664575602276-acd073f104c1?auto=format&w=1200" alt="" loading="lazy" /></div>
      </div>
    </section>

    <section class="content-section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">How it looks</p>
          <h2><span>How a typical engagement</span><br /><span class="accent">unfolds with us.</span></h2>
        </div>
        <div class="counter-grid ir" style="margin-top:3rem;">
          <div class="counter"><div class="n">01</div><div class="l"><b>Discovery</b> · Week 1 — Listen in on your existing calls, audit your current playbooks, identify the gaps.</div></div>
          <div class="counter"><div class="n">02</div><div class="l"><b>Design</b> · Weeks 2-3 — Build your scorecard, your scripts, your escalation paths. You sign off on every artifact.</div></div>
          <div class="counter"><div class="n">03</div><div class="l"><b>Train</b> · Weeks 3-4 — Your dedicated team trains on your product, your tone, your customer profile.</div></div>
          <div class="counter"><div class="n">04</div><div class="l"><b>Go live</b> · Week 5+ — Soft launch with QA double-coverage. Full ramp to target volume at 60-90 days.</div></div>
        </div>
      </div>
    </section>
    <section class="content-section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta">Related services</p>
          <h2>What pairs well with this.</h2>
        </div>
        <div class="article-grid ir">
        <a class="article" href="<?php echo home_url('/services/customer-support/'); ?>" style="text-decoration:none;">
          <div class="a-img"><img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&w=1400" alt="" loading="lazy" /></div>
          <div class="a-body">
            <p class="a-meta">Service · 02</p>
            <h3>Customer Support</h3>
            <p>Our agents work as a seamless extension of your team, in your tone, on your hours.</p>
            <span class="a-more">Learn more &rarr;</span>
          </div>
        </a>
        <a class="article" href="<?php echo home_url('/services/quality-assurance/'); ?>" style="text-decoration:none;">
          <div class="a-img"><img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&w=1400" alt="" loading="lazy" /></div>
          <div class="a-body">
            <p class="a-meta">Service · 07</p>
            <h3>Quality Assurance</h3>
            <p>AI and machine learning capture, transcribe, and score every interaction — across every channel. No surprises, no missed coaching moments.</p>
            <span class="a-more">Learn more &rarr;</span>
          </div>
        </a>
        <a class="article" href="<?php echo home_url('/services/tier-1-tech/'); ?>" style="text-decoration:none;">
          <div class="a-img"><img src="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&w=1400" alt="" loading="lazy" /></div>
          <div class="a-body">
            <p class="a-meta">Service · 09</p>
            <h3>Tier 1 Tech Support</h3>
            <p>Our agents are trained in your product and your tone — so the customer never has to wait for a human to call back.</p>
            <span class="a-more">Learn more &rarr;</span>
          </div>
        </a>
        </div>
      </div>
    </section>
    <section id="contact-cta" class="closing border-t">
      <h2 class="ir"><span>Ready to talk about</span><br /><span class="accent">AI Call Center?</span></h2>
      <p class="ir">Book a 15-minute demo. We'll listen to your operation and show you how this service would slot in.</p>
      <div class="ctas ir">
        <a class="cta-primary lg" href="<?php echo home_url('/contact/'); ?>">Book a 15-minute demo
          <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
        <a class="cta-quiet" href="tel:18005304897"><u>Or call 1-800-530-4897</u>
          <svg class="ico" viewBox="0 0 24 24" style="transform:translateY(-1px)"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg></a>
      </div>
    </section>
    <footer>
      <div class="foot">
        <div class="foot-brand">
          <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><img src="data:image/webp;base64,UklGRloGAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCD2AgAAUBAAnQEqpgA0AD6RQJhJJaQiISo1vIiwEglmCHKxjQWlg9+m85Wxf4nir0IdofMB8HfVH4pfTV8wH7ZesB/p/Vh6AHSO+gB+tfpr+xz+4XpVAI0HW1OuIh7BKc+tlU2EG3c9pz7xiEy4hwmS2vrGaFMiRk6HoRNLaV4hMwD2aZuQpjtw2J4iYipiAAD+axULKw73xZ/5zu7c6cz8Kyn9y6jfrxJ+Hlr05mVmbEKPgTv9quR0GxaJW2+7Pl8AY1q7Clh0oS9ZrW90xnH2+Szy86R4xQlFOq45RZR38/tDveDoHlavpLb2gfmZ6MJM0/iDJuOkQN32hEDv8TliU2DB/19gFLRnwmnDvCSQHmxv9S7Aif4Gf1+3xe/9b4fzNhnSL8sj1UvtWcPj4C7Pw//05voL//aWWjs2zIhnTmBMG3QbsL0c6AdfAqmoXUD7Zsft3yyjIOa0v6o7ItcGvloPEdmktmsJc8UV40UyeWTWck2iYhB90D+FVZwTL0ovepmBvGmgGiKjDzv3bOCaDZicQplwq9GQ3M/xkLlCmvlK76mYFBamg/qAEf5k9crw4gq2UVVeZwC0PLIKI2X9XvnZmgWHjqvQtC1fh75iHVyXZfjU4AvRHQvyZe5c30O3yb7cKHOx9S62Ip3msyUeIiyrT3KnGoTKei8P/OuE94fXz94LHm3gnbyC2LkSBqXbdTDU8Ck16hD/C7sumGj6LC5cJby7p9LhOqWE/RxUWpWQ9A5wIUMaxeI8o2GpL0QP7n+NI5PyG/8NC11Qs3vMH3ZLqDmHq/ZeW5Rv91zGPnA1tbWEvG6VxaNPnDCaM9l/WfuNPb0ypwF3JTT09lMsL/4GOpenHYBcR5FK38d0W6P/K50BxZpCDZ83O0pGbsWoYibjB3cAmuxo//vK9vo74OruV9XZS4cVZerSFfYv/oclHfrJZIEyRvuNBdsdwlx/mLNKj/Zfvv/fSTD7AEvnoiOxJZPjfZj82/3z9wIJuf7wAAAAAAAAAAA=" alt="Centris" /></a>
          <p>Centris Information Services &mdash; bilingual nearshore contact center solutions, built for a human-first AI future.</p>
          <div class="foot-social">
            <a href="https://facebook.com/centrisinfo" aria-label="Facebook"><svg class="ico" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
            <a href="https://linkedin.com/company/centris-information-services" aria-label="LinkedIn"><svg class="ico" viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a href="https://x.com/centrisinfo" aria-label="X"><svg class="ico" viewBox="0 0 24 24"><path d="M18 4 6 20M6 4l12 16"/></svg></a>
          </div>
        </div>
        <div class="foot-col"><h4>Services</h4><ul>
          <li><a href="<?php echo home_url('/services/ai-call-center/'); ?>">AI Call Center</a></li>
          <li><a href="<?php echo home_url('/services/customer-support/'); ?>">Customer Support</a></li>
          <li><a href="<?php echo home_url('/services/bpo/'); ?>">Business Process Outsourcing</a></li>
          <li><a href="<?php echo home_url('/services/inbound-sales/'); ?>">Inbound Sales</a></li>
          <li><a href="<?php echo home_url('/services/live-chat/'); ?>">Live Chat</a></li>
          <li><a href="<?php echo home_url('/services/marketing-surveys/'); ?>">Marketing Surveys</a></li>
          <li><a href="<?php echo home_url('/services/quality-assurance/'); ?>">Quality Assurance</a></li>
          <li><a href="<?php echo home_url('/services/soft-collections/'); ?>">Soft Collections</a></li>
          <li><a href="<?php echo home_url('/services/tier-1-tech/'); ?>">Tier 1 Tech Support</a></li>
        </ul></div>
        <div class="foot-col"><h4>Industries</h4><ul>
          <li><a href="<?php echo home_url('/industries/insurance/'); ?>">Insurance</a></li>
          <li><a href="<?php echo home_url('/industries/healthcare/'); ?>">Healthcare</a></li>
          <li><a href="<?php echo home_url('/industries/retail/'); ?>">Retail &amp; E-commerce</a></li>
          <li><a href="<?php echo home_url('/industries/security/'); ?>">Security</a></li>
          <li><a href="<?php echo home_url('/industries/utilities/'); ?>">Utilities</a></li>
          <li><a href="<?php echo home_url('/industries/finance/'); ?>">Finance</a></li>
          <li><a href="<?php echo home_url('/industries/'); ?>">View all industries</a></li>
        </ul></div>
        <div class="foot-col">
          <h4>Contact</h4>
          <ul>
            <li><a href="tel:18005304897">1-800-530-4897</a></li>
            <li><a href="mailto:kudos@centrisinfo.com">kudos@centrisinfo.com</a></li>
            <li style="color: var(--muted); font-size: 14px;">119 W. Tyler St., Suite 260<br/>Longview, TX 75601</li>
          </ul>
          <h4 style="margin-top:1.75rem;">Resources</h4>
          <ul>
            <li><a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Whitepapers</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Industry Events</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="foot-meta">
        <span>&copy; 2026 Centris Information Services</span>
        <span>Human-first AI for contact centers</span>
      </div>
    </footer>
    <button class="sophia-fab" id="sophiaFab" aria-label="Open Sophia chat">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
      <span class="fab-dot"></span>
    </button>
    <div class="sophia-panel" id="sophiaPanel" role="dialog" aria-label="Sophia assistant">
      <div class="sp-head">
        <div class="sp-avatar">S</div>
        <div class="sp-meta"><div class="n">Sophia</div><div class="s">Online &middot; Bilingual</div></div>
        <button class="sp-close" id="sophiaClose" aria-label="Close"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="sp-msgs" id="sophiaMsgs">
        <div class="sp-msg bot">Hi! I'm Sophia, the AI behind Centris contact centers. Ask me about pricing, ramp time, or what AI-assisted QA actually looks like.</div>
      </div>
      <div class="sp-quick" id="sophiaQuick">
        <button data-q="How fast can we go live?">Ramp time</button>
        <button data-q="What does pricing look like?">Pricing</button>
        <button data-q="How is quality measured?">Quality / QA</button>
        <button data-q="What languages do you cover?">Languages</button>
      </div>
      <form class="sp-input" id="sophiaForm">
        <input type="text" id="sophiaInput" placeholder="Ask Sophia anything..." autocomplete="off" />
        <button type="submit" aria-label="Send"><svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
      </form>
    </div>


<?php get_footer(); ?>
