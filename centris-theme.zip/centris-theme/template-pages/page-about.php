<?php
/**
 * Template Name: Centris — About
 * Centris About page.
 */

// SEO
function centris_about_meta() {
    if ( ! is_page( 'about' ) ) return;
    ?>
    <meta name="description" content="Learn about Centris — 30+ years of bilingual nearshore contact center excellence, powered by Sophia AI." />
    <meta property="og:title" content="About — Centris" />
    <meta property="og:description" content="Learn about Centris — 30+ years of bilingual nearshore contact center excellence, powered by Sophia AI." />
    <?php
}
add_action( 'wp_head', 'centris_about_meta' );

get_header();
?>

<div class="scroll-progress" aria-hidden="true"><div class="scroll-progress-bar" id="scrollBar"></div></div>
    <header class="nav">
      <div class="nav-inner">
        <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><img src="data:image/webp;base64,UklGRloGAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCD2AgAAUBAAnQEqpgA0AD6RQJhJJaQiISo1vIiwEglmCHKxjQWlg9+m85Wxf4nir0IdofMB8HfVH4pfTV8wH7ZesB/p/Vh6AHSO+gB+tfpr+xz+4XpVAI0HW1OuIh7BKc+tlU2EG3c9pz7xiEy4hwmS2vrGaFMiRk6HoRNLaV4hMwD2aZuQpjtw2J4iYipiAAD+axULKw73xZ/5zu7c6cz8Kyn9y6jfrxJ+Hlr05mVmbEKPgTv9quR0GxaJW2+7Pl8AY1q7Clh0oS9ZrW90xnH2+Szy86R4xQlFOq45RZR38/tDveDoHlavpLb2gfmZ6MJM0/iDJuOkQN32hEDv8TliU2DB/19gFLRnwmnDvCSQHmxv9S7Aif4Gf1+3xe/9b4fzNhnSL8sj1UvtWcPj4C7Pw//05voL//aWWjs2zIhnTmBMG3QbsL0c6AdfAqmoXUD7Zsft3yyjIOa0v6o7ItcGvloPEdmktmsJc8UV40UyeWTWck2iYhB90D+FVZwTL0ovepmBvGmgGiKjDzv3bOCaDZicQplwq9GQ3M/xkLlCmvlK76mYFBamg/qAEf5k9crw4gq2UVVeZwC0PLIKI2X9XvnZmgWHjqvQtC1fh75iHVyXZfjU4AvRHQvyZe5c30O3yb7cKHOx9S62Ip3msyUeIiyrT3KnGoTKei8P/OuE94fXz94LHm3gnbyC2LkSBqXbdTDU8Ck16hD/C7sumGj6LC5cJby7p9LhOqWE/RxUWpWQ9A5wIUMaxeI8o2GpL0QP7n+NI5PyG/8NC11Qs3vMH3ZLqDmHq/ZeW5Rv91zGPnA1tbWEvG6VxaNPnDCaM9l/WfuNPb0ypwF3JTT09lMsL/4GOpenHYBcR5FK38d0W6P/K50BxZpCDZ83O0pGbsWoYibjB3cAmuxo//vK9vo74OruV9XZS4cVZerSFfYv/oclHfrJZIEyRvuNBdsdwlx/mLNKj/Zfvv/fSTD7AEvnoiOxJZPjfZj82/3z9wIJuf7wAAAAAAAAAAA=" alt="Centris" /></a>
        <nav class="nav-links">
          <span class="has-dropdown"><a href="<?php echo home_url('/services/'); ?>" data-i18n="nav.services">Services</a>
            <div class="nav-dropdown" role="menu">
              <a href="<?php echo home_url('/services/ai-call-center/'); ?>"><span class="num">01</span><span data-i18n="service.ai-call-center.name">AI Call Center</span></a>
              <a href="<?php echo home_url('/services/customer-support/'); ?>"><span class="num">02</span><span data-i18n="service.customer-support.name">Customer Support</span></a>
              <a href="<?php echo home_url('/services/bpo/'); ?>"><span class="num">03</span><span data-i18n="service.bpo.name">Business Process Outsourcing</span></a>
              <a href="<?php echo home_url('/services/inbound-sales/'); ?>"><span class="num">04</span><span data-i18n="service.inbound-sales.name">Inbound Sales</span></a>
              <a href="<?php echo home_url('/services/live-chat/'); ?>"><span class="num">05</span><span data-i18n="service.live-chat.name">Live Chat</span></a>
              <a href="<?php echo home_url('/services/marketing-surveys/'); ?>"><span class="num">06</span><span data-i18n="service.marketing-surveys.name">Marketing Surveys</span></a>
              <a href="<?php echo home_url('/services/quality-assurance/'); ?>"><span class="num">07</span><span data-i18n="service.quality-assurance.name">Quality Assurance</span></a>
              <a href="<?php echo home_url('/services/soft-collections/'); ?>"><span class="num">08</span><span data-i18n="service.soft-collections.name">Soft Collections</span></a>
              <a href="<?php echo home_url('/services/tier-1-tech/'); ?>"><span class="num">09</span><span data-i18n="service.tier-1-tech.name">Tier 1 Tech Support</span></a>
              <a class="all-link" href="<?php echo home_url('/services/'); ?>" data-i18n="nav.all_services">View all services</a>
            </div>
          </span>
          <span class="has-dropdown"><a href="<?php echo home_url('/industries/'); ?>" data-i18n="nav.industries">Industries</a>
            <div class="nav-dropdown" role="menu">
              <a href="<?php echo home_url('/industries/insurance/'); ?>"><span data-i18n="industry.insurance.name">Insurance</span></a>
              <a href="<?php echo home_url('/industries/healthcare/'); ?>"><span data-i18n="industry.healthcare.name">Healthcare</span></a>
              <a href="<?php echo home_url('/industries/retail/'); ?>"><span data-i18n="industry.retail.name">Retail &amp; E-commerce</span></a>
              <a href="<?php echo home_url('/industries/security/'); ?>"><span data-i18n="industry.security.name">Security</span></a>
              <a href="<?php echo home_url('/industries/utilities/'); ?>"><span data-i18n="industry.utilities.name">Utilities</span></a>
              <a href="<?php echo home_url('/industries/finance/'); ?>"><span data-i18n="industry.finance.name">Finance</span></a>
              <a class="all-link" href="<?php echo home_url('/industries/'); ?>" data-i18n="nav.all_industries">View all industries</a>
            </div>
          </span>
          <a href="<?php echo home_url('/case-studies/'); ?>" data-i18n="nav.cases">Case Studies</a>
          <a href="<?php echo home_url('/about/'); ?>" data-i18n="nav.about" style="color:var(--coral)">About</a>
          <a href="<?php echo home_url('/resources/'); ?>" data-i18n="nav.resources">Resources</a>
        </nav>
        <div class="nav-tools">
          <button class="lang-toggle" aria-label="Toggle language"><span class="active-lang">EN</span></button>
          <button class="theme-toggle" aria-label="Toggle theme">
            <svg class="sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
            <svg class="moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
          </button>
          <a class="cta-primary sm" href="<?php echo home_url('/contact/'); ?>" data-i18n="nav.cta">Book a demo
            <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </a>
        </div>
      </div>
    </header>
    <section class="page-hero">
      <div class="wrap">
        <div class="crumbs"><a href="<?php echo home_url('/'); ?>" data-i18n="crumb.home">Home</a> <span class="sep">/</span> <span data-i18n="crumb.about">About</span></div>
        <h1><span data-i18n="ph.about.h1">30 years delivering better customer service —</span> <span class="accent" data-i18n="ph.about.h1b">with an edge.</span></h1>
        <p class="lede" data-i18n="ph.about.lede">Centris was founded in 1993 with a simple idea: what if contact centers were treated as partners, not vendors. Three decades, two nearshore hubs, and 5,000+ customers later, that idea is a practice.</p>
      </div>
    </section>
    <section class="content-section border-t">
      <div class="wrap">
        <div class="two-col ir">
          <div class="prose">
            <p class="meta" data-i18n="about.story.label">Our story</p>
            <h3 data-i18n="about.story.h3">Built nearshore. Run like an extension of your team.</h3>
            <p data-i18n="about.story.p1">Centris began as a US-led operation with one nearshore hub in Monterrey. The thesis was simple: bilingual contact center work is a craft, and craft requires continuity.</p>
            <p data-i18n="about.story.p2">That thesis still drives the company. We've added a second center in Aguascalientes, layered Sophia (our in-call AI assistant) onto every seat, and grown to support more than 5,000 customer relationships across North America.</p>
            <p data-i18n="about.story.p3">Every agent who works on your account is fully bilingual EN/ES, dedicated to your program, and supported by AI that watches every call for quality, compliance, and coaching opportunities.</p>
          </div>
          <div class="media-card"><img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&w=900" alt="Centris contact center floor" loading="lazy" /></div>
        </div>
      </div>
    </section>

    <section class="content-section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta" data-i18n="about.tl.label">02 — Timeline</p>
          <h2><span data-i18n="about.tl.h2a">Three decades. Two hubs.</span><br /><span class="accent" data-i18n="about.tl.h2b">One throughline.</span></h2>
        </div>
        <div class="timeline ir">
          <div class="tl-row"><span class="yr">1993</span><h4>Founded in Longview, TX</h4><p>Centris opens as a US-led contact center services firm targeting the underserved bilingual market for North American brands.</p></div>
          <div class="tl-row"><span class="yr">1998</span><h4>Monterrey hub opens</h4><p>First nearshore center in Nuevo León. Same-timezone delivery becomes the company's structural advantage.</p></div>
          <div class="tl-row"><span class="yr">2007</span><h4>1,000th customer milestone</h4><p>Cross-vertical growth into insurance, healthcare, and security — laying the foundation for the industry playbooks that run today.</p></div>
          <div class="tl-row"><span class="yr">2015</span><h4>Aguascalientes hub opens</h4><p>Second nearshore center adds redundancy and healthcare-vertical capacity. Both centers run on Central Time.</p></div>
          <div class="tl-row"><span class="yr">2022</span><h4>Sophia AI launches</h4><p>In-call AI assistant rolls out across every seat. 100% QA coverage replaces sampled manual QA on day one.</p></div>
          <div class="tl-row"><span class="yr">2026</span><h4>5,000+ customer relationships</h4><p>The largest US-led bilingual nearshore CCaaS provider — still treating every account as a partnership.</p></div>
        </div>
      </div>
    </section>

    <section class="content-section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta" data-i18n="about.values.label">03 — Values</p>
          <h2 data-i18n="about.values.h2">What we actually believe.</h2>
        </div>
        <div class="leaders ir" style="margin-top: 2.5rem;">
          <div class="leader"><div class="avatar">H</div><h4 data-i18n="about.values.1.h">Human-first</h4><p class="role" data-i18n="about.values.1.role">Value 01</p><p data-i18n="about.values.1.p">AI augments the agent. It does not replace the person on the call. Every interaction has a name attached to it.</p></div>
          <div class="leader"><div class="avatar">P</div><h4 data-i18n="about.values.2.h">Partner, not vendor</h4><p class="role" data-i18n="about.values.2.role">Value 02</p><p data-i18n="about.values.2.p">Your account team is named, dedicated, and stays. Continuity beats sampling every time, in every industry.</p></div>
          <div class="leader"><div class="avatar">B</div><h4 data-i18n="about.values.3.h">Bilingual by default</h4><p class="role" data-i18n="about.values.3.role">Value 03</p><p data-i18n="about.values.3.p">Every agent. Every call. No language tiers, no transfers. Your Spanish-speaking customers get the same service.</p></div>
          <div class="leader"><div class="avatar">M</div><h4 data-i18n="about.values.4.h">Measured, not promised</h4><p class="role" data-i18n="about.values.4.role">Value 04</p><p data-i18n="about.values.4.p">Live dashboards, 100% QA coverage, weekly digests. You see what we see. Numbers settle arguments.</p></div>
        </div>
      </div>
    </section>

    <section class="content-section border-t">
      <div class="wrap">
        <div class="sec-head ir">
          <p class="meta" data-i18n="about.team.label">04 — Leadership</p>
          <h2 data-i18n="about.team.h2">The team running this.</h2>
        </div>
        <div class="leaders ir" style="margin-top: 2.5rem;">
          <div class="leader"><div class="avatar">AB</div><h4>Alejandro Bautista</h4><p class="role">Chief Executive Officer</p><p>20+ years in CCaaS leadership. Joined Centris in 2014 from a Fortune 500 ops role. Drives the human-first AI strategy.</p></div>
          <div class="leader"><div class="avatar">MR</div><h4>Maria Rodriguez</h4><p class="role">President</p><p>Operations leader behind the dedicated-team model. Spent her early career running call centers in Monterrey.</p></div>
          <div class="leader"><div class="avatar">JC</div><h4>James Chen</h4><p class="role">CTO &amp; AI</p><p>Architect of the Sophia platform. Built the 100% QA coverage engine that replaced sampled manual QA in 2022.</p></div>
          <div class="leader"><div class="avatar">SK</div><h4>Sofia Kim</h4><p class="role">VP, Customer Success</p><p>Runs the partnership model across all accounts. Cares about CSAT more than anyone else in the company.</p></div>
        </div>
      </div>
    </section>
    <section id="contact-cta" class="closing border-t">
      <h2 class="ir"><span data-i18n="closing.h2a">Want to learn more about</span><br /><span class="accent" data-i18n="closing.h2b">outsourcing your contact center?</span></h2>
      <p class="ir" data-i18n="closing.sub">Fill out the form on our contact page and we'll get in touch ASAP.</p>
      <div class="ctas ir">
        <a class="cta-primary lg" href="<?php echo home_url('/contact/'); ?>" data-i18n="closing.cta">Book a 15-minute demo
          <svg class="ico arr" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
        <a class="cta-quiet" href="tel:18005304897"><u data-i18n="closing.alt">Or call 1-800-530-4897</u>
          <svg class="ico" viewBox="0 0 24 24" style="transform:translateY(-1px)"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg></a>
      </div>
    </section>
    <footer>
      <div class="foot">
        <div class="foot-brand">
          <a href="<?php echo home_url('/'); ?>" class="brand-mark" aria-label="Centris"><img src="data:image/webp;base64,UklGRloGAABXRUJQVlA4WAoAAAAQAAAApQAAMwAAQUxQSD0DAAABoFVtexbneiTgoK8EHAwOWgfgABxkHLAdZDtAQiREwivhlfAc5OcN7TccR8QEYOS8x6xGUtO5Cp7pchqdesrzkMShaXkWU+TwJA/iMN4YHsN08c6ApyjKOwOeoijvDHiKorwzoDql+dOJ8s6AqmSqfLjEG3NAVZRknj7amzdG1EVZnp9MONJUlWRAXZT15YMlX9q/UM7fqIuymT/XRm9+wS3KzvVjJc8Jvyh79d8niVkGzHTu8IuyfxmzvJOSls7lH5BJpgHREeAXpTOOmBM7s/w5lgO0L8IvSq8NOOhc/1oimX0zu1V8ovQvrjedNv8WkoxDRJnFt/edcIty4O5ZWLVzXUMibcZfG3z2iUuUI6NHK9eEctMZ/6bUleAV5dDs+GF5oTmhvSUjc5TWcipJy1F60rZtAGKMUSQZi0gy1paopKVVoF3BI8qx6ogVabVnZfOobexcO0oAJLkqaZ7/2NTDur4ds3G0IxcX3LOx8yiE3fMQJamONzsDu199s/F3sNx9StL21yuStAlArJhVziGlx0jqvkZlwA2Rv2l1bSRVACCRDAByEYBQaOv6+vpq2f6a+4QkVwCywvHdh/BLrNhdieQl5U4yASBJBQAjyVZEtSKot6ZCzwWldu0O/OggdWhxuYz91khFGhbhQmI9rZ7ogeiY5DgLmzz0/o4wQHKNPHF1mQsIQy7HUvBqzRUjqanzrwDbpRUeZxcXHzYbsDuQCl5SOfguEsmE/j8CYD6L9NOXBkDU9/IsFfIK25lJRgCBJN/FoXJLuulcAUBJ5qmPPwMwRY/CfdQ6L2AyktQYE8kog5Qkr3je8D+Z9i2SZETqMxkABEf04XDYDGApmjrqLEgd9z97BXsfVUZAtOs1AJJ6kqCctZUFgya9a9GWrcBkfVQZAbk6FGPlTEZaCi+0t8tIvb5RHQGJmdTo6/2OmbQcJgAIDuo6AgitddAnnMxBprU1bdLAj1YyPndwkXaFbdvCZdS5AdFCPhiyr9vWBnCSAZ9c7A7y3cJx4bNv9/Bsff5wD7M8BYR7qPIUEO6hzk8Bxz3k8RQgeovtjwEIN+QZT1LiIAt4mrJnn4YJT1S2M6kVqinuMx4hAFZQOCD2AgAAUBAAnQEqpgA0AD6RQJhJJaQiISo1vIiwEglmCHKxjQWlg9+m85Wxf4nir0IdofMB8HfVH4pfTV8wH7ZesB/p/Vh6AHSO+gB+tfpr+xz+4XpVAI0HW1OuIh7BKc+tlU2EG3c9pz7xiEy4hwmS2vrGaFMiRk6HoRNLaV4hMwD2aZuQpjtw2J4iYipiAAD+axULKw73xZ/5zu7c6cz8Kyn9y6jfrxJ+Hlr05mVmbEKPgTv9quR0GxaJW2+7Pl8AY1q7Clh0oS9ZrW90xnH2+Szy86R4xQlFOq45RZR38/tDveDoHlavpLb2gfmZ6MJM0/iDJuOkQN32hEDv8TliU2DB/19gFLRnwmnDvCSQHmxv9S7Aif4Gf1+3xe/9b4fzNhnSL8sj1UvtWcPj4C7Pw//05voL//aWWjs2zIhnTmBMG3QbsL0c6AdfAqmoXUD7Zsft3yyjIOa0v6o7ItcGvloPEdmktmsJc8UV40UyeWTWck2iYhB90D+FVZwTL0ovepmBvGmgGiKjDzv3bOCaDZicQplwq9GQ3M/xkLlCmvlK76mYFBamg/qAEf5k9crw4gq2UVVeZwC0PLIKI2X9XvnZmgWHjqvQtC1fh75iHVyXZfjU4AvRHQvyZe5c30O3yb7cKHOx9S62Ip3msyUeIiyrT3KnGoTKei8P/OuE94fXz94LHm3gnbyC2LkSBqXbdTDU8Ck16hD/C7sumGj6LC5cJby7p9LhOqWE/RxUWpWQ9A5wIUMaxeI8o2GpL0QP7n+NI5PyG/8NC11Qs3vMH3ZLqDmHq/ZeW5Rv91zGPnA1tbWEvG6VxaNPnDCaM9l/WfuNPb0ypwF3JTT09lMsL/4GOpenHYBcR5FK38d0W6P/K50BxZpCDZ83O0pGbsWoYibjB3cAmuxo//vK9vo74OruV9XZS4cVZerSFfYv/oclHfrJZIEyRvuNBdsdwlx/mLNKj/Zfvv/fSTD7AEvnoiOxJZPjfZj82/3z9wIJuf7wAAAAAAAAAAA=" alt="Centris" /></a>
          <p data-i18n="foot.about">Centris Information Services &mdash; bilingual nearshore contact center solutions, built for a human-first AI future.</p>
          <div class="foot-social">
            <a href="https://facebook.com/centrisinfo" aria-label="Facebook"><svg class="ico" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
            <a href="https://linkedin.com/company/centris-information-services" aria-label="LinkedIn"><svg class="ico" viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
            <a href="https://x.com/centrisinfo" aria-label="X"><svg class="ico" viewBox="0 0 24 24"><path d="M18 4 6 20M6 4l12 16"/></svg></a>
          </div>
        </div>
        <div class="foot-col"><h4 data-i18n="foot.services">Services</h4><ul>
          <li><a href="<?php echo home_url('/services/ai-call-center/'); ?>" data-i18n="service.ai-call-center.name">AI Call Center</a></li>
          <li><a href="<?php echo home_url('/services/customer-support/'); ?>" data-i18n="service.customer-support.name">Customer Support</a></li>
          <li><a href="<?php echo home_url('/services/bpo/'); ?>" data-i18n="service.bpo.name">Business Process Outsourcing</a></li>
          <li><a href="<?php echo home_url('/services/inbound-sales/'); ?>" data-i18n="service.inbound-sales.name">Inbound Sales</a></li>
          <li><a href="<?php echo home_url('/services/live-chat/'); ?>" data-i18n="service.live-chat.name">Live Chat</a></li>
          <li><a href="<?php echo home_url('/services/marketing-surveys/'); ?>" data-i18n="service.marketing-surveys.name">Marketing Surveys</a></li>
          <li><a href="<?php echo home_url('/services/quality-assurance/'); ?>" data-i18n="service.quality-assurance.name">Quality Assurance</a></li>
          <li><a href="<?php echo home_url('/services/soft-collections/'); ?>" data-i18n="service.soft-collections.name">Soft Collections</a></li>
          <li><a href="<?php echo home_url('/services/tier-1-tech/'); ?>" data-i18n="service.tier-1-tech.name">Tier 1 Tech Support</a></li>
        </ul></div>
        <div class="foot-col"><h4 data-i18n="foot.industries">Industries</h4><ul>
          <li><a href="<?php echo home_url('/industries/insurance/'); ?>" data-i18n="industry.insurance.name">Insurance</a></li>
          <li><a href="<?php echo home_url('/industries/healthcare/'); ?>" data-i18n="industry.healthcare.name">Healthcare</a></li>
          <li><a href="<?php echo home_url('/industries/retail/'); ?>" data-i18n="industry.retail.name">Retail &amp; E-commerce</a></li>
          <li><a href="<?php echo home_url('/industries/security/'); ?>" data-i18n="industry.security.name">Security</a></li>
          <li><a href="<?php echo home_url('/industries/utilities/'); ?>" data-i18n="industry.utilities.name">Utilities</a></li>
          <li><a href="<?php echo home_url('/industries/finance/'); ?>" data-i18n="industry.finance.name">Finance</a></li>
          <li><a href="<?php echo home_url('/industries/'); ?>" data-i18n="nav.all_industries">View all industries</a></li>
        </ul></div>
        <div class="foot-col">
          <h4 data-i18n="foot.contact">Contact</h4>
          <ul>
            <li><a href="tel:18005304897">1-800-530-4897</a></li>
            <li><a href="mailto:kudos@centrisinfo.com">kudos@centrisinfo.com</a></li>
            <li style="color: var(--muted); font-size: 14px;">119 W. Tyler St., Suite 260<br/>Longview, TX 75601</li>
          </ul>
          <h4 style="margin-top:1.75rem;" data-i18n="foot.resources">Resources</h4>
          <ul>
            <li><a href="<?php echo home_url('/case-studies/'); ?>" data-i18n="nav.cases">Case Studies</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Whitepapers</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Industry Events</a></li>
            <li><a href="<?php echo home_url('/resources/'); ?>">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="foot-meta">
        <span>&copy; 2026 Centris Information Services</span>
        <span data-i18n="foot.tag">Human-first AI for contact centers</span>
      </div>
    </footer>
    <button class="sophia-fab" id="sophiaFab" aria-label="Open Sophia chat">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
      <span class="fab-dot"></span>
    </button>
    <div class="sophia-panel" id="sophiaPanel" role="dialog" aria-label="Sophia assistant">
      <div class="sp-head">
        <div class="sp-avatar">S</div>
        <div class="sp-meta"><div class="n">Sophia</div><div class="s">Online &middot; Bilingual</div></div>
        <button class="sp-close" id="sophiaClose" aria-label="Close"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="sp-msgs" id="sophiaMsgs">
        <div class="sp-msg bot">Hi! I'm Sophia, the AI behind Centris contact centers. Ask me about pricing, ramp time, or what AI-assisted QA actually looks like.</div>
      </div>
      <div class="sp-quick" id="sophiaQuick">
        <button data-q="How fast can we go live?">Ramp time</button>
        <button data-q="What does pricing look like?">Pricing</button>
        <button data-q="How is quality measured?">Quality / QA</button>
        <button data-q="What languages do you cover?">Languages</button>
      </div>
      <form class="sp-input" id="sophiaForm">
        <input type="text" id="sophiaInput" placeholder="Ask Sophia anything..." autocomplete="off" />
        <button type="submit" aria-label="Send"><svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
      </form>
    </div>


<?php get_footer(); ?>
