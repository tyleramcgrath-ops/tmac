<?php
/**
 * Centris Theme — functions.php
 * Elementor-compatible, EN/ES bilingual contact center theme.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CENTRIS_VERSION', '1.0.0' );
define( 'CENTRIS_DIR',     get_template_directory() );
define( 'CENTRIS_URI',     get_template_directory_uri() );

/* ---------------------------------------------------------------
   THEME SETUP
--------------------------------------------------------------- */
function centris_setup() {
    load_theme_textdomain( 'centris', CENTRIS_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'custom-logo', [
        'height'      => 80,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ] );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'woocommerce' );

    // Elementor
    add_theme_support( 'elementor' );

    register_nav_menus( [
        'primary'  => __( 'Primary Navigation', 'centris' ),
        'footer'   => __( 'Footer Navigation',  'centris' ),
        'services' => __( 'Services Menu',       'centris' ),
        'industries' => __( 'Industries Menu',   'centris' ),
    ] );
}
add_action( 'after_setup_theme', 'centris_setup' );

/* ---------------------------------------------------------------
   ENQUEUE SCRIPTS & STYLES
--------------------------------------------------------------- */
function centris_enqueue_assets() {
    // Google Fonts — Inter + JetBrains Mono
    wp_enqueue_style(
        'centris-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap',
        [],
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'centris-styles',
        CENTRIS_URI . '/assets/css/centris.css',
        [ 'centris-fonts' ],
        CENTRIS_VERSION
    );

    // Translations / i18n
    wp_enqueue_script(
        'centris-i18n',
        CENTRIS_URI . '/assets/js/centris-i18n.js',
        [],
        CENTRIS_VERSION,
        false  // in <head> so it's available before body
    );

    // Main interactive scripts
    wp_enqueue_script(
        'centris-scripts',
        CENTRIS_URI . '/assets/js/centris-scripts.js',
        [ 'centris-i18n' ],
        CENTRIS_VERSION,
        true  // footer
    );

    // Pass WordPress data to JS
    wp_localize_script( 'centris-scripts', 'centrisData', [
        'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
        'nonce'     => wp_create_nonce( 'centris_nonce' ),
        'contactPage' => get_page_link( get_page_by_path( 'contact' ) ),
        'siteUrl'   => get_site_url(),
    ] );
}
add_action( 'wp_enqueue_scripts', 'centris_enqueue_assets' );

/* ---------------------------------------------------------------
   ELEMENTOR COMPATIBILITY
--------------------------------------------------------------- */
function centris_elementor_support() {
    // Allow Elementor to override any page
    add_filter( 'elementor/utils/get_edit_link', '__return_true' );
}
add_action( 'elementor/init', 'centris_elementor_support' );

// Register Elementor locations
function centris_register_elementor_locations( $elementor_theme_manager ) {
    $elementor_theme_manager->register_all_core_location();
    $elementor_theme_manager->register_location( 'header', [
        'label'    => __( 'Header', 'centris' ),
        'multiple' => false,
        'edit_in_content' => false,
    ] );
    $elementor_theme_manager->register_location( 'footer', [
        'label'    => __( 'Footer', 'centris' ),
        'multiple' => false,
        'edit_in_content' => false,
    ] );
    $elementor_theme_manager->register_location( 'single', [
        'label'    => __( 'Single', 'centris' ),
    ] );
    $elementor_theme_manager->register_location( 'archive', [
        'label'    => __( 'Archive', 'centris' ),
    ] );
}
add_action( 'elementor/theme/register_locations', 'centris_register_elementor_locations' );

/* ---------------------------------------------------------------
   CONTACT FORM AJAX HANDLER
--------------------------------------------------------------- */
function centris_handle_contact() {
    check_ajax_referer( 'centris_nonce', 'nonce' );

    $name    = sanitize_text_field( $_POST['name']    ?? '' );
    $company = sanitize_text_field( $_POST['company'] ?? '' );
    $email   = sanitize_email(      $_POST['email']   ?? '' );
    $phone   = sanitize_text_field( $_POST['phone']   ?? '' );
    $volume  = sanitize_text_field( $_POST['volume']  ?? '' );
    $message = sanitize_textarea_field( $_POST['message'] ?? '' );

    if ( empty( $name ) || ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => __( 'Please provide a valid name and email.', 'centris' ) ] );
    }

    $to      = get_option( 'admin_email' );
    $subject = sprintf( '[Centris Demo Request] %s — %s', $name, $company );
    $body    = sprintf(
        "Name: %s\nCompany: %s\nEmail: %s\nPhone: %s\nCall Volume: %s\n\nMessage:\n%s",
        $name, $company, $email, $phone, $volume, $message
    );
    $headers = [ "Reply-To: $name <$email>", 'Content-Type: text/plain; charset=UTF-8' ];

    $sent = wp_mail( $to, $subject, $body, $headers );

    if ( $sent ) {
        wp_send_json_success( [ 'message' => __( 'Thanks! We\'ll be in touch within one business day.', 'centris' ) ] );
    } else {
        wp_send_json_error( [ 'message' => __( 'Something went wrong. Please email us directly.', 'centris' ) ] );
    }
}
add_action( 'wp_ajax_centris_contact',        'centris_handle_contact' );
add_action( 'wp_ajax_nopriv_centris_contact', 'centris_handle_contact' );

/* ---------------------------------------------------------------
   WIDGET AREAS
--------------------------------------------------------------- */
function centris_widgets_init() {
    register_sidebar( [
        'name'          => __( 'Footer — Column 1', 'centris' ),
        'id'            => 'footer-col-1',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ] );
    register_sidebar( [
        'name'          => __( 'Footer — Column 2', 'centris' ),
        'id'            => 'footer-col-2',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ] );
}
add_action( 'widgets_init', 'centris_widgets_init' );

/* ---------------------------------------------------------------
   TITLE TAG
--------------------------------------------------------------- */
function centris_wp_title( $title ) {
    if ( is_home() || is_front_page() ) {
        return 'Centris — Bilingual Contact Center Solutions Powered by AI';
    }
    return $title . ' — Centris';
}
add_filter( 'pre_get_document_title', 'centris_wp_title' );

/* ---------------------------------------------------------------
   REMOVE EMOJI BLOAT
--------------------------------------------------------------- */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

/* ---------------------------------------------------------------
   EXCERPT SETTINGS
--------------------------------------------------------------- */
add_filter( 'excerpt_length', fn() => 30 );
add_filter( 'excerpt_more',   fn() => '…' );

/* ---------------------------------------------------------------
   ADMIN BRANDING
--------------------------------------------------------------- */
function centris_admin_bar_logo() {
    echo '<style>#wpadminbar #wp-admin-bar-wp-logo > .ab-item .ab-icon { background-image: none; } </style>';
}
add_action( 'wp_head', 'centris_admin_bar_logo' );

/* ---------------------------------------------------------------
   ELEMENTOR PRO: Disable default fonts/colors so ours take over
--------------------------------------------------------------- */
add_action( 'elementor/init', function() {
    if ( defined( 'ELEMENTOR_VERSION' ) ) {
        update_option( 'elementor_disable_color_schemes',      'yes' );
        update_option( 'elementor_disable_typography_schemes', 'yes' );
    }
} );

/* ---------------------------------------------------------------
   PREVENT ELEMENTOR FROM STRIPPING OUR CUSTOM ATTRIBUTES
--------------------------------------------------------------- */
add_filter( 'elementor/frontend/builder_content_data', function( $data ) {
    return $data;
} );

/* ---------------------------------------------------------------
   SETUP WIZARD (one-time admin notice)
--------------------------------------------------------------- */
require_once CENTRIS_DIR . '/inc/setup-wizard.php';
