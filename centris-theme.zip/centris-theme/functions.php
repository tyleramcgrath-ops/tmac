<?php
/**
 * Centris Theme — functions.php
 * Elementor-compatible, EN/ES bilingual contact center theme.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CENTRIS_VERSION', time() );
define( 'CENTRIS_DIR',     get_template_directory() );
define( 'CENTRIS_URI',     get_template_directory_uri() );

/* ---------------------------------------------------------------
   THEME SETUP
--------------------------------------------------------------- */
function centris_setup() {
    load_theme_textdomain( 'centris', CENTRIS_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'custom-logo', [
        'height'      => 80,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ] );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'woocommerce' );

    // Elementor
    add_theme_support( 'elementor' );

    register_nav_menus( [
        'primary'  => __( 'Primary Navigation', 'centris' ),
        'footer'   => __( 'Footer Navigation',  'centris' ),
        'services' => __( 'Services Menu',       'centris' ),
        'industries' => __( 'Industries Menu',   'centris' ),
    ] );
}
add_action( 'after_setup_theme', 'centris_setup' );

/* ---------------------------------------------------------------
   ENQUEUE SCRIPTS & STYLES
--------------------------------------------------------------- */
function centris_enqueue_assets() {
    // Google Fonts — Inter + JetBrains Mono
    wp_enqueue_style(
        'centris-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap',
        [],
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'centris-styles',
        CENTRIS_URI . '/assets/css/centris.css',
        [ 'centris-fonts' ],
        CENTRIS_VERSION
    );

    // Main interactive scripts
    wp_enqueue_script(
        'centris-scripts',
        CENTRIS_URI . '/assets/js/centris-scripts.js',
        [],
        CENTRIS_VERSION,
        true  // footer
    );

    // Pass WordPress data to JS
    wp_localize_script( 'centris-scripts', 'centrisData', [
        'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
        'nonce'     => wp_create_nonce( 'centris_nonce' ),
        'contactPage' => get_page_link( get_page_by_path( 'contact' ) ),
        'siteUrl'   => get_site_url(),
    ] );
}
add_action( 'wp_enqueue_scripts', 'centris_enqueue_assets' );

/* ---------------------------------------------------------------
   ELEMENTOR COMPATIBILITY
--------------------------------------------------------------- */
function centris_elementor_support() {
    // Allow Elementor to override any page
    add_filter( 'elementor/utils/get_edit_link', '__return_true' );
}
add_action( 'elementor/init', 'centris_elementor_support' );

// Register Elementor locations
function centris_register_elementor_locations( $elementor_theme_manager ) {
    $elementor_theme_manager->register_all_core_location();
    $elementor_theme_manager->register_location( 'header', [
        'label'    => __( 'Header', 'centris' ),
        'multiple' => false,
        'edit_in_content' => false,
    ] );
    $elementor_theme_manager->register_location( 'footer', [
        'label'    => __( 'Footer', 'centris' ),
        'multiple' => false,
        'edit_in_content' => false,
    ] );
    $elementor_theme_manager->register_location( 'single', [
        'label'    => __( 'Single', 'centris' ),
    ] );
    $elementor_theme_manager->register_location( 'archive', [
        'label'    => __( 'Archive', 'centris' ),
    ] );
}
add_action( 'elementor/theme/register_locations', 'centris_register_elementor_locations' );

/* ---------------------------------------------------------------
   CONTACT FORM AJAX HANDLER
--------------------------------------------------------------- */
function centris_handle_contact() {
    check_ajax_referer( 'centris_nonce', 'nonce' );

    $name    = sanitize_text_field( $_POST['name']    ?? '' );
    $company = sanitize_text_field( $_POST['company'] ?? '' );
    $email   = sanitize_email(      $_POST['email']   ?? '' );
    $phone   = sanitize_text_field( $_POST['phone']   ?? '' );
    $volume  = sanitize_text_field( $_POST['volume']  ?? '' );
    $message = sanitize_textarea_field( $_POST['message'] ?? '' );

    if ( empty( $name ) || ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => __( 'Please provide a valid name and email.', 'centris' ) ] );
    }

    $to      = get_option( 'admin_email' );
    $subject = sprintf( '[Centris Demo Request] %s — %s', $name, $company );
    $body    = sprintf(
        "Name: %s\nCompany: %s\nEmail: %s\nPhone: %s\nCall Volume: %s\n\nMessage:\n%s",
        $name, $company, $email, $phone, $volume, $message
    );
    $headers = [ "Reply-To: $name <$email>", 'Content-Type: text/plain; charset=UTF-8' ];

    $sent = wp_mail( $to, $subject, $body, $headers );

    if ( $sent ) {
        wp_send_json_success( [ 'message' => __( 'Thanks! We\'ll be in touch within one business day.', 'centris' ) ] );
    } else {
        wp_send_json_error( [ 'message' => __( 'Something went wrong. Please email us directly.', 'centris' ) ] );
    }
}
add_action( 'wp_ajax_centris_contact',        'centris_handle_contact' );
add_action( 'wp_ajax_nopriv_centris_contact', 'centris_handle_contact' );

/* ---------------------------------------------------------------
   WIDGET AREAS
--------------------------------------------------------------- */
function centris_widgets_init() {
    register_sidebar( [
        'name'          => __( 'Footer — Column 1', 'centris' ),
        'id'            => 'footer-col-1',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ] );
    register_sidebar( [
        'name'          => __( 'Footer — Column 2', 'centris' ),
        'id'            => 'footer-col-2',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ] );
}
add_action( 'widgets_init', 'centris_widgets_init' );

/* ---------------------------------------------------------------
   TITLE TAG
--------------------------------------------------------------- */
function centris_wp_title( $title ) {
    if ( is_home() || is_front_page() ) {
        return 'Centris — Bilingual Contact Center Solutions Powered by AI';
    }
    return $title . ' — Centris';
}
add_filter( 'pre_get_document_title', 'centris_wp_title' );

/* ---------------------------------------------------------------
   REMOVE EMOJI BLOAT
--------------------------------------------------------------- */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

/* ---------------------------------------------------------------
   EXCERPT SETTINGS
--------------------------------------------------------------- */
add_filter( 'excerpt_length', fn() => 30 );
add_filter( 'excerpt_more',   fn() => '…' );

/* ---------------------------------------------------------------
   ADMIN BRANDING
--------------------------------------------------------------- */
function centris_admin_bar_logo() {
    echo '<style>#wpadminbar #wp-admin-bar-wp-logo > .ab-item .ab-icon { background-image: none; } </style>';
}
add_action( 'wp_head', 'centris_admin_bar_logo' );

/* ---------------------------------------------------------------
   ELEMENTOR PRO: Disable default fonts/colors so ours take over
--------------------------------------------------------------- */
add_action( 'elementor/init', function() {
    if ( defined( 'ELEMENTOR_VERSION' ) ) {
        update_option( 'elementor_disable_color_schemes',      'yes' );
        update_option( 'elementor_disable_typography_schemes', 'yes' );
    }
} );

/* ---------------------------------------------------------------
   PREVENT ELEMENTOR FROM STRIPPING OUR CUSTOM ATTRIBUTES
--------------------------------------------------------------- */
add_filter( 'elementor/frontend/builder_content_data', function( $data ) {
    return $data;
} );

/* ---------------------------------------------------------------
   SETUP WIZARD (one-time admin notice)
--------------------------------------------------------------- */
require_once CENTRIS_DIR . '/inc/setup-wizard.php';

/* ---------------------------------------------------------------
   PAGE ROUTING — load correct template by slug
--------------------------------------------------------------- */
function centris_page_template( $template ) {
    if ( ! is_page() ) return $template;

    $slug = get_post_field( 'post_name', get_queried_object_id() );
    $map  = [
        'about'           => 'template-pages/page-about.php',
        'services'        => 'template-pages/page-services.php',
        'industries'      => 'template-pages/page-industries.php',
        'contact'         => 'template-pages/page-contact.php',
        'case-studies'    => 'template-pages/page-case-studies.php',
        'resources'       => 'template-pages/page-resources.php',
        // Service pages (child of /services/)
        'ai-call-center'      => 'template-pages/services/page-ai-call-center.php',
        'customer-support'    => 'template-pages/services/page-customer-support.php',
        'bpo'                 => 'template-pages/services/page-bpo.php',
        'inbound-sales'       => 'template-pages/services/page-inbound-sales.php',
        'live-chat'           => 'template-pages/services/page-live-chat.php',
        'marketing-surveys'   => 'template-pages/services/page-marketing-surveys.php',
        'quality-assurance'   => 'template-pages/services/page-quality-assurance.php',
        'soft-collections'    => 'template-pages/services/page-soft-collections.php',
        'tier-1-tech'         => 'template-pages/services/page-tier-1-tech.php',
        // Industry pages (child of /industries/)
        'finance'    => 'template-pages/industries/page-finance.php',
        'healthcare' => 'template-pages/industries/page-healthcare.php',
        'insurance'  => 'template-pages/industries/page-insurance.php',
        'retail'     => 'template-pages/industries/page-retail.php',
        'security'   => 'template-pages/industries/page-security.php',
        'utilities'  => 'template-pages/industries/page-utilities.php',
    ];

    if ( isset( $map[ $slug ] ) ) {
        $path = CENTRIS_DIR . '/' . $map[ $slug ];
        if ( file_exists( $path ) ) return $path;
    }
    return $template;
}
add_filter( 'template_include', 'centris_page_template' );

/* ---------------------------------------------------------------
   AI-OPTIMISED SEO & SCHEMA MARKUP
--------------------------------------------------------------- */
function centris_schema_and_seo() {
    $site_url = get_site_url();
    $logo_url = CENTRIS_URI . '/assets/images/centris-logo.webp';

    // Organisation schema
    $org = [
        '@context'    => 'https://schema.org',
        '@type'       => 'Organization',
        '@id'         => $site_url . '/#organization',
        'name'        => 'Centris',
        'url'         => $site_url,
        'logo'        => [ '@type' => 'ImageObject', 'url' => $logo_url ],
        'description' => 'Centris is a nearshore bilingual contact center solutions provider with 30+ years of experience. Locations in Monterrey and Aguascalientes, Mexico. Powered by Sophia AI for real-time coaching, sentiment analysis, and 100% auto-scored QA.',
        'foundingDate'=> '1994',
        'areaServed'  => [ 'US', 'CA', 'MX' ],
        'knowsLanguage' => [ 'en', 'es' ],
        'contactPoint'=> [
            '@type'           => 'ContactPoint',
            'telephone'       => '+1-800-530-4897',
            'contactType'     => 'sales',
            'availableLanguage' => [ 'English', 'Spanish' ],
        ],
        'location'    => [
            [
                '@type'           => 'Place',
                'name'            => 'Centris Monterrey',
                'address'         => [ '@type' => 'PostalAddress', 'addressLocality' => 'Monterrey', 'addressRegion' => 'Nuevo León', 'addressCountry' => 'MX' ],
            ],
            [
                '@type'           => 'Place',
                'name'            => 'Centris Aguascalientes',
                'address'         => [ '@type' => 'PostalAddress', 'addressLocality' => 'Aguascalientes', 'addressCountry' => 'MX' ],
            ],
        ],
        'sameAs' => [
            'https://www.linkedin.com/company/centris',
        ],
    ];

    // WebSite schema
    $website = [
        '@context' => 'https://schema.org',
        '@type'    => 'WebSite',
        '@id'      => $site_url . '/#website',
        'url'      => $site_url,
        'name'     => 'Centris',
        'publisher'=> [ '@id' => $site_url . '/#organization' ],
    ];

    // FAQ schema (homepage)
    $faq = null;
    if ( is_front_page() ) {
        $faq = [
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => [
                [ '@type' => 'Question', 'name' => 'How quickly can Centris go live?', 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => 'Pilots typically go live in 30–45 days: two weeks for knowledge transfer, two weeks for training and shadowing, then a soft launch with double QA. Full ramp at 60–90 days.' ] ],
                [ '@type' => 'Question', 'name' => 'How much can I save with Centris versus a US-based contact center?', 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => 'Most clients save 40–50% versus comparable fully-loaded US contact centers. The ROI calculator on the homepage provides a directional figure based on your call volume and handle time.' ] ],
                [ '@type' => 'Question', 'name' => 'What compliance certifications does Centris hold?', 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => 'Centris is SOC 2 Type II, HIPAA, PCI-DSS, and GDPR-aligned. PII never leaves controlled environments. Data is encrypted at rest and in transit.' ] ],
                [ '@type' => 'Question', 'name' => 'What languages does Centris support?', 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => 'English and Spanish are native across both centers — every agent is fully bilingual EN/ES. Sophia AI can surface real-time translation cues for 30+ additional languages.' ] ],
                [ '@type' => 'Question', 'name' => 'What CRM and telephony integrations does Centris support?', 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => 'Standard integrations include Salesforce, Zendesk, HubSpot, ServiceNow, Genesys, NICE CXone, Five9, AWS Connect, and Twilio Flex. Custom CRMs connect via REST/webhook in approximately two weeks.' ] ],
                [ '@type' => 'Question', 'name' => 'Does Sophia AI replace human agents?', 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => 'No. Sophia listens, drafts suggested responses, tracks sentiment, and surfaces knowledge in real time. The human agent decides whether to accept, rewrite, or skip each suggestion. Customers always speak with a person.' ] ],
            ],
        ];
    }

    echo '<script type="application/ld+json">' . wp_json_encode( $org,     JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) . '</script>' . "\n";
    echo '<script type="application/ld+json">' . wp_json_encode( $website, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) . '</script>' . "\n";
    if ( $faq ) {
        echo '<script type="application/ld+json">' . wp_json_encode( $faq, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) . '</script>' . "\n";
    }

    // AI-crawler / LLM meta hints
    echo '<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />' . "\n";
    echo '<meta name="ai-content-declaration" content="human-authored" />' . "\n";
    echo '<link rel="canonical" href="' . esc_url( ( is_ssl() ? 'https' : 'http' ) . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] ) . '" />' . "\n";
}
add_action( 'wp_head', 'centris_schema_and_seo', 1 );

/* ---------------------------------------------------------------
   SITEMAP PING — notify AI crawlers on publish
--------------------------------------------------------------- */
function centris_notify_crawlers( $post_id ) {
    if ( wp_is_post_revision( $post_id ) ) return;
    $sitemap = get_site_url() . '/sitemap.xml';
    wp_remote_get( 'https://www.google.com/ping?sitemap=' . urlencode( $sitemap ), [ 'blocking' => false ] );
    wp_remote_get( 'https://www.bing.com/ping?sitemap=' . urlencode( $sitemap ),   [ 'blocking' => false ] );
}
add_action( 'publish_post', 'centris_notify_crawlers' );

/* ---------------------------------------------------------------
   AUTO-CREATE PAGES ON THEME ACTIVATION
--------------------------------------------------------------- */
function centris_create_pages() {
    if ( get_option( 'centris_pages_created' ) ) return;

    $pages = [
        [ 'title' => 'Home',         'slug' => 'home',         'parent' => 0 ],
        [ 'title' => 'About',        'slug' => 'about',        'parent' => 0 ],
        [ 'title' => 'Services',     'slug' => 'services',     'parent' => 0 ],
        [ 'title' => 'Industries',   'slug' => 'industries',   'parent' => 0 ],
        [ 'title' => 'Contact',      'slug' => 'contact',      'parent' => 0 ],
        [ 'title' => 'Case Studies', 'slug' => 'case-studies', 'parent' => 0 ],
        [ 'title' => 'Resources',    'slug' => 'resources',    'parent' => 0 ],
    ];

    $services_page_id = 0;
    $industries_page_id = 0;
    $home_id = 0;

    foreach ( $pages as $p ) {
        if ( get_page_by_path( $p['slug'] ) ) continue;
        $id = wp_insert_post( [
            'post_title'   => $p['title'],
            'post_name'    => $p['slug'],
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '',
        ] );
        if ( $p['slug'] === 'services' )   $services_page_id   = $id;
        if ( $p['slug'] === 'industries' ) $industries_page_id = $id;
        if ( $p['slug'] === 'home' )       $home_id            = $id;
    }

    // Service sub-pages
    $service_children = [
        'AI Call Center' => 'ai-call-center', 'Customer Support' => 'customer-support',
        'BPO' => 'bpo', 'Inbound Sales' => 'inbound-sales', 'Live Chat' => 'live-chat',
        'Marketing Surveys' => 'marketing-surveys', 'Quality Assurance' => 'quality-assurance',
        'Soft Collections' => 'soft-collections', 'Tier 1 Tech Support' => 'tier-1-tech',
    ];
    if ( ! $services_page_id ) {
        $sp = get_page_by_path('services');
        $services_page_id = $sp ? $sp->ID : 0;
    }
    foreach ( $service_children as $title => $slug ) {
        if ( get_page_by_path( $slug ) ) continue;
        wp_insert_post( [ 'post_title' => $title, 'post_name' => $slug, 'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '', 'post_parent' => $services_page_id ] );
    }

    // Industry sub-pages
    $industry_children = [
        'Finance' => 'finance', 'Healthcare' => 'healthcare', 'Insurance' => 'insurance',
        'Retail' => 'retail', 'Security' => 'security', 'Utilities' => 'utilities',
    ];
    if ( ! $industries_page_id ) {
        $ip = get_page_by_path('industries');
        $industries_page_id = $ip ? $ip->ID : 0;
    }
    foreach ( $industry_children as $title => $slug ) {
        if ( get_page_by_path( $slug ) ) continue;
        wp_insert_post( [ 'post_title' => $title, 'post_name' => $slug, 'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '', 'post_parent' => $industries_page_id ] );
    }

    // Set homepage
    if ( $home_id ) {
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $home_id );
    }

    update_option( 'centris_pages_created', true );
}
add_action( 'after_switch_theme', 'centris_create_pages' );
add_action( 'init',               'centris_create_pages' );
