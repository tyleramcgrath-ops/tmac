// ====== Scroll reveals
try {
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        const idx = Array.from(e.target.parentNode.children).indexOf(e.target);
        const delay = Math.min(idx, 8) * 60;
        setTimeout(() => e.target.classList.add("in"), delay);
        io.unobserve(e.target);
      }
    });
  }, { rootMargin: "0px 0px 0px 0px", threshold: 0 });
  document.querySelectorAll(".ir").forEach((el) => io.observe(el));
  setTimeout(() => { document.querySelectorAll(".ir:not(.in)").forEach(el => el.classList.add("in")); }, 1500);
} catch(e) { console.warn("Centris reveals:", e); }

// ====== INTERACTIVE SOPHIA DEMO
try {
  const SCENARIOS = {
    insurance: {
      title: "Insurance Claim",
      lines: [
        { t: 0, kind: "cust", role: "caller", text: "I called twice last week. Nobody got back to me." },
        { t: 1500, kind: "note", text: "tone · frustrated · 2 prior contacts" },
        { t: 2800, kind: "ai", role: "sophia", text: "Acknowledge the wait. Offer expedited review with a hard timeline." },
        { t: 4400, kind: "agent", role: "agent", text: "I hear you — two weeks is too long. Let me mark this expedited, 48 hours." },
        { t: 6200, kind: "es cust", role: "caller · es", text: "cliente — gracias, eso me ayuda mucho." },
        { t: 7800, kind: "note", text: "sentiment shift · −0.4 → +0.3 · language es-MX" },
        { t: 9200, kind: "agent", role: "agent", text: "I'll send the confirmation in Spanish too. You'll have it by 5pm." },
        { t: 10800, kind: "crm", text: "CRM logged · expedited · es-MX preference set" }
      ],
      sentiment: [-0.4, -0.4, -0.3, -0.1, 0.1, 0.2, 0.3, 0.3],
      finalSignals: { lang: "es-MX", qa: 97 },
      suggest: { head: "Recommended next line · conf 0.94", text: '"And while we wait, I can connect you with your assigned adjuster for any other questions — would that help?"' }
    },
    healthcare: {
      title: "Healthcare Inquiry",
      lines: [
        { t: 0, kind: "cust", role: "patient", text: "I need to reschedule my appointment for next week." },
        { t: 1400, kind: "note", text: "tone · calm · returning patient · 4 prior visits" },
        { t: 2600, kind: "ai", role: "sophia", text: "Pull provider calendar. Offer 3 next-available slots, prioritize morning." },
        { t: 4000, kind: "agent", role: "agent", text: "Of course. I have Tuesday at 10am, Wednesday at 2pm, or Thursday at 9am." },
        { t: 5600, kind: "cust", role: "patient", text: "Tuesday at 10am works for me." },
        { t: 6800, kind: "ai", role: "sophia", text: "Confirm slot. Send SMS reminder 24h prior with parking info." },
        { t: 8400, kind: "agent", role: "agent", text: "Tuesday 10am confirmed. I'll text you a reminder Monday with parking details." },
        { t: 10200, kind: "crm", text: "Appointment rescheduled · SMS scheduled · HIPAA-logged" }
      ],
      sentiment: [0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55],
      finalSignals: { lang: "en-US", qa: 98 },
      suggest: { head: "Follow-up suggestion · conf 0.91", text: '"While you\'re on, would you like to schedule your annual lab work for the same morning? Saves you a second trip."' }
    },
    billing: {
      title: "Billing Dispute",
      lines: [
        { t: 0, kind: "cust", role: "caller", text: "There's a charge on my bill I don't recognize." },
        { t: 1500, kind: "note", text: "tone · concerned · first contact this cycle" },
        { t: 2800, kind: "ai", role: "sophia", text: "Pull last 90-day statement. Match against subscription renewals." },
        { t: 4200, kind: "agent", role: "agent", text: "Let me pull up your statement. Which date is the charge from?" },
        { t: 5800, kind: "cust", role: "caller", text: "March 14th, for $89.99." },
        { t: 7000, kind: "ai", role: "sophia", text: "Match found · auto-renewal · premium plan. Offer cancellation + same-day refund." },
        { t: 8600, kind: "agent", role: "agent", text: "I see it — that's an auto-renewal for premium. I can cancel it and refund you today." },
        { t: 10200, kind: "note", text: "resolution path · 0 escalations · refund authorized" },
        { t: 11600, kind: "crm", text: "Refund $89.99 issued · auto-renewal cancelled · customer notified" }
      ],
      sentiment: [-0.1, -0.1, 0.0, 0.1, 0.15, 0.25, 0.4, 0.5, 0.55],
      finalSignals: { lang: "en-US", qa: 96 },
      suggest: { head: "Recommended next line · conf 0.92", text: '"Want me to also turn off auto-renew on your other plans, or just this one?"' }
    },
    sales: {
      title: "Inbound Sales",
      lines: [
        { t: 0, kind: "cust", role: "caller", text: "I'm comparing your premium plan against a competitor." },
        { t: 1500, kind: "note", text: "intent · evaluating · price-sensitive signals detected" },
        { t: 2800, kind: "ai", role: "sophia", text: "Surface premium-tier value props. Mention 14-day guarantee. Hold discount until objection #2." },
        { t: 4400, kind: "agent", role: "agent", text: "Happy to walk through what makes our plan different — what features matter most to you?" },
        { t: 6200, kind: "cust", role: "caller", text: "Mostly the bilingual support and reporting. The other quote was 12% less." },
        { t: 7600, kind: "ai", role: "sophia", text: "Objection · price. Authorized: 10% loyalty discount + free onboarding ($1.2k value)." },
        { t: 9200, kind: "agent", role: "agent", text: "I can match that within 2% and include free onboarding — about $1,200 in value on day one." },
        { t: 10800, kind: "note", text: "close probability · 0.74 → 0.86" },
        { t: 12200, kind: "crm", text: "Deal advanced · proposal sent · CSM tagged" }
      ],
      sentiment: [0.1, 0.15, 0.2, 0.2, 0.05, 0.25, 0.4, 0.5, 0.55],
      finalSignals: { lang: "en-US", qa: 95 },
      suggest: { head: "Closing suggestion · conf 0.88", text: '"If we get the paperwork started today, I can have your first bilingual queue live by Friday — interested?"' }
    }
  };
  const demoPlayBtn = document.getElementById("demoPlayBtn");
  if (demoPlayBtn) {
    const $d = (id) => document.getElementById(id);
    const wave = $d("demoWave"), liveDot = $d("demoLiveDot");
    let currentKey = "insurance", timers = [], timerId = null, playing = false;
    function clearAll() { timers.forEach((t) => clearTimeout(t)); timers = []; if (timerId) { clearInterval(timerId); timerId = null; } playing = false; }
    function fmtTime(s) { return Math.floor(s/60).toString().padStart(2,"0")+":"+Math.floor(s%60).toString().padStart(2,"0"); }
    function drawSparkline(values) {
      if (!values.length) return;
      const W=240,H=60,pad=6,max=Math.max(...values,0.5),min=Math.min(...values,-0.5),range=Math.max(max-min,0.5),step=(W-pad*2)/Math.max(values.length-1,1);
      const pts=values.map((v,i)=>[pad+i*step,H-pad-((v-min)/range)*(H-pad*2)]);
      const line=pts.map((p,i)=>(i===0?"M":"L")+" "+p[0].toFixed(1)+" "+p[1].toFixed(1)).join(" ");
      const fill=line+" L "+pts[pts.length-1][0].toFixed(1)+" "+H+" L "+pts[0][0].toFixed(1)+" "+H+" Z";
      if ($d("demoSparkLine")) $d("demoSparkLine").setAttribute("d",line);
      if ($d("demoSparkFill")) $d("demoSparkFill").setAttribute("d",fill);
    }
    function updateSignal(progress, scenario) {
      const sentArr=scenario.sentiment, slice=Math.min(sentArr.length,Math.max(1,Math.ceil(progress*sentArr.length))), visible=sentArr.slice(0,slice);
      drawSparkline(visible);
      const cur=visible[visible.length-1], sentEl=$d("demoSent");
      if (sentEl) { sentEl.textContent=(cur>=0?"+":"")+cur.toFixed(2); sentEl.classList.toggle("up",cur>=0.2); }
      if ($d("demoSentMeter")) $d("demoSentMeter").style.width=(50+cur*50).toFixed(0)+"%";
      if (progress>0.6&&$d("demoLang")) $d("demoLang").textContent=scenario.finalSignals.lang;
      else if (progress>0.05&&$d("demoLang")) $d("demoLang").textContent="en-US";
      const qa=Math.round(progress*scenario.finalSignals.qa);
      if (progress>0.05&&$d("demoQa")) { $d("demoQa").innerHTML=qa+'<span style="font-size:0.55em;color:var(--muted);">%</span>'; if ($d("demoQaMeter")) $d("demoQaMeter").style.width=qa+"%"; }
    }
    function resetUI() {
      const convo=$d("demoConvo"); if (convo) convo.innerHTML='<div class="dt-empty" id="demoEmpty">Press play to start the call simulation →</div>';
      if ($d("demoTimer")) $d("demoTimer").textContent="00:00";
      if ($d("demoStatus")) $d("demoStatus").textContent="idle";
      if (liveDot) liveDot.style.opacity="0.3";
      if (wave) wave.classList.remove("active");
      if ($d("demoSent")) { $d("demoSent").textContent="0.0"; $d("demoSent").classList.remove("up"); }
      if ($d("demoSentMeter")) $d("demoSentMeter").style.width="50%";
      if ($d("demoLang")) $d("demoLang").textContent="—";
      if ($d("demoQa")) $d("demoQa").textContent="—";
      if ($d("demoQaMeter")) $d("demoQaMeter").style.width="0%";
      if ($d("demoSparkLine")) $d("demoSparkLine").setAttribute("d","");
      if ($d("demoSparkFill")) $d("demoSparkFill").setAttribute("d","");
      if ($d("demoSuggestRow")) $d("demoSuggestRow").hidden=true;
      if ($d("demoPlayLabel")) $d("demoPlayLabel").textContent="Play call";
      if ($d("demoHint")) $d("demoHint").textContent="Press play to begin.";
    }
    function addMsg(line) {
      const convo=$d("demoConvo"); if (!convo) return;
      const empty=$d("demoEmpty"); if (empty) empty.remove();
      const el=document.createElement("div"); el.className="dt-line "+line.kind;
      if (line.kind==="note"||line.kind==="crm") { el.innerHTML='<span class="role"></span><span class="body">'+line.text+'</span>'; }
      else { const role=line.role||line.kind; el.innerHTML='<span class="role">'+role+'</span><span class="body">'+line.text.replace(/&/g,"&amp;").replace(/</g,"&lt;")+'</span>'; }
      convo.appendChild(el); convo.scrollTop=convo.scrollHeight;
    }
    function setScenario(key) {
      if (key===currentKey) return; currentKey=key;
      document.querySelectorAll(".dash-tab").forEach((t)=>t.classList.toggle("active",t.dataset.scenario===key));
      if ($d("demoCallTitle")) $d("demoCallTitle").textContent=SCENARIOS[key].title;
      clearAll(); resetUI();
    }
    function play() {
      const scenario=SCENARIOS[currentKey]; if (playing) return; playing=true;
      if ($d("demoPlayLabel")) $d("demoPlayLabel").textContent="Playing…";
      if ($d("demoStatus")) $d("demoStatus").textContent="live";
      if (liveDot) liveDot.style.opacity="1";
      if (wave) wave.classList.add("active");
      if ($d("demoHint")) $d("demoHint").textContent="Sophia is listening. Transcript streaming.";
      const startMs=Date.now();
      timerId=setInterval(()=>{ if ($d("demoTimer")) $d("demoTimer").textContent=fmtTime((Date.now()-startMs)/1000); },100);
      const total=scenario.lines[scenario.lines.length-1].t+1400;
      scenario.lines.forEach((line,i)=>{ timers.push(setTimeout(()=>{ addMsg(line); updateSignal((i+1)/scenario.lines.length,scenario); },line.t)); });
      timers.push(setTimeout(()=>{
        playing=false; if (wave) wave.classList.remove("active");
        if ($d("demoStatus")) $d("demoStatus").textContent="wrapped";
        if (liveDot) liveDot.style.opacity="0.6";
        clearInterval(timerId); timerId=null;
        if ($d("demoPlayLabel")) $d("demoPlayLabel").textContent="Replay call";
        if ($d("demoHint")) $d("demoHint").textContent="Call complete. Sophia recommending follow-up.";
        if ($d("demoSuggestHead")) $d("demoSuggestHead").textContent=scenario.suggest.head;
        if ($d("demoSuggestText")) $d("demoSuggestText").textContent=scenario.suggest.text;
        if ($d("demoSuggestRow")) $d("demoSuggestRow").hidden=false;
        const sug=document.querySelector(".ai-suggest"); if (sug) sug.classList.remove("dismissed","accepted");
      },total));
    }
    document.querySelectorAll(".dash-tab").forEach((t)=>{ t.addEventListener("click",()=>setScenario(t.dataset.scenario)); });
    demoPlayBtn.addEventListener("click",()=>{ if (playing) return; clearAll(); resetUI(); play(); });
    if ($d("demoReplayBtn")) $d("demoReplayBtn").addEventListener("click",()=>{ clearAll(); resetUI(); setTimeout(play,200); });
    if ($d("demoAcceptBtn")) $d("demoAcceptBtn").addEventListener("click",()=>{ const sug=document.querySelector(".ai-suggest"); if (sug) sug.classList.add("accepted"); if ($d("demoSuggestHead")) $d("demoSuggestHead").textContent="Accepted · sent to agent script"; if ($d("demoHint")) $d("demoHint").textContent="Suggestion accepted. Logged to coaching data."; });
    if ($d("demoRewriteBtn")) $d("demoRewriteBtn").addEventListener("click",()=>{ if ($d("demoSuggestText")) $d("demoSuggestText").textContent='"Want me to also queue up a follow-up SMS in 24 hours?"'; if ($d("demoSuggestHead")) $d("demoSuggestHead").textContent="Rewritten alternative · conf 0.89"; });
    if ($d("demoSkipBtn")) $d("demoSkipBtn").addEventListener("click",()=>{ const sug=document.querySelector(".ai-suggest"); if (sug) sug.classList.add("dismissed"); if ($d("demoHint")) $d("demoHint").textContent="Suggestion skipped. Agent improvising."; });
    const voiceBtn=document.getElementById("demoVoiceBtn");
    if (voiceBtn) { voiceBtn.addEventListener("click",()=>{ voiceBtn.setAttribute("aria-pressed","false"); }); }
  }
} catch(e) { console.warn("Centris demo:", e); }

// ====== FLOATING SOPHIA CHAT WIDGET
try {
  const fab=document.getElementById("sophiaFab");
  const panel=document.getElementById("sophiaPanel");
  const closeBtn=document.getElementById("sophiaClose");
  const msgs=document.getElementById("sophiaMsgs");
  const sophiaForm=document.getElementById("sophiaForm");
  const input=document.getElementById("sophiaInput");
  const quick=document.getElementById("sophiaQuick");
  if (fab && panel && msgs && sophiaForm && input && quick) {
    const KB=[
      {keys:["ramp","fast","live","launch","start","timeline","go live"],a:"Pilots typically go live in 30–45 days. Weeks 1–2: knowledge transfer. Weeks 3–4: training & shadowing. Week 5: soft launch with double QA. Full ramp at 60–90 days."},
      {keys:["price","pricing","cost","rate","fee","budget"],a:"Most engagements are per-hour FTE or per-call. Expect 40–50% below comparable U.S. centers fully loaded. Pilots start at 10–25 seats. Try the ROI calculator on this page for a directional number."},
      {keys:["security","compliance","soc","hipaa","pci","gdpr","data"],a:"We're SOC 2 Type II, HIPAA, PCI-DSS, and GDPR-aligned. PII never leaves controlled environments. Encrypted at rest and in transit. Happy to walk through the controls matrix during procurement."},
      {keys:["language","spanish","bilingual","english","es","translate"],a:"English and Spanish are native across both centers — every agent is fully bilingual EN/ES. I can also surface real-time translation cues for 30+ additional languages on demand."},
      {keys:["qa","quality","score","coaching","assurance"],a:"I auto-score 100% of calls on adherence, empathy, resolution, and compliance — versus the typical 2–3% manual sample. Human QA analysts review flagged calls weekly. You get a live dashboard plus a weekly digest."},
      {keys:["ai","sophia","artificial","replace","robot"],a:"I don't replace agents — I assist them. I listen, draft suggested responses, track sentiment, and run real-time translation cues. The human decides. Customers always talk to a person."},
      {keys:["integrate","crm","integration","salesforce","zendesk","tool"],a:"Standard integrations: Salesforce, Zendesk, HubSpot, ServiceNow, Genesys, NICE CXone, Five9, AWS Connect, Twilio Flex. Custom CRMs connect via REST/webhook in roughly two weeks."},
      {keys:["where","location","mexico","monterrey","aguascalientes","timezone","tz"],a:"Two nearshore hubs: Monterrey (Nuevo León) and Aguascalientes. Both run on Central Time, so no overnight gap. ~1,280 bilingual agents online right now."},
      {keys:["call","contact","demo","talk","schedule","sales","book"],a:"Easiest: book a 15-minute demo from the CTA at the bottom of the page, or call 1-800-530-4897. Either way, we'll come ready with numbers for your call mix."},
      {keys:["exit","leave","contract","cancel","term"],a:"Standard contracts are annual with 90-day notice. We hand over knowledge artifacts and recordings (where contractually retained), plus a structured transition playbook. No exit fees."},
      {keys:["industry","insurance","healthcare","retail","utilities","industries"],a:"Strongest in insurance, healthcare, retail, security, utilities, finance, restaurant, and warranty & claims. The Industries section above goes deeper."},
    ];
    function sophiaReply(q){ const lower=q.toLowerCase(); for (const item of KB){ if (item.keys.some((k)=>lower.includes(k))) return item.a; } return "Great question — I'd love to answer that in detail. The fastest path is to book a 15-minute demo (CTA at the bottom of the page) or call 1-800-530-4897."; }
    function addSophiaMsg(text,who){ const el=document.createElement("div"); el.className="sp-msg "+who; el.textContent=text; msgs.appendChild(el); msgs.scrollTop=msgs.scrollHeight; }
    function ask(q){ addSophiaMsg(q,"you"); setTimeout(()=>addSophiaMsg(sophiaReply(q),"bot"),500+Math.random()*400); }
    fab.addEventListener("click",()=>panel.classList.toggle("open"));
    if (closeBtn) closeBtn.addEventListener("click",()=>panel.classList.remove("open"));
    quick.querySelectorAll("button").forEach((b)=>{ b.addEventListener("click",()=>ask(b.dataset.q)); });
    sophiaForm.addEventListener("submit",(e)=>{ e.preventDefault(); const v=input.value.trim(); if (!v) return; ask(v); input.value=""; });
  }
} catch(e) { console.warn("Centris sophia:", e); }

// ====== LIVE TICKER
try {
  const tkCalls=document.getElementById("tk-calls");
  const tkSent=document.getElementById("tk-sent");
  const tkAht=document.getElementById("tk-aht");
  const tkAgents=document.getElementById("tk-agents");
  if (tkCalls) {
    let n=12847;
    setInterval(()=>{
      n+=Math.floor(Math.random()*4)+1;
      tkCalls.textContent=n.toLocaleString();
      if (tkSent) tkSent.textContent="+"+(0.38+Math.random()*0.10).toFixed(2);
      if (tkAht) { const m=3+Math.floor(Math.random()*2),s=Math.floor(Math.random()*60).toString().padStart(2,"0"); tkAht.textContent=m+"m "+s+"s"; }
      if (tkAgents) tkAgents.textContent=(1240+Math.floor(Math.random()*80)).toLocaleString();
    },2400);
  }
} catch(e) { console.warn("Centris ticker:", e); }

// ====== ROI CALCULATOR
try {
  const roiVol=document.getElementById("roi-vol");
  if (roiVol) {
    const roiAht=document.getElementById("roi-aht"), roiRate=document.getElementById("roi-rate"), roiMix=document.getElementById("roi-mix");
    const roiVolV=document.getElementById("roi-vol-v"), roiAhtV=document.getElementById("roi-aht-v"), roiRateV=document.getElementById("roi-rate-v"), roiMixV=document.getElementById("roi-mix-v");
    const roiSavings=document.getElementById("roi-savings"), roiCurr=document.getElementById("roi-current"), roiNew=document.getElementById("roi-new"), roiQa=document.getElementById("roi-qa"), roiTotal=document.getElementById("roi-total");
    const fmt=(n)=>{ if (n>=1e6) return "$"+(n/1e6).toFixed(2)+"M"; if (n>=1e3) return "$"+Math.round(n/1e3)+"K"; return "$"+Math.round(n); };
    function roiUpdate(){
      const v=+roiVol.value,a=roiAht?+roiAht.value:5,r=roiRate?+roiRate.value:18,m=roiMix?+roiMix.value:30;
      if (roiVolV) roiVolV.textContent=(+v).toLocaleString();
      if (roiAhtV) roiAhtV.textContent=a.toFixed(1);
      if (roiRateV) roiRateV.textContent="$"+r.toFixed(2);
      if (roiMixV) roiMixV.textContent=m+"%";
      const current=12*v*r*(1+(m/100)*0.12), newCost=12*v*r*0.55, saved=current-newCost, pct=Math.round((saved/current)*100);
      if (roiCurr) roiCurr.textContent=fmt(current);
      if (roiNew) roiNew.textContent=fmt(newCost);
      if (roiQa) roiQa.textContent="+97 pts";
      if (roiSavings) roiSavings.innerHTML=fmt(saved)+'<span class="unit">/ yr saved</span>';
      if (roiTotal) roiTotal.textContent=fmt(saved)+" · "+pct+"%";
    }
    [roiVol,roiAht,roiRate,roiMix].filter(Boolean).forEach((el)=>el.addEventListener("input",roiUpdate));
    roiUpdate();
  }
} catch(e) { console.warn("Centris ROI:", e); }

// ====== ANIMATED COUNTERS
try {
  const countEls=document.querySelectorAll("[data-count]");
  if (countEls.length) {
    const animate=(el)=>{ const target=+el.dataset.count,suffix=el.dataset.suffix||"",dur=1400,start=performance.now(); function tick(now){ const t=Math.min(1,(now-start)/dur),eased=1-Math.pow(1-t,3); el.textContent=Math.round(target*eased)+suffix; if (t<1) requestAnimationFrame(tick); } requestAnimationFrame(tick); };
    const cObs=new IntersectionObserver((entries)=>{ entries.forEach((e)=>{ if (e.isIntersecting){ animate(e.target); cObs.unobserve(e.target); } }); },{threshold:0.5});
    countEls.forEach((el)=>cObs.observe(el));
  }
} catch(e) { console.warn("Centris counters:", e); }

// ====== 3D TILT ON SERVICE CARDS
try {
  document.querySelectorAll("[data-tilt]").forEach((card)=>{
    card.addEventListener("mousemove",(e)=>{ const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height; card.style.transform=`perspective(1000px) rotateX(${(0.5-y)*6}deg) rotateY(${(x-0.5)*8}deg) translateY(-4px)`; });
    card.addEventListener("mouseleave",()=>{ card.style.transform=""; });
  });
} catch(e) { console.warn("Centris tilt:", e); }

// ====== FAQ ACCORDION
try {
  document.querySelectorAll(".faq-item").forEach((item)=>{
    const btn=item.querySelector(".faq-q");
    if (!btn) return;
    btn.addEventListener("click",()=>{ const open=item.classList.toggle("open"); btn.setAttribute("aria-expanded",open?"true":"false"); });
  });
} catch(e) { console.warn("Centris FAQ:", e); }

// ====== SCROLL PROGRESS BAR
try {
  const scrollBar=document.getElementById("scrollBar");
  if (scrollBar) {
    function updateBar(){ const h=document.documentElement,sc=h.scrollTop||document.body.scrollTop,max=(h.scrollHeight-h.clientHeight)||1; scrollBar.style.width=((sc/max)*100).toFixed(2)+"%"; }
    window.addEventListener("scroll",updateBar,{passive:true}); updateBar();
  }
} catch(e) { console.warn("Centris scrollbar:", e); }

// ====== THEME (dark mode enforced, toggle kept for compatibility)
try {
  const stored=localStorage.getItem("centris-theme");
  if (stored) document.documentElement.setAttribute("data-theme",stored);
  else document.documentElement.setAttribute("data-theme","dark");
} catch(e) {}

// ====== WORDPRESS AJAX CONTACT FORM
try {
  const contactForm=document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit",function(e){
      e.preventDefault();
      const btn=contactForm.querySelector('[type="submit"]'), origText=btn?btn.textContent:"";
      if (btn){ btn.textContent="Sending…"; btn.disabled=true; }
      const data=new FormData(contactForm);
      data.append("action","centris_contact");
      data.append("nonce",contactForm.dataset.nonce||"");
      fetch(contactForm.dataset.ajax||"/wp-admin/admin-ajax.php",{method:"POST",body:data})
        .then(r=>r.json())
        .then(res=>{ if (res.success){ contactForm.innerHTML='<p style="color:var(--emerald);font-family:var(--mono);text-align:center;padding:2rem;">✓ '+(res.data.message||"Thanks! We\'ll be in touch.")+'</p>'; } else { if (btn){btn.textContent=origText;btn.disabled=false;} alert(res.data.message||"Error. Please try again."); } })
        .catch(()=>{ if (btn){btn.textContent=origText;btn.disabled=false;} });
    });
  }
} catch(e) { console.warn("Centris form:", e); }
