<?php defined( 'ABSPATH' ) || exit; // The bear pops up (home page, once per visit). ?>
<div class="intro" id="intro" role="presentation">
  <div class="intro__stage">
    <div class="intro__bear" data-bear></div>
    <div class="intro__word" aria-label="Teddy"><span>T</span><span>E</span><span>D</span><span>D</span><span>Y</span></div>
    <div class="intro__sub">a new frontier.</div>
  </div>
  <button class="intro__skip" type="button">Skip intro</button>
</div>
