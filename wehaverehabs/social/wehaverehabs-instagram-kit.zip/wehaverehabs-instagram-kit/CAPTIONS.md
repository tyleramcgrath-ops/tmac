# We Have Rehabs — Instagram launch kit

## Profile

- **Username:** @wehaverehabs (or the closest available)
- **Name field** (searchable, max 30 characters): `We Have Rehabs · Rehab Guide`
- **Category:** Health & wellness website (or "Website" if that isn't offered)
- **Website link:** https://wehaverehabs.com
- **Profile picture:** 01-profile-picture/profile-picture.png (use profile-picture-dark.png if you prefer a dark one)
- **Bio** (150 characters max; this one is 128):

```
Holistic & mental-health rehabs worldwide 🌿
Honest listings · calm guides
In crisis? US: call or text 988
👇 Find a place to heal
```

## Posting order

Instagram shows the newest post first, so post them in this order (1 → 9). The welcome post ends up bottom-right and post 9 top-left, which gives a balanced 3×3 grid.

---

### Post 1 — 02-posts/post-01-welcome.jpg

```
Welcome to We Have Rehabs 🌿

We're building a calm, honest guide to holistic and mental-health rehabs around the world, from quiet retreats to clinical programs and medically supervised care.

What you'll find here:
• Plain-spoken guides to choosing care
• Destinations, from Costa Rica to Thailand
• Questions to ask, red flags to avoid
• Real listings, labelled honestly

Search thousands of programs by place, need and budget. Link in bio.

If you're in crisis right now: in the US, call or text 988. Elsewhere, findahelpline.com.

#holistichealing #mentalhealth #recovery #rehab #wellnessretreat #healingjourney #mentalhealthsupport #addictionrecovery
```

### Post 2 (carousel, 5 slides) — 02-posts/post-02-questions/slide-1 … slide-5

```
Save this before you make the call 📌

Choosing a rehab is a big decision, often made under pressure. These 12 questions help you compare programs calmly and spot the good ones.

Write down every answer, and the name of the person who gave it. A good program will welcome your questions. If one dodges them, that tells you something too.

The full guide, "How to choose a rehab", is on our site (link in bio).

This post is general information, not medical advice.

#rehab #addictionrecovery #mentalhealth #recoveryispossible #sobriety #mentalhealthmatters #treatment #holistichealing
```

### Post 3 — 02-posts/post-03-quote.jpg

```
A good decision rarely has to be made in a rush.

If someone needs urgent medical help, that's an emergency: call your local emergency number. Otherwise, take the time to verify a licence, talk to your doctor and read the paperwork. The right program will still be there.

#mentalhealth #recovery #healingjourney #selfcompassion #mindfulness #holistichealing
```

### Post 4 (carousel, 4 slides) — 02-posts/post-04-red-flags/slide-1 … slide-4

```
4 red flags when choosing a rehab 🚩

Most people working in treatment care deeply about the people they serve. But it pays to know the warning signs:

1. Patient brokering: "neutral" helplines or recruiters paid to steer you
2. "Guaranteed cure" promises and unverifiable success rates
3. Pressure tactics: "only one bed left"
4. Free flights, free rent and other inducements

Two questions worth asking:
→ A referral service: "Are you paid by the facilities you recommend?"
→ A rehab: "Do you pay for referrals?"

More in our guide (link in bio).

#rehab #addictionrecovery #recovery #mentalhealthawareness #familysupport #sobriety
```

### Post 5 — 02-posts/post-05-holistic.jpg

```
What does "holistic rehab" actually mean? 🧘

Yoga, meditation, breathwork, nutrition, time in nature, art and music. These can genuinely support recovery. But on their own they aren't treatment.

A real holistic program builds them around an evidence-based core: assessment by qualified clinicians, therapies such as CBT or DBT, medical care where it's needed, and a plan for life afterwards.

Ask any "holistic" program: who are your licensed clinicians, and what does a normal week look like?

Our full explainer is on the site (link in bio).

#holisticrehab #holistichealing #wellnessretreat #mentalhealth #recovery #yogaforrecovery #mindfulness
```

### Post 6 — 02-posts/post-06-inpatient-outpatient.jpg

```
Inpatient or outpatient: which is right?

There's no single answer. It depends on your health, your safety at home, what you're dealing with, and your work and family life. Many people move between levels: residential care first, then intensive outpatient, then ongoing therapy and support.

A proper clinical assessment should guide the choice, not a sales call.

Read our plain-English guide to the levels of care (link in bio).

#rehab #recovery #mentalhealth #addictionrecovery #outpatient #treatment
```

### Post 7 — 02-posts/post-07-costa-rica.jpg

```
Thinking about rehab in Costa Rica? 🌴

Rainforest, ocean and distance from everyday triggers draw many people there. But programs vary a lot, from wellness retreats to full clinical care.

Before you book:
• Ask which permits and health ministry authorisation they hold, then verify them
• Check who the clinical lead is and how medical emergencies are handled
• Expect your insurance not to cover care abroad
• Plan your aftercare back home before you leave

Our destination guide covers it all (link in bio).

#costarica #puravida #wellnessretreat #holistichealing #recovery #mentalhealth #rehab
```

### Post 8 — 02-posts/post-08-help-now.jpg (also pin this post to the top of the profile)

```
You don't have to work this out alone. 💚

If you or someone you love needs help right now:

🇺🇸 Call or text 988 (Suicide & Crisis Lifeline, 24/7)
🇺🇸 SAMHSA National Helpline: 1-800-662-4357 (free, confidential, 24/7)
🇬🇧 Samaritans: 116 123, or NHS 111
🌍 findahelpline.com for free helplines in your country

In an emergency, call your local emergency number.

Save this. Share it. You never know who needs it.

#mentalhealth #988 #crisissupport #suicideprevention #recovery #youarenotalone
```

### Post 9 — 02-posts/post-09-for-facilities.jpg

```
Run a rehab, clinic or retreat? 🌿

Your program may already be listed on We Have Rehabs. Claim your listing for free to keep your details accurate and get guest inquiries sent straight to you.

Want photos, your story, your daily rhythm and team? Upgrade to a full profile any time.

wehaverehabs.com/for-sanctuaries (link in bio)

#rehabcenter #wellnessretreat #treatmentcenter #holisticwellness #mentalhealthprofessionals #retreatcenter
```

---

## Stories & highlights

1. Post 04-stories/story-help-now.jpg as a story and save it to a highlight called **Help now** (cover: 03-highlight-covers/highlight-help-now.png).
2. Post 04-stories/story-welcome.jpg as a story with a link sticker to https://wehaverehabs.com and save it to a highlight called **About** (cover: 03-highlight-covers/highlight-guides.png).
3. Spare covers for later highlights: highlight-places.png ("Places"), highlight-for-rehabs.png ("For rehabs").

## Good to know

- Images are 1080×1350 (4:5) posts and 1080×1920 stories. Upload them as they are, with no extra crop.
- Photos are general retreat and landscape scenes, never a specific facility. Don't caption them as one.
- Paid ads for addiction treatment on Instagram/Facebook need LegitScript certification. Organic posts like these don't.
- Keep the crisis lines in captions accurate. Don't promise outcomes or give medical advice in replies or DMs; point people to a clinician or helpline.
