Set up and launch the Instagram account for my business, We Have Rehabs (wehaverehabs.com), a directory and guide to holistic and mental-health rehabs worldwide. The account is brand new. I've attached a zip, "wehaverehabs-instagram-kit". Unzip it and use CAPTIONS.md inside as the source of truth for every bit of text. Copy captions exactly as written, including line breaks, emojis and hashtags.

Use instagram.com in the browser, where I'm already logged in. If you hit a login, a verification code, a CAPTCHA or a security check, stop and ask me to handle it, then continue.

1. Switch to a professional account.
   Settings → Account type and tools → Switch to professional account → Business. Pick the category "Health & wellness website" (or "Website" if that isn't available). Choose not to show contact info.

2. Edit the profile.
   - Profile picture: 01-profile-picture/profile-picture.png
   - Name: We Have Rehabs · Rehab Guide
   - Website / link: https://wehaverehabs.com
   - Bio: copy it exactly from CAPTIONS.md
   - Save, then check that the bio shows on 4 lines and nothing was cut off.

3. Publish the 9 feed posts in order, Post 1 first and Post 9 last. Wait about a minute between posts.
   - For each post, upload the image(s) listed in CAPTIONS.md and keep the original 4:5 aspect ratio (choose "Original", not square).
   - Posts 2 and 4 are carousels. Select all their slides in order (slide-1, slide-2, …) in one post.
   - Paste that post's caption exactly. Don't add location tags, people tags or music.
   - Leave comments on.

4. After all 9 are up, pin Post 8 (the "help now" post) to the top of the profile.

5. Post 04-stories/story-help-now.jpg as a story.
   Then add it to a new highlight named "Help now", using 03-highlight-covers/highlight-help-now.png as the highlight cover.

6. Post 04-stories/story-welcome.jpg as a story with a link sticker to https://wehaverehabs.com.
   Add it to a new highlight named "About", with cover 03-highlight-covers/highlight-guides.png.
   If link stickers aren't available on desktop, post it without one.

Rules:
- Don't follow, like, comment on or DM other accounts.
- Don't buy anything, start ads or boost posts.
- Don't change any password or security settings.
- Don't invent text: use only what's in CAPTIONS.md.

When you finish, send me a short report:
- what you completed;
- anything you had to skip, and why;
- a link to the profile.
